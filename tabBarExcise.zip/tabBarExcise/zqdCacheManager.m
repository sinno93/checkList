//
//  zqdCacheManager.m
//  tabBarExcise
//
//  Created by 郑庆登(King Zheng)-企业内部系统研发中心 on 16/1/26.
//  Copyright © 2016年 郑庆登(Qingdeng Zheng)-IT服务中心. All rights reserved.
//
#define CACHE_DIR_NAME @"serviceApp"
#define WEB_VERSION    @"webVersion.json"
#define MANI_FEST      @"manifest.json"
#import "zqdCacheManager.h"
#import "zqdownload.h"
#import "PAMD5.h"
@implementation zqdCacheManager

@synthesize loadWebViewWithURL;

+ (zqdCacheManager*)share {
    static zqdCacheManager *seh = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        seh = [[zqdCacheManager alloc] init];
    });
    return seh;
}
// 更改其属性值
-(void)initializedWithAppInfo:(NSDictionary *)appInfo andHost:(NSString*)host{
        self.appInfo = appInfo;
        self.rootDirectory = [self getBasePath];
        self.host = host;
        self.accessFile = @"/index.html";
        self.shortUrlArray = [[NSMutableArray alloc]init];
    self.shortUrlDic = [[NSMutableDictionary alloc]init];
}
/**
 *  加载webView之前的准备工作
 *
 *  @param loadBlock 准备完成后要执行的函数...
 */
-(void)prepareToLoadWebView:(void (^)(NSString *path))loadBlock{
    
    self.loadWebViewWithURL = loadBlock;
    // 初始化WebVersion
    // 初始化Manifest
    [self initWebVersion];
}
/**
 *  下载webVersion 并且初始化webVersionDic
 */
-(void)initWebVersion{
    NSString* webVersionUrl = [NSString stringWithFormat:@"%@%@%@",self.host,[self.appInfo objectForKey:@"visiturl"] ,WEB_VERSION ];
    [zqdownload downloadWithURL:webVersionUrl complete:^(NetState state, NSData *data){
        if (state == success) {
            // 下载成功,保存
            if( [self saveData:data toFilePath:WEB_VERSION]){
                NSString *jsonStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
                NSDictionary *webVersion = [zqdCacheManager dictionaryWithJsonString:jsonStr];
                NSString *mfMD5 = [webVersion objectForKey:@"mfMD5"];
                if (mfMD5) {
                    self.webVersionDic = webVersion;
                    [self initManifest];
                }
                //[self initManifest];
            }
        }
    }];
}
-(BOOL)shouldBeHandledWithUrl:(NSURL *)url{
    NSSet * set = [[NSSet alloc] initWithObjects:@"http",@"https",@"file",nil];
    BOOL isSupportScheme = [set containsObject:url.scheme];
    if (!isSupportScheme) {
        return NO;
    }else{
        if (![self getShortUrlStrWithUrl:url]) {
            return NO;
        }else return YES;
    }
    
}
-(NSString*)getShortUrlStrWithUrl:(NSURL *)url{
    NSMutableString *urlStr = [url.absoluteString mutableCopy];
    if([urlStr rangeOfString:@"?"].length>0){
        urlStr = [[urlStr componentsSeparatedByString:@"?"][0] mutableCopy];
    }
    NSString *separatedMark = [NSString stringWithFormat:@"%@/%@/",CACHE_DIR_NAME,[self.appInfo objectForKey:@"syskey"]];
    NSArray *urlArr = [urlStr componentsSeparatedByString:separatedMark];
    if (urlArr.count>1) {
        return urlArr[1];
    }else return nil;

}
+(void)handleShortUrlStr:(NSString*)shortUrlStr andReturn:(void (^)(NSString *path))loadFile{
    zqdCacheManager * manager = [zqdCacheManager share];
    //直接取短路径对应的MD5 如果没有 直接执行了 如果有 判断是否最新 若是最新 直接执行 不是最新 下载后执行
    NSString* newFileMD5 = [manager.shortUrlDic objectForKey:shortUrlStr];
    if (!newFileMD5) {// 没有对应的MD5
        loadFile(@"x");
    }
    if ([manager isFileNewest:shortUrlStr compareMD5:newFileMD5]) {
        loadFile(@"x");
    }else{
        //下载文件后再执行
        NSString *downLoadFileUrl = [NSString stringWithFormat:@"%@%@%@",manager.host,[manager.appInfo objectForKey:@"visiturl"] ,shortUrlStr];
        [zqdownload downloadWithURL:downLoadFileUrl complete:^(NetState state,NSData *data){
            if (state == success) {//保存数据
                if([manager saveData:data toFilePath:shortUrlStr]){
                 //保存数据成功
                }
            }
            loadFile(@"x");
        }];
    
    }
}
/**
 *  初始化manifestDic 和 shortUrlDic
 */
-(void)initManifest{
    /* 先判断webVersion里的md5和本地的manifest.json的md5是否相同
        若相同，则直接通过本地manifest.json初始化manifestDic 和 shortUrlDic
        若不同，则去下载manifest.json 再初始化
     */
    NSString*urlStr = [NSString stringWithFormat:@"%@%@",self.rootDirectory,self.accessFile ];
    NSString *MD5 = [self.webVersionDic objectForKey:@"mfMD5"];
    if ([self isFileNewest:MANI_FEST compareMD5:MD5]) {
        NSLog(@"manifest文件是最新的");
        NSString *manifestStr = [[NSString alloc]initWithData:[self getFileDataWithShortPath:MANI_FEST] encoding:NSUTF8StringEncoding];
        NSDictionary* manifest = [zqdCacheManager dictionaryWithJsonString:manifestStr];
        self.manifestDic = manifest;
        NSDictionary *fileDict = [manifest objectForKey:@"wwwroot"];
        
        [self getURLsFromManifest:fileDict FileName:@""];
        self.loadWebViewWithURL(urlStr);
        NSLog(@"%@",self.shortUrlDic);
        NSLog(@"%@",self.shortUrlArray);
    }else{
        
        NSString* manifestUrl = [NSString stringWithFormat:@"%@%@%@",self.host,[self.appInfo objectForKey:@"visiturl"],MANI_FEST];
        [zqdownload downloadWithURL:manifestUrl complete:^(NetState state,NSData *data){
            if(state == success){
                if ([self saveData:data toFilePath:MANI_FEST]) {
                    NSString *manifestStr = [[NSString alloc]initWithData:[self getFileDataWithShortPath:MANI_FEST] encoding:NSUTF8StringEncoding];
                    NSDictionary* manifest = [zqdCacheManager dictionaryWithJsonString:manifestStr];
                    self.manifestDic = manifest;
                     NSDictionary *fileDict = [manifest objectForKey:@"wwwroot"];
                    [self getURLsFromManifest:fileDict FileName:@""];
                    self.loadWebViewWithURL(urlStr);
                };
            }
        }];
    }
    
   
}

/**
 *  获取基本路径
 *
 *  @return 返回基本路径 比如...Documents/serviceApp/ECP
 */
-(NSString*)getBasePath{
    NSMutableString *basePath = [[self documentsDirectory] mutableCopy];
    [basePath appendFormat:@"/%@/%@",CACHE_DIR_NAME,[self.appInfo objectForKey:@"syskey"]];
    return basePath;
}
/**
 *  保存数据到指定的文件中去
 *
 *  @param data     要保存的数据
 *  @param filePath 保存的路径(短路径)
 *
 *  @return 是否保存成功
 */
-(BOOL)saveData:(NSData*)data toFilePath:(NSString*)filePath{
    // 先直接creatPath 再写入文件
    NSMutableString *mutFilePath = [filePath mutableCopy];
    if ([mutFilePath hasPrefix:@"/"]) {
        [mutFilePath deleteCharactersInRange:NSMakeRange(0, 1)];
    }
    BOOL createResult = [self creatPath:mutFilePath];
    if(createResult){
        NSString *fileRealPath = [NSString string];
        if ([filePath rangeOfString:@"?"].length>0) {
           fileRealPath =[ NSString stringWithFormat:@"%@/%@",self.rootDirectory, [filePath componentsSeparatedByString:@"?"][0]];
        }else fileRealPath =[ NSString stringWithFormat:@"%@/%@",self.rootDirectory,filePath ];
        BOOL result =  [data writeToFile:fileRealPath atomically:YES];
        return result;
    }return NO;
}

/**
 *  (在app根目录下 ...ECP/...)创建路径
 *
 *  @param filePath 要创建的路径
 *
 *  @return 若存在该路径OR创建路径成功 返回YES 否则返回NO
 */
-(BOOL)creatPath:(NSString *)filePath{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSMutableArray *fileArr = [[filePath componentsSeparatedByString:@"/"] mutableCopy];
    // 若数组为空，则判断根目录是否存在,若存在则直接返回YES
    if (!fileArr){
        BOOL result = [fileManager fileExistsAtPath:self.rootDirectory];
        if(result)return result;
        return [fileManager createDirectoryAtPath:self.rootDirectory withIntermediateDirectories:YES attributes:nil error:nil];
    }else{
        //数组不为空 判断其是否是路径 不是则移除最后的...
        if([fileArr.lastObject rangeOfString:@"."].length>0){
            [fileArr removeLastObject];
            NSString *newFilePath = [NSString stringWithFormat:@"%@/%@",self.rootDirectory, [fileArr componentsJoinedByString:@"/"]];
            BOOL result = [fileManager fileExistsAtPath:newFilePath];
            if(result)return result;
            // 不存在 则创建
            return [fileManager createDirectoryAtPath:newFilePath withIntermediateDirectories:YES attributes:nil error:nil];
        }else{
            NSString *newFilePath = [NSString stringWithFormat:@"%@/%@",self.rootDirectory, [fileArr componentsJoinedByString:@"/"]];
            BOOL result = [fileManager fileExistsAtPath:newFilePath];
            if(result)return result;
            // 不存在 则创建
            return [fileManager createDirectoryAtPath:newFilePath withIntermediateDirectories:YES attributes:nil error:nil];
        }
    }
}
-(NSString*)getProperFilePathWithShortUrl:(NSString*)str{
    // 还是要返回目录地址比较好
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSMutableString *returnFilePath = [NSMutableString string];
    NSArray *fileArr = [str componentsSeparatedByString:@"/"];
    if (fileArr.count>1) {
        NSMutableString *fileRealPath = [[NSMutableString alloc]initWithString:[self documentsDirectory]];
        [fileRealPath appendFormat:@"/www"];
        NSMutableArray *fileMutArr = [fileArr mutableCopy];
        [fileMutArr removeLastObject];
        for(NSString*filePath in fileMutArr){
            [fileRealPath appendFormat:@"/%@",filePath];
        }
        BOOL dirExist = [fileManager fileExistsAtPath:fileRealPath];
        if(!dirExist){ // 文件夹不存在
            BOOL create = [fileManager createDirectoryAtPath:fileRealPath withIntermediateDirectories:YES attributes:nil error:nil];
            [fileRealPath appendFormat:@"/%@",fileArr.lastObject ];
            if(create)return fileRealPath;
            else return nil;
        }else{
            // 文件夹存在
            [fileRealPath appendFormat:@"/%@",fileArr.lastObject];
            return fileRealPath;
        }
    }else{
        // 不是目录 直接返回根目录即可
        [returnFilePath appendFormat:@"%@/www/%@",[self documentsDirectory],fileArr[0] ];
        return returnFilePath;
    }
}
/**
 *  判断当前路径的文件是否是最新文件(与manifest文件中的md5值比较)
 *
 *  @param shortFilePath 文件路径
 *
 *  @return 相同则YES,不同(或不存在)则NO
 */
-(BOOL)isFileNewest:(NSString *)shortFilePath compareMD5:(NSString*)MD5{
    if (![self isFileExistInPath:shortFilePath]) {
        return NO;
    }else{
        NSMutableString *fullPathFile = [self.rootDirectory mutableCopy];
        [fullPathFile appendFormat:@"/%@",shortFilePath];
        NSString*fileMD5 = [PAMD5 md5ForFileContent:fullPathFile];
        return [fileMD5 isEqualToString:MD5];
    }
}
-(BOOL)isFileExistInPath:(NSString*)shortFilePath{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSMutableString *fullFilePath = [self.rootDirectory mutableCopy];
    if ([shortFilePath hasPrefix:@"/"]) {
        [fullFilePath appendFormat:@"%@",shortFilePath ];
    }else{
        [fullFilePath appendFormat:@"/%@",shortFilePath ];
    }
    return [fileManager fileExistsAtPath:fullFilePath];
}
-(NSString*)documentsDirectory{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths firstObject];
    return documentsDirectory;
}

/**
 *  通过短路径获取NSData数据
 *
 *  @param shortFilePath 短路径
 *
 *  @return 获取的data数据
 */
-(NSData*)getFileDataWithShortPath:(NSString*)shortFilePath{
    NSString *fullFilePath = [NSString stringWithFormat:@"%@/%@",self.rootDirectory,shortFilePath];
    NSData *data = [NSData dataWithContentsOfFile:fullFilePath];
    return data;
}
/*!
 * @brief 把格式化的JSON格式的字符串转换成字典
 * @param jsonString JSON格式的字符串
 * @return 返回字典
 */
+ (NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString {
    if (jsonString == nil) {
        return nil;
    }
    
    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSError *err;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
                                                        options:NSJSONReadingMutableContainers
                                                          error:&err];
    if(err) {
        NSLog(@"json解析失败：%@",err);
        return nil;
    }
    return dic;
}
- (void)getURLsFromManifest:(NSDictionary*)manifestDict
                   FileName:(NSString*)fileName {
   
    for (NSDictionary *serverSubDict in manifestDict) {
        NSString *serverFileName = [serverSubDict objectForKey:@"name"];
        
        NSString * folder = [serverSubDict objectForKey:@"folder"];
        if (folder)//文件夹
        {
            if ([fileName length] > 0)
            {
                serverFileName = [fileName stringByAppendingFormat:@"/%@",serverFileName];
            }
            
            NSDictionary *serverChildren = [serverSubDict objectForKey:@"children"];
            if (serverChildren)
            {
                [self getURLsFromManifest:serverChildren FileName:serverFileName];
            }
        }
        else//文件
        {
            if ([fileName length] > 0)
            {
                serverFileName = [fileName stringByAppendingFormat:@"/%@",serverFileName];
            }
            NSString *md5 = [serverSubDict objectForKeyedSubscript:@"lastModified"];
            [self.shortUrlDic setObject:md5 forKey:serverFileName];
            [self.shortUrlArray addObject:serverFileName];
        }
    }
}
@end
