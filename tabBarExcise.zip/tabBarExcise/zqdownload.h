//
//  zqdownload.h
//  tabBarExcise
//
//  Created by 郑庆登(King Zheng)-企业内部系统研发中心 on 16/1/26.
//  Copyright © 2016年 郑庆登(Qingdeng Zheng)-IT服务中心. All rights reserved.
//

#import <Foundation/Foundation.h>
/***************************回调的网络状态********************************/
typedef enum NetState {
    success					=0, //成功返回
    connectFailed       =1, //网络连接错误
}NetState;

@interface zqdownload : NSObject {
    NSMutableData *myData;
}
@property NSInteger httpCode;
@property (strong) void (^requestResultBlock)(NetState state, NSData *data);
/**
 *  根据url下载文件并回调
 *
 *  @param urlString     要下载的文件的url
 *  @param requestResult 回调函数(返回状态和数据)
 */
+ (void)downloadWithURL:(NSString*)urlString
               complete:(void (^)(NetState state, NSData *data))requestResult;

@end
