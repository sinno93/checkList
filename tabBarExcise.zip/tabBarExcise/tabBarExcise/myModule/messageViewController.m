//
//  messageViewController.m
//  tabBarExcise
//
//  Created by 郑庆登(King Zheng)-企业内部系统研发中心 on 16/1/15.
//  Copyright © 2016年 郑庆登(Qingdeng Zheng)-IT服务中心. All rights reserved.
//

#import "messageViewController.h"
#import "ZQDCell.h"
#import "UIImageView+WebCache.h"
@interface messageViewController ()<UITableViewDelegate,UITableViewDataSource>
{
    NSArray *data;
    NSMutableData *_receiveData;
}
@property(nonatomic,strong)UITableView *tabView;
@property(nonatomic,strong)UILabel *myLabel;
@end

@implementation messageViewController
-(void)viewWillAppear:(BOOL)animated{
    
}
- (void)viewDidLoad {
     [super viewDidLoad];
    CGRect r = [ UIScreen mainScreen ].applicationFrame;
    // Do any additional setup after loading the view.
    UITableView * tableView = [[UITableView alloc]initWithFrame:r];
    self.tabView = tableView;
    tableView.rowHeight = 80;
    self.myLabel = [[UILabel alloc]initWithFrame:CGRectMake(100, 100, 100, 100)];
    self.myLabel.backgroundColor = [UIColor brownColor];
    self.myLabel.text = @"测试label";
    [tableView setBackgroundColor:[UIColor colorWithRed:214/255.0 green:255/255.0 blue:255/255.0 alpha:255/255.0]];
    tableView.delegate = self;
    tableView.dataSource = self;
    [tableView registerNib:[UINib nibWithNibName:@"ZQDCell" bundle:nil] forCellReuseIdentifier:@"zqdCell"];
    [self.view addSubview:tableView];
    
    data = [[NSArray alloc]init];
    // 访问接口
    _receiveData = [NSMutableData data];
    NSString*apiPath=@"https://kms-mappserver.sf-express.com/KMS-MSERVER";
    NSMutableString *urlStr = [apiPath mutableCopy];
    [urlStr appendString:@"/kmshome/list?startPage=0&pageSize=50&contentType="];
    
    //NSString *kmsLoginStr =[NSString stringWithFormat:@"%@?service=%@",casUrl,loginUrl];
    NSURL *kmsLoginUrl = [NSURL URLWithString:urlStr];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:kmsLoginUrl];
    [request setTimeoutInterval:15];
    [NSURLConnection connectionWithRequest:request delegate:self];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (instancetype)init{
    self = [super init];
    self.tabBarItem.title=@"信!息";
    self.tabBarItem.image=[UIImage imageNamed:@"message.png"];
    return self;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return data.count;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSLog(@"indexPath:%@",indexPath);
    ZQDCell *cell = [tableView dequeueReusableCellWithIdentifier:@"zqdCell" forIndexPath:indexPath];
    cell.zqdLabel.text = data[indexPath.row][@"title"];
    UIImage *img = [UIImage imageNamed:@"avatar_l1-1.jpg"];
//    https://kms-mappserver.sf-express.com/KMS/
    NSString *imageStr = [NSString stringWithFormat:@"https://kms-mappserver.sf-express.com/KMS/%@",data[indexPath.row][@"imagePath"] ];
    [cell.zqdImage sd_setImageWithURL:[NSURL URLWithString:imageStr] placeholderImage:[UIImage imageNamed:@"avatar_l1-1.jpg"]];
//    cell.zqdImage.image = [UIImage imageNamed:@"avatar_l1-1.jpg"];
    UILabel* author=(UILabel*)[cell.contentView viewWithTag:1001];
    author.text = data[indexPath.row][@"createrName"];
    UILabel* date = (UILabel*)[cell.contentView viewWithTag:1002];
    date.text =[ NSString stringWithFormat:@"%@", data[indexPath.row][@"createDate"] ];
    
    NSLog(@"%@",self.myLabel.text);
    NSLog(@"%@",self.myLabel.text);
    NSLog(@"%@",self.myLabel.text);
//    date.text = data[indexPath.row][@"createDate"];
    UILabel* commentCount = (UILabel*)[cell.contentView viewWithTag:1003];
    commentCount.text = [ NSString stringWithFormat:@"%@",data[indexPath.row][@"commentCount"]];
    //NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:imageStr]];
    //cell.zqdImage.image= [UIImage imageWithData:imageData];
    return cell;
}

#pragma mark - NSURLConnectionDataDelegate
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    NSHTTPURLResponse *http = (NSHTTPURLResponse *)response;
    
}
- (void)connection:(NSURLConnection *)aConn didReceiveData:(NSData *)data2
{
    [_receiveData appendData:data2];
}
- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSData* returnData = [NSData dataWithData:_receiveData];
    NSString * responseContent = [[NSString alloc] initWithData:returnData encoding:NSUTF8StringEncoding];
    NSError *error =nil;
    id json = [NSJSONSerialization JSONObjectWithData:_receiveData options:NSJSONReadingMutableContainers error:&error];
    if (error) {
        NSLog(@"解析JSON出错---%@",error);
    }
    id json_data = json[@"data"];
    NSString *title1 = json_data[1][@"title"];
    data = json_data;
    [self.tabView reloadData];
    NSLog(@"%@",json[@"data"]);
    NSLog(@"%@",[json class]);
//    NSDictionary *dic = NSJSONSerialization JSONObjectWithData:returnData options:<#(NSJSONReadingOptions)#> error:<#(NSError * _Nullable __autoreleasing * _Nullable)#>;

    NSLog(@"%@",responseContent);
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:[error localizedDescription] delegate:nil cancelButtonTitle:NSLocalizedString(@"IKnow",nil) otherButtonTitles:nil, nil];
    [alert show];
}
- (BOOL)connection:(NSURLConnection *)connection canAuthenticateAgainstProtectionSpace:(NSURLProtectionSpace *)protectionSpace
{
    return [protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust];
}

- (void)connection:(NSURLConnection *)connection didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge {
    if ([challenge.protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust]){
        [[challenge sender]  useCredential:[NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust] forAuthenticationChallenge:challenge];
        [[challenge sender]  continueWithoutCredentialForAuthenticationChallenge: challenge];
    }
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
