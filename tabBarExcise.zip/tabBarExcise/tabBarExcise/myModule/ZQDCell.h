//
//  ZQDCell.h
//  tabBarExcise
//
//  Created by 郑庆登(King Zheng)-企业内部系统研发中心 on 16/2/25.
//  Copyright © 2016年 郑庆登(Qingdeng Zheng)-IT服务中心. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZQDCell : UITableViewCell{
    
}
@property (weak, nonatomic) IBOutlet UILabel *zqdLabel;
@property (weak, nonatomic) IBOutlet UIImageView *zqdImage;
@property (weak, nonatomic) IBOutlet UILabel *labelTime;
@property (weak, nonatomic) IBOutlet UILabel *labelCount;

@end
