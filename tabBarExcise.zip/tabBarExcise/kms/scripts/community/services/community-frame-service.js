/**
 * 
 * @author 刘梓涛835879
 * 
 * @description 社区服务
 */

define(['angularAMD','global'],function(angularAMD){
	angularAMD.factory('CommunityFrameServices',["$http","$q","Global",
	function($http,$q,Global){
		var getPromise = function(p){
			var defer = $q.defer();
			p.success(function(response){
				return defer.resolve(response);
			}).error(function(){
				return defer.reject();
			});
			return defer.promise;
		};
		return{
			getCommunityMessage:function(currPage,pageSize,keyword){
				var url = Global.apiPath+"/community/list";						
				url = url+"?startPage="+ currPage + "&pageSize=" + pageSize + "&communityName=" + keyword;
				return getPromise($http.get(url));
			},
			joinCommunity:function(communityId, isAdd){
				var url = Global.apiPath+"/community/joinOrOutCommunity";	
				url = url + "?communityId=" + communityId + "&isAdd=" + isAdd;
				return getPromise($http.get(url));
			},
		};
	}]);
});
