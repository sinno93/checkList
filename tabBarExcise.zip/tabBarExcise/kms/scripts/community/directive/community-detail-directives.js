define(['angularAMD'], function(angularAMD) {
	angularAMD.directive('itemCommunitydetail', function() {
		return {
			restrict: 'AE',
			replace: 'true',
			templateUrl: 'views/common/directive/item-communitydetail.html',
			link: function(scope, element) {
				/*回复*/
				scope.reply=function(id, event){
					scope.replyPost(id);
					event.stopPropagation();
				};

				/*点赞*/
				scope.praise=function(index){
					scope.praisePost(index);
				};

				/*删除*/
				scope.delete=function(id, event){
					scope.showDialogbox1("删除这条主题讨论？", function(){
						scope.deletePost(id);
					});
					event.stopPropagation();
				};
			}
		};
	});
})