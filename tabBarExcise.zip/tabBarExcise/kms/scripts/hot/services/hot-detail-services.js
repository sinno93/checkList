define(['angularAMD','global'], function(angularAMD) {
	angularAMD.factory('HotDetailServices', ["$http", "$q", "Global", "$ionicModal",
		function($http,$q,Global,$ionicModal) {
			var getPromise = function(p) {
				var defer = $q.defer();
				p.success(function(response) {
					return defer.resolve(response);
				}).error(function() {
					return defer.reject();
				});
				return defer.promise;
			};
			
			return {
				/*获取热门详情*/
				getHotDetailContent: function (data){
					var contentType=data.contentType;
					var contentId=data.contentId;
					var url = Global.apiPath+'/hot/view/'+contentType+"/"+contentId;
					return getPromise($http.get(url));
				},
				/*点赞热门详情*/
				praiseHotDetailContent: function(data){
					var url = Global.apiPath+'/praise/toPraise?'+$.param(data);
					return getPromise($http.get(url));
				},
				/*回复热门详情*/
				replyHotDetail: function (data){
					var url = Global.apiPath+'/comment/'+data.type+'/save?'+$.param(data.param);
					return getPromise($http.get(url));
				},
				/*获取评论列表*/
				getHotDetailPostlist: function (data){
					var url = Global.apiPath+'/comment/'+data.type+'/list?'+$.param(data.param);
					return getPromise($http.get(url));
				},
				/*获取更多评论*/
				getMoreReplys: function (data){
					var url = Global.apiPath+'/comment/'+data.type+'/listReply?'+$.param(data.param);
					return getPromise($http.get(url));
				},
				/*回复现有评论*/
				replyHotDetailPost: function (data){
					var url = Global.apiPath+'/comment/'+data.type+'/saveReply?'+$.param(data.param);
					return getPromise($http.get(url));
				},
				/*关注现有评论*/
				followHotDetailPoster: function (data){
					var url = Global.apiPath+'/attention/follow/person/'+data.targetUserId;
					return getPromise($http.get(url));
				},
				/*删除评论*/
				deleteReplys: function (data){
					var url = Global.apiPath+'/comment/'+ data.type + '/delete?'+ $.param(data.param);
					return getPromise($http.get(url));
				},
			}
		}
	]);

});