require.config({
	baseUrl: 'scripts/', //基目录
	waitSeconds:200,
	paths: { //需要引入的js库
		'jquery': '../components/jquery/dist/jquery',
		'ionic': '../components/ionic/release-common/js/ionic',
		'angularAMD': '../components/plugs/angularAMD',
		'ngload': '../components/plugs/ngload',
		'angular-resource': '../components/plugs/angular-resource',
	},

	// Add angular modules that does not support AMD out of the box, put it in a shim
	shim: { // 配置依赖关系
		'angularAMD': ['ionic', 'jquery'],
		'ngload': ['angularAMD'],
		'angular-resource': ['ionic'],
		'angular-ui-router': ['ionic'],
	},
	
	// kick start application  启动app入口
	deps: ['app']

});

//加载插件

//require(['jquery','mobiscroll.core', 'mobiscroll.scroller', 'mobiscroll.datetime', 'mobiscroll.i18n.zh', 'mobiscroll.scroller.android-ics'], function($) {});