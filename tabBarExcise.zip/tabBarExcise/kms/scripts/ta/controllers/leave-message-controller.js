define(['angularAMD', 'common/services/footer-service', 'mine/services/mine-frame-services',  'common/directive/input-box', 'common/directive/item-lams-post', 'common/filters/common-filter'], function(angularAMD) {
	angularAMD.controller('leaveMessageController', ['$scope', '$stateParams', '$ionicModal', '$ionicPopup', '$location', '$rootScope', 'MineFrameServices','FooterServices', '$ionicScrollDelegate', '$timeout',
		function($scope, $stateParams, $ionicModal, $ionicPopup, $location, $rootScope, MineFrameServices, FooterServices, $ionicScrollDelegate, $timeout) {
			'use strict';
			/*传入参数*/
			var parameter={};
			parameter.userId=getMyId() || "002628";//用户Id
			parameter.userName=getMyName() || "临时登录用户！";//用户名称
			parameter.meOrTa=$stateParams.who;
			parameter.empNumber=$stateParams.workID;
			/*分页控制*/
			var listPageSize=5;
			var listStartPage=0;
			/*评论数据*/
			var commentData={};
			commentData.type='';
			commentData.setTooltip=function(t){
				$scope.$broadcast("inputBoxPlaceholder",t);
			};
			commentData.id0='';
			commentData.id1='';
			commentData.id2='';
			commentData.name0='';
			commentData.name1='';
			commentData.name2='';

			/*定义对话框*/
			$scope.showDialogbox1=function(text, callback){/*confirm*/
				$scope.explain = text;
				$scope.modalYes = "确定";
				$scope.modalNo = "取消";
				$scope.modalShow = 3;
				$scope.isBatch = function(flag) {
					if(flag){
						callback();
					}
					$scope.modal.hide();
				};
				$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
					scope: $scope,
					animation: 'slide-in-up'
				}).then(function(modal) {
					$scope.modal = modal;
					$scope.modal.show();
				});
			};
			var showDialogbox2=function(text){/*提示*/
				$scope.modalShow = 10;
				$scope.collectContent = text;
				$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
					scope: $scope,
					animation: 'slide-in-up'
				}).then(function(modal) {
					$scope.modal = modal;
					$scope.modal.show();
					$timeout(function(){
						$scope.modal.hide();
					}, 1000);
				});
			};
			/*刷新数据提示*/
			function refreshData(type, length) {
				if (type == "refresh") {
					if (length > 0) {
						$scope.refresherData = "已经为您更新" + length + "条数据";
						$(".refresher-data").show();
						$timeout(function() {
							$(".refresher-data").hide();
						}, 1000);
					}

				} else if (type == "loadMore") {
					if (length > 0) {
						$scope.infiniteData = "已经为您加载" + length + "条数据";
						$(".infinite-data").show();
						$timeout(function() {
							$(".infinite-data").hide();
						}, 1000);
					}
				}
				NoData(length,1);
			};
			var isShowNomore=false;
			$scope.scrollDragUp=function(){
				var currentTop = $ionicScrollDelegate.getScrollPosition().top;
				var maxTop = $ionicScrollDelegate.getMaxTop();
				if (currentTop - maxTop > 50 && maxTop > 0) {
					if (!isShowNomore && $scope.scrollEnded) {
						isShowNomore = true;
						$scope.infiniteData = "已经到底啦!";
						$(".infinite-data").show();
						setTimeout(function() {
							$(".infinite-data").hide();
							isShowNomore = false;
						}, 700);
					}

				}
			}
			/*页面表情转码*/
			$scope.emoijToText=function(html){
				return replace_html(html)
			};
			/*转到他的主页*/
			$scope.goHome=function(userId){
				if(userId==getMyId()){
					$location.path('/mine');
				}else{
					$location.path('/ta/'+userId);
				}
			};
			$scope.create = function() {
				$location.path('/leave-message-create/'+parameter.empNumber);
			}

			var init=function(){
				FooterServices.hide();
				$scope.meOrTa=parameter.meOrTa;
				if(parameter.meOrTa == 'me'){
					$scope.title = "我的留言";
				}else{
					$scope.title = "TA的留言";
				}
				inputBoxImg($scope);
				$scope.isInputing=false;
				$("ion-content").on("touchstart", function(event){
					keyboardDown();
					var $target=$(event.target);
					if(!($target.hasClass('mine-delrep')||$target.parents().hasClass('mine-delrep'))){
						$(".mine-delrep").hide();
					}
					$scope.isInputing=false;
				});
				$scope.scrollEnded=true;
				$scope.userId=parameter.userId;
				$scope.userName=parameter.userName;

				var data={};
				data.meOrTa=parameter.meOrTa;
				data.empNumber=parameter.empNumber;
				data.param={};
				data.param.pageSize=listPageSize;
				data.param.startPage=listStartPage;
				MineFrameServices.getMineLamsList(data).then(function(result){
					if(result.status){
						$scope.lamsList=result.data;
						listStartPage++;
						if(result.currentPage>=(result.totalPage-1)){
							$scope.scrollEnded=true;
						}else{
							$scope.scrollEnded=false;
						}
					}else{
						$ionicPopup.alert({
							template: "<p >" + result.errorMessage + "</p>"
						});
					}
				});

			}
			init();

			/*评论留言*/
			$scope.replyLams=function(event){
				var $target=$(event.target).hasClass('target')?$(event.target):$(event.target).parents(".target");
				commentData.type=$target.data('type');
				commentData.id1=$target.data('id1');
				commentData.id2=$target.data('id2');
				commentData.name1=$target.data('name1');
				commentData.name2=$target.data('name2');
				commentData.rId1=$target.data('rid1');
				commentData.rId2=$target.data('rid2');
				var text;
				switch(commentData.type){
					case 1:
						text="回复："+commentData.name1;
						break;
					case 2:
						text="回复："+commentData.name2;
						break;
					default:
						break;
				}
				$scope.$broadcast("inputOnFocus");
				$scope.isInputing=true;
				$timeout(function(){
					commentData.setTooltip(text);
				}, 300);
				$(".mine-delrep").hide();
			}
			$scope.$on('inputSend', function(event, data){
				if(data.indexOf("placeholder")>0 || data==""){
					showDialogbox2("请填写评论内容");
					return false;
				}
				var content=data;
				var data={};
				data.meOrTa=parameter.meOrTa;
				data.param={};
				data.param.parentId=(commentData.type==1)?commentData.id1:commentData.id2;
				data.param.content=content;
				data.param.receiverId=(commentData.type==1)?commentData.rId1:commentData.rId2;
				MineFrameServices.saveMineLamsItem(data).then(function(result){
					if(result.status){
						var reply=result.data;
						$($scope.lamsList).each(function(index, el) {
							if(el.id==commentData.id1){
								if(!el.replys){
									el.replys=[];
								}
								el.replys.unshift(reply);
								return;
							}
						});
						showDialogbox2("回复评论成功");
					}else{
						$ionicPopup.alert({
							template: "<p >" + result.errorMessage + "</p>"
						});
					}
				});

			});
			/*删除留言*/
			$scope.showReplyTools=function(event, createrId){
				var $target=$(event.target).hasClass('target-del')?$(event.target):$(event.target).parents(".target-del");
				var createrId=$target.data('createrid');
				$scope.delOrRep='rep';//(createrId==parameter.userId?'del':'rep');
				$target.find(".mine-delrep").show();
			}
			$scope.deleteReply=function(parentId, replyId){
				var data={};
				data.meOrTa=parameter.meOrTa;
				data.param={};
				data.param.leaveMessageId=replyId;
				MineFrameServices.deleteMineLamsItem(data).then(function(result){
					if(result.status){
						$($scope.lamsList).each(function(index, el) {
							if(el.id==parentId){
								$(el.replys).each(function(i, e) {
									if(e.id==replyId){
										$scope.lamsList[index].replys.splice(i, 1);
										$(".mine-detele").hide();
										return;
									}
								})
								return;
							}
						});
						showDialogbox2("删除留言成功");
					}else{
						$ionicPopup.alert({
							template: "<p >" + result.errorMessage + "</p>"
						});
					}
				});
			}
			
			/*刷新数据*/
			$scope.doRefresh = function(atTop) {
				if(atTop){
					$scope.lamsList={};
					listStartPage=0;

					var data={};
					data.meOrTa=parameter.meOrTa;
					data.empNumber=parameter.empNumber;
					data.param={};
					data.param.pageSize=listPageSize;
					data.param.startPage=listStartPage;
					MineFrameServices.getMineLamsList(data).then(function(result){
						if(result.status){
							$scope.lamsList=result.data;
							$scope.$broadcast('scroll.refreshComplete');
							refreshData("refresh", result.data.length);
							listStartPage++;
							if(result.currentPage>=(result.totalPage-1)){
								$scope.scrollEnded=true;
							}else{
								$scope.scrollEnded=false;
							}
						}else{
							$ionicPopup.alert({
								template: "<p >" + result.errorMessage + "</p>"
							});
						}
					});
				}else{
					var data={};
					data.meOrTa=parameter.meOrTa;
					data.param={};
					data.param.pageSize=listPageSize;
					data.param.startPage=listStartPage;
					MineFrameServices.getMineLamsList(data).then(function(result){
						if(result.status){
							var newPostlist=result.data;
							$scope.lamsList=$scope.lamsList.concat(newPostlist);
							$scope.$broadcast('scroll.infiniteScrollComplete');
							if(result.currentPage>1){
								refreshData("loadMore", result.data.length);
							}
							listStartPage++;
							if(result.currentPage>=(result.totalPage-1)){
								$scope.scrollEnded=true;
							}else{
								$scope.scrollEnded=false;
							}
						}else{
							$ionicPopup.alert({
								template: "<p >" + result.errorMessage + "</p>"
							});
						}
					});
				}
			};
			
			$scope.dealPath = function(url){
				return assembleImageUrl(url);
			};

		}
	])

});