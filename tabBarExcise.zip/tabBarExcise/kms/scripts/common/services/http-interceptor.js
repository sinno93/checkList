define(['angularAMD'], function (angularAMD) {
angularAMD.factory('HttpInterceptor', ["$q", "$rootScope",
	function($q, $rootScope) {
		return {
			request: function(config) {
				config.msBeforeAjaxCall = new Date().getTime();
				return config || $q.when(config);
			},
			responseError: function(rejection) {
//				emm.errorLog("http错误编码："+rejection.status+"。请求接口和时间："+JSON.stringify(rejection.config));
				/*进行网络的判断，当请求超过8秒时，提示用户网络错误*/
//				if (new Date().getTime() - rejection.config.msBeforeAjaxCall > 8000) {
//					$rootScope.$broadcast("NoNetWorksError", rejection);
//					return $q.reject(rejection);
//				} else
				if (rejection.status < 500) {
					$rootScope.$broadcast("DataServerError", rejection);
					return $q.reject(rejection);
				} else {
					/*其他错误报的错，定义错误信息码为400以后的才显示错误信息框*/
					$rootScope.$broadcast("ResponseServerError", rejection);
					return $q.reject(rejection);
				}
			}
		};
	}
])
});
