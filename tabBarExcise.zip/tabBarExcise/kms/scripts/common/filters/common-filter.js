define(['angularAMD'], function(angularAMD) {
	angularAMD.filter('typeFilter', [
		function() {
			return function(type) {
				switch (type) {
					case 'knowledge':
						return '知识';
						break;
					case 'theme':
						return '讨论';
						break;
					case 'blog':
						return '博客';
						break;
					default:
						break;
				}
			};


		}
	]);
	angularAMD.filter('timeFormat', [
		function() {
			return function(time) {
				var timeFormat = time.substring(0, time.length - 6),
					Midnight = time.substring(time.length - 6),
					nowDate = new Date().Format('YYYY-MM-DD'),
					Yesterday = new Date(new Date().getTime() - 24 * 60 * 60 * 1000).Format('YYYY-MM-DD');
				switch (timeFormat) {
					case nowDate:
						return '今天' + Midnight;
						break;
					case Yesterday:
						return '昨天' + Midnight;
						break;
					default:
					   return timeFormat + Midnight;
						break;
				}
			};
		}
	]);
		angularAMD.filter('askTimeFormat', [
		function() {
			return function(t) {
//				获取时间
                var time = new Date(t).Format('YYYY-MM-DD hh:mm'),
				    timeFormat = time.substring(0, time.length - 6),
					Midnight = time.substring(time.length - 6),
					nowDate = new Date().Format('YYYY-MM-DD'),
					Yesterday = new Date(new Date().getTime() - 24 * 60 * 60 * 1000).Format('YYYY-MM-DD');
				switch (timeFormat) {
					case nowDate:
						return '今天' + Midnight;
						break;
					case Yesterday:
						return '昨天' + Midnight;
						break;
					default:
					   return timeFormat + Midnight;
						break;
				}
			};
		}
	]);
	angularAMD.filter('commonTimeFormat', [
		function() {
			return function(t) {
//				获取时间
                var time = new Date(t).Format('YYYY-MM-DD');
			    return time;   
			};
		}
	]);

})