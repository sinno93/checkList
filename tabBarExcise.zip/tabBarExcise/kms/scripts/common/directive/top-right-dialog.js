define(['angularAMD'], function(angularAMD) {
	angularAMD.directive('topRightDialog', ['$rootScope','$location',
		function($rootScope, $location) {
			return {
				restrict: 'E',
				replace: true,
				scope: {},
				templateUrl: 'views/common/directive/top-right-dialog.html',
				link: function(scope) {
					scope.screenWidth = document.documentElement.clientWidth + 'px';
					function leftData() {
						if (scope.showButton) {
							document.getElementById("left_button").setAttribute("class", "kms-more icon  icon-point");
							document.getElementById("close-window").style.display = "none";
						} else {
							document.getElementById("left_button").setAttribute("class", "kms-more icon  icon-point-2");
							document.getElementById("close-window").style.display = "block";
						}
						scope.showButton = !scope.showButton;
						scope.isShowRightBtnList = !scope.isShowRightBtnList;
					}

					$rootScope.$on("close", function() {
						if (scope.showButton) {
							leftData();
						}
					});
					scope.LeftButton = function() {
						leftData();

					};
					scope.privateLetter = function() {
						$location.path('/mine-private-message');
					};
					scope.leaveMessage = function() {
						$location.path('/leave-message/me/');
					};
					scope.writeTalk = function() {
						$location.path('/talk-write/me/');
					};

				}
			};
		}
	]);
});