define(['angularAMD'], function(angularAMD) {
	angularAMD.directive('loading', [ function() {
		return {
			restrict: 'E',
			link: function($scope, $element) {
				var show = function() {
					$element.show();
				};
				var hide = function() {
					$element.hide();
				};
				
				$scope.$on('activeLoadingStatus', show);
				$scope.$on('inActiveLoadingStatus', hide);
			}
		};
	}]);
});