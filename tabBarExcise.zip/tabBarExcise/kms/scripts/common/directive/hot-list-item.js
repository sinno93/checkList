define(['angularAMD', 'hot/services/hot-services'], function(angularAMD) {
	angularAMD.directive('hotListItem', ['$rootScope', '$location', '$ionicModal', '$timeout', '$ionicPopup', 'hotServices',
		function($rootScope, $location, $ionicModal, $timeout, $ionicPopup, hotServices) {
			return {
				restrict: 'E',
				replace: true,
				scope: true,
				templateUrl: 'views/common/hot-list-item.html',
				link: function(scope) {
					$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
						scope: scope,
						animation: 'slide-in-up'
					}).then(function(modal) {
						scope.modal = modal;
					});
					//跳转详情
					scope.goDeatil = function(data) {
							console.log(data);
							$location.path('/hotDetail/' + data.contentId + "/" + data.type);
						}
						//名字跳转
					scope.goToDetail = function(data, event) {
						console.log(data);
						if (data.createrId == getMyId() ) {
							$location.path('/mine');
						}else{
							$location.path('/ta/' + data.createrId);
						}
						event.stopPropagation();
					}

					//收藏
					scope.hotCollect = function(data) {
						console.log(data);
						if (data.isSave == false) {
							data.isSave = true;
							data.isCollect = "已收藏";
							scope.modalShow = 10;
							scope.collectContent = "已经添加为收藏";
						} else {
							data.isSave = false;
							data.isCollect = "收藏";
							scope.modalShow = 10;
							scope.collectContent = "已经取消收藏";
						}

						function isCollect() {
							return {
								contentId: data.contentId,
								contentType: data.type,
								saveType: data.isSave
							}
						}
						hotServices.getIsCollect(isCollect()).then(function(res) {
							if (res.status == 1) {

							} else {
								//                       	console.log(res.errorMessage);
								$ionicPopup.alert({
									template: "<p >" + res.errorMessage + "</p>"
								});
							}
						});
						scope.modal.show();
						$timeout(function() {
							scope.modal.hide();
						}, 1000)
					}

				}
			};
		}
	]);
});