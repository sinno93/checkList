define(['angularAMD', 'hot/services/hot-detail-services'], function(angularAMD) {
	angularAMD.directive('commonReview', ['$rootScope', '$location', '$ionicModal', '$ionicScrollDelegate', '$timeout', '$ionicPopup', 'HotDetailServices',
		function($rootScope, $location, $ionicModal, $ionicScrollDelegate, $timeout, $ionicPopup, HotDetailServices) {
			return {
				restrict: 'E',
				replace: true,
				scope: true,
				templateUrl: 'views/common/directive/common-review.html',
				link: function(scope, element) {
					$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
						scope: scope,
						animation: 'slide-in-up'
					}).then(function(modal) {
						scope.modal = modal;
					});
					scope.rw = {};
					//评论id、评论索引、显示输入框flag
					var preID, index, flag;
					//回复人id
					var signId, type;
					//评论总数
					scope.total = scope.data.totalReplyCount;
					if (scope.talkTypeSettings.showReplyNo) {
						scope.totalNum = scope.data.commentNum;
					} else {
						scope.totalNum = scope.data.replyContent.length;
					}

					//评论切换先设置为真
					scope.toggledList = true;
					scope.hideMore = true;
					//获取评论数据
					var replys = scope.data.replyContent;
					//只显示5条
					if (scope.total > 5) {
						scope.data.replyContent = scope.data.replyContent.slice(0, 5);
					}
					//剩余评论数
					scope.overage = scope.total - 5;
					/*点赞*/
					scope.praise = function(data) {
						var items = {};
						data.isPraise = !data.isPraise;
						if (data.isPraise == 1) {
							data.goodNum++;
							items.isCanceled = false;
							console.log(data.isPraise);
						} else {
							data.goodNum--;
							items.isCanceled = true;
							console.log(data.isPraise);
						}
						console.log(data);
						items.contentId = data.contentId;
						if (data.selectType == "microblog") {
							items.contentType = "mic-blog";
						} else {
							items.contentType = data.selectType;
						}
						HotDetailServices.praiseHotDetailContent(items).then(function(res) {
							if (res.status == 1) {
								//scope.data.goodNum = res.data.praiseCount;
							} else {
								$ionicPopup.alert({
									template: "<p >" + res.errorMessage + "</p>"
								});
							}
						});
					};
					/*回复人名字和工号*/
					scope.getName = function(list) {
						return replypPerson(list.replyPerson, list.replyPersonId);
					}

					function replypPerson(person, id) {
						return person + id;
					}
					/*回复人跳转*/
					scope.goTa = function(list) {
							console.log(getMyId());
							if (list.replyPersonId != getMyId()) {
								$location.path('/ta/' + list.replyPersonId);
							} else {
								$location.path('/mine');
							}
						}
						/*被回复人名字和工号*/
					scope.toGetName = function(list) {
							return replypPerson(list.berepliedPerson, list.berepliedPersonId);
						}
						/*被回复人跳转*/
					scope.toGoTa = function(list) {
						console.log(getMyId());
						if (list.berepliedPersonId != getMyId()) {
							$location.path('/ta/' + list.berepliedPersonId);
						} else {
							$location.path('/mine');
						}
					};
					/* 评论数据显示隐藏切换 */
					scope.toggle = function(datas) {
							console.log(datas);
							if (scope.toggledList) {
								scope.data.replyContent = replys;
								console.log(datas.replyContent.length);
								scope.toggledList = false;
								$ionicScrollDelegate.resize();
							} else {
								scope.data.replyContent = scope.data.replyContent.slice(0, 5);
								scope.toggledList = true;
								$ionicScrollDelegate.resize();
							}
						}
						/*长按功能*/
					scope.showDelete = function(list) {
							console.log("长按功能");
							console.log(list);
							console.log(getMyId());
							if (scope.talkTypeSettings.deletable || list.replyPersonId == getMyId()) {
								var id = $("#reply" + list.signId);
								signId = list.signId;
								if (preID != id && preID != null) {
									preID.css("display", "none");
								}
								preID = id;
								id.css("display", "block");
							}
						}
						/*隐藏删除评论弹窗*/
					scope.hideTool = function() {
						angular.element(".mine-detele").css("display", "none");
					}
					scope.hideTool();
					$(window).on('touchstart', function(obj) {
						if (angular.element(obj.target).hasClass("mine-detele")) {
							return;
						}
						scope.hideTool();
					});
					/*删除一条评论*/
					scope.mineDelete = function(list, data) {
						console.log(data);
						type = data.selectType;
						scope.modalShow = 6;
						scope.explain = "是否要删除该条评论？";
						scope.modalYes = "是";
						scope.modalNo = "否";
						scope.modal.show();
					}
					scope.isSubmit = function(flag) {
						if (flag) {
							var datas = {};
							datas.param = {};
							if (type == "microblog") {
								datas.type = "mic-blog";
								datas.param.contentType = "mic-blog";
							} else {
								datas.type = type;
								datas.param.contentType = type;
							}
							datas.param.id = signId;
							HotDetailServices.deleteReplys(datas).then(function(res) {
								if (res.status == 1) {
									console.log("删除成功");
								} else {
									console.log("删除失败");
								}
							});
							GetByid(signId).remove();
							console.log(signId);
							scope.total--;
							//判断是否大于五条
							if (scope.total <= 5) {
								//还需请求数据
								//scope.data.replyContent = replys;
								scope.hideMore = false;
								console.log(scope.total);
							}
							scope.modal.hide();
						} else {
							scope.modal.hide();
						}
					};
					$rootScope.$on("closeHide", function() {
						$(".tabs").hide();
						$(".input-common").hide();
					});
					//显示键盘
					//					function showKeyboard() {
					//
					//					}
					/*调用输入框*/
					scope.showEnter = function(data) {
							flag = "one";
							console.log(data);
							setStype(data.selectType);
							setSid(data.contentId);
							//评论内容
							setReplyDatas(data.replyContent);
							//回复标识
							setFlag(flag);

							//回复人名，回复人工号
							switch (scope.talkTypeSettings.Myself) {
								case "mineFrame":
								case "taTalk":
									setReplyName(scope.data.name);
									setReplyNum(scope.data.id);
									//显示输入框
									scope.showInputBoxImg();
									//showKeyboard();
									//setTooltip("回复："+ data.name);
									scope.setHalohoder("回复：" + data.name);
									//scope.$broadcast("inputBoxPlaceholder","回复："+ data.name);
									$(".input-common").show();
									$(".tabs").hide();
									break;
								case "mineRelated":
									setReplyName(scope.mineName);
									setReplyNum(scope.mineID);
									console.log("自己不能对自己发表的内容评论！");
									$(".input-common").hide();
									$(".tabs").hide();
									break;
								case "taFrame":
									setReplyName(getMyName());
									setReplyNum(getMyId());
									//显示输入框
									scope.showInputBoxImg();
									//showKeyboard();
									//setTooltip("回复："+ data.name);
									scope.setHalohoder("回复：" + data.name);
									//scope.$broadcast("inputBoxPlaceholder","回复："+ data.name);
									$(".input-common").show();
									$(".tabs").hide();
									break;
								default:
									break;
							}


						}
						//点击评论回复
					scope.replyTa = function(list, data, reIndex) {
						flag = "two";
						console.log("list", list);
						console.log("data", data);
						console.log(reIndex);
						setStype(data.selectType);
						setSid(list.signId);

						function replyfn() {
							//							showKeyboard();
							//被回复人名，被回复人工号
							setBeReplyName(list.replyPerson);
							setBeReplyNum(list.replyPersonId);
							//评论内容
							setReplyDatas(data.replyContent);
							//评论索引
							setIndex(reIndex + 1);
							//回复标识
							setFlag(flag);

							$(".input-common").show();
							$(".tabs").hide();
							$ionicScrollDelegate.resize();

						}
						switch (scope.talkTypeSettings.Myself) {
							case "mineFrame":
								// 判断这个回复人是不是自己，若是自己，则不能回复
								console.log(scope.data.id);
								if (list.replyPersonId == scope.data.id)
									console.log("自己怎么可以回复自己呢？是不！");
								//									$ionicPopup.alert({
								//									template: "<p >" + "自己不能对自己回复！" + "</p>"
								//								});
								else {
									//回复人名，回复人工号
									setReplyName(scope.data.name);
									setReplyNum(scope.data.id);
									replyfn();
									//显示输入框
									scope.showInputBox();
									//									setTooltip("回复："+ list.replyPerson);
									scope.setHalohoder("回复：" + list.replyPerson);
									//									scope.$broadcast("inputBoxPlaceholder","回复："+ list.replyPerson);
								}
								break;
							case "taFrame":
								// 判断这个回复人是不是自己，若是自己，则不能回复
								if (list.replyPersonId == getMyId())
									console.log("自己怎么可以回复自己呢？是不！");
								else {
									//回复人名，回复人工号
									setReplyName(scope.data.name);
									setReplyNum(scope.data.id);
									replyfn();
									//显示输入框
									scope.showInputBox();
									//									setTooltip("回复："+ list.replyPerson);
									scope.setHalohoder("回复：" + list.replyPerson);
									//									scope.$broadcast("inputBoxPlaceholder","回复："+ list.replyPerson);
								}
								break;
							case "mineRelated":
								if (list.replyPersonId == scope.mineID)
									console.log("自己怎么可以回复自己呢？是不！");
								else {
									setReplyName(scope.mineName);
									setReplyNum(scope.mineID);
									replyfn();
									console.log("1");
									scope.showInputBox();
									//									setTooltip("回复："+ list.replyPerson);
									scope.setHalohoder("回复：" + list.replyPerson);
									//									scope.$broadcast("inputBoxPlaceholder","回复："+ list.replyPerson);
								}
								break;
							default:
								break;
						}

					}

					// 移除modalPay
					scope.$on('$destroy', function() {
						scope.modal.remove();
					});
					//过滤表情
					scope.getContent = function(data) {
						return replace_html(data);
					}

				}
			};
		}
	]);
});