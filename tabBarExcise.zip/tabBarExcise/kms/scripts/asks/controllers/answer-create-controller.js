define(['angularAMD', 'common/services/footer-service', 'asks/services/ask-services', 'common/directive/input-box', 'common/filters/common-filter'], function(angularAMD) {
	angularAMD.controller('answerCreateController', ['$scope', 'Global', '$ionicModal', '$ionicPopup', '$location', '$rootScope', '$stateParams', 'asksServices', 'FooterServices', '$ionicScrollDelegate',
		function($scope, Global, $ionicModal, $ionicPopup, $location, $rootScope, $stateParams, asksServices, FooterServices, $ionicScrollDelegate) {
			'use strict';
			FooterServices.hide();

			var questionID = $stateParams.askID;
			$scope.myId = getMyId();
			$scope.type = 'reply';
			var headPath = getHeadPath();

			$scope.title = "回答详情";

			$scope.content = '';
			$scope.postInfo = [];

			$scope.isFirstIn = true;



			function assembleTextInfo(content) {
				return {
					'questionId': questionID,
					'content': content
				};
			}

			function pushImageInfo(image) {
				return {
					'type': 'image',
					'src': image
				};
			}

			function pushTextInfo(content) {
				return {
					'type': 'text',
					'text': content
				};
			}

			$scope.getImageUrl = function(image) {
				transferImageToService(Global.apiPath + "/upload/image", image.original, function(imageUrl) {
					console.log(imageUrl);
					asksServices.setReply({
						'questionId': questionID,
						'images': imageUrl
					}).then(function(response) {
						if (response.status == 1) {
							$ionicPopup.alert({
								template: "<p >" + '回答成功' + "</p>"
							});
						} else if (response.status == 0) {
							$ionicPopup.alert({
								template: "<p >" + response.errorMessage + "</p>"
							});
						}
					});
					$scope.myhead = assembleImageUrl(headPath);
					$scope.postInfo.push(pushImageInfo(image.thumbnail));
					$ionicScrollDelegate.scrollBottom(true);
				}, function() {

				});
			};

			//			function 
			function init() {
				inputBoxAsk7($scope);
				$scope.sign.imageUrlDirectory = true;
				asksServices.getAskDetail(questionID).then(function(response) {
					console.log(response);
					$scope.askDetail = response.data;
					$ionicScrollDelegate.scrollBottom(true);
				});
				if (headPath == null || headPath == '') {
					asksServices.getUserInfo().then(function(response) {
						console.log(response);
						headPath = response.data.headPath;
						setHeadPath(headPath);
					});
				}
			}
			init();
			$scope.replyQuestion = function(content) {
				asksServices.setReply(assembleTextInfo(content)).then(function(response) {
					if (response.status == 1) {
						if ($scope.isFirstIn) {
							$scope.replyDate = getCurrentTime();
							$scope.myhead = assembleImageUrl(headPath);
						}
						$scope.postInfo.push(pushTextInfo(content));
						$ionicScrollDelegate.scrollBottom(true);
					} else if (response.status == 0) {
						$ionicPopup.alert({
							template: "<p >" + response.errorMessage + "</p>"
						});
					}
				});
			};

			function getCurrentTime() {
				return Date.parse(new Date());
			}
			$scope.isShow = function() {
				if ($scope.replyDate) {
					return true;
				}
				return false;
			};
			$scope.headPath = function(src){
				return assembleImageUrl(src);
			};
			$scope.showPic = function(src) {
				var imgArray = [];
				_.each($scope.askDetail.contentSequence, function(content) {
					if (content.type == 'image') {
						imgArray.push(assembleImageUrl(content.src));
					}
				});
				var index = 0;
				for (var i = 0; i < imgArray.length; i++) {
					if (imgArray[i] == assembleImageUrl(src)) {
						index = i;
					}
				}
				imgArray.unshift(index);
				pictrueViewer(imgArray);
			};
			$scope.getName = function() {
				return $scope.askDetail.createrName + $scope.askDetail.createrId;
			};
			$scope.getReward = function(reward) {
				return '悬赏' + reward;
			};
			$scope.isSelf = function(id) {
				return $scope.myId == id;
			};
			$scope.getImageUrl = function(src) {
				return assembleImageUrl(src) + '.thumbnail';
			}
		}
	])

});