define(['angularAMD'], function(angularAMD) {
	angularAMD.directive('itemAskdetailPost', function() {
		return {
			restrict: 'AE',
			replace: 'true',
			templateUrl: 'views/common/directive/item-askdetail-post.html',
			link: function(scope, element) {
				scope.adopt=function (id, event){
					scope.adoptAnswer(id, event);
				};
				
				scope.comment=function (id){
					scope.commentAnswer(id);
					event.stopPropagation();
				};

				scope.praise=function(id, index){
					scope.praiseAnswer(id, index);
					event.stopPropagation();
				}
			}
		};
	});
})