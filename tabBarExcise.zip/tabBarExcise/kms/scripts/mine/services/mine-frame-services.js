define(['angularAMD', 'global'], function(angularAMD) {
	angularAMD.factory('MineFrameServices', ["$http", "$q", "Global",
		function($http, $q, Global) {
			var getPromise = function(p) {
				var defer = $q.defer();
				p.success(function(response) {
					return defer.resolve(response);
				}).error(function() {
					return defer.reject();
				});
				return defer.promise;
			};
			return {
				//我的详细信息接口
				getMineMessage: function() {
					var url = Global.apiPath + '/mymessage/detail';
					return getPromise($http.get(url));
				},
				/**我的爱问*/
				getMyQuestion: function(item) {
					var url = Global.apiPath + '/mymessage/question/posted?startPage=' + item.startPage + '&pageSize=' + item.pageSize;
					return getPromise($http.get(url));
				},
				/**我的回答*/
				getMyAnswer: function(item) {
					var url = Global.apiPath + '/mymessage/question/answered?startPage=' + item.startPage + '&pageSize=' + item.pageSize;
					return getPromise($http.get(url));
				},
				/**我的关注*/
				getMyAttention: function(item) {
					var url = Global.apiPath + '/mymessage/question/followed?startPage=' + item.startPage + '&pageSize=' + item.pageSize;
					return getPromise($http.get(url));
				},
				/* 我的主页列表*/
				getMineFrameData: function(data){
					var url = Global.apiPath + '/mymessage/dynamics?' + $.param(data);
					return getPromise($http.get(url));
				},
				/* 与我相关 */
				getRelevanceData: function(data){
					var url = Global.apiPath + '/mymessage/relevance?' + $.param(data);
					return getPromise($http.get(url));
				},
				/*删除主页动态*/
				deleteMineData: function(data){
					var url = Global.apiPath + '/mymessage/dynamics/delete?' + $.param(data);
					return getPromise($http.get(url));
				},
				/**
				 * 我的私信列表
				 * @param {Object} data
				 */
				getMyPrivateMessageList:function(data){
					var url = Global.apiPath+'/mymessage/private-message/list?'+$.param(data);
					return getPromise($http.get(url));
				},
				/**私信会话的详细信息*/
				getMyPrivateMessageDetail:function(data){
					var url = Global.apiPath+'/mymessage/private-message/detail/'+data.empNumber +'?startPage='+data.startPage+'&pageSize='+data.pageSize;
					return getPromise($http.get(url));
				},
//				/**发送一条私信*/
//				sendPrivateMessage:function(data){
//					var url = Global.apiPath+'/mymessage/private-message/send?content='+data.content+'&receiverId='+data.receiverId;
//					return getPromise($http.get(url));
//				},
				/**发送一条私信*/
				sendPrivateMessage:function(data){
					var url = Global.apiPath+'/mymessage/private-message/send';
					return getPromise($.post(url, data));
				},
				/**
				 * 查看新的消息个数
				 */
				hasNewMessage:function(){
					var url = Global.apiPath+'/mymessage/message-box/unread-count';
					return getPromise($http.get(url));
				},
				getMineQuestion: function() {
					return askList = [{
						'questionID': '10000',
						'questionDate': '今天 19:42',
						'creator': '赵文杰',
						'askers': 1,
						'questionReward': 0,
						'questionImage': ['styles/images/2.jpg'],
						'questionValue': '什么是小样本事件?',
						'creatorWorkId': '02153',
						'isSlove': false,
						'creatorType': 'own'

					}, {
						'questionID': '10001',
						'questionDate': '今天 18:30',
						'creator': '李云辉',
						'askers': 1,
						'questionReward': 40,
						'questionImage': [],
						'questionValue': '前两天我和我的朋友去上海，碰见一个来奉天的朋友，他也是做程序的。我和他们交流，后发现他们貌似对我们的技术不是很了解...',
						'creatorWorkId': '02154',
						'isSlove': false,
						'creatorType': 'other'
					}, {
						'questionID': '10002',
						'questionDate': '2015-09-21 08:42',
						'creator': '李云辉',
						'askers': 2,
						'questionReward': 40,
						'questionImage': ['styles/images/2.jpg', 'styles/images/img_l1-1.jpg', 'styles/images/accept.png', 'styles/images/3.jpg', 'styles/images/head.jpg', 'styles/images/1.jpg'],
						'questionValue': '大家看看这是什么',
						'creatorWorkId': '02154',
						'isSlove': true,
						'creatorType': 'other'
					}];
				},
				getMineAttentionerData: function() {
					return attentionerData = [{
							'name': 'L刘秋庭',
							'workId': '659792',
							'firstLetter': 'L',
							'department': '行政办公研发中心'
						}, {
							'name': 'A张三',
							'workId': 'sfit0589',
							'firstLetter': 'A',
							'department': '研发管理部'
						}, {
							'name': 'B刘秋庭',
							'workId': '659793',
							'firstLetter': 'B',
							'department': '行政办公研发中心'
						}, {
							'name': 'C张三',
							'workId': 'sfit0580',
							'firstLetter': 'C',
							'department': '研发管理部'
						}, {
							'name': 'D刘秋庭',
							'workId': '659794',
							'firstLetter': 'D',
							'department': '行政办公研发中心'
						}, {
							'name': 'D张三',
							'workId': 'sfit0582',
							'firstLetter': 'D',
							'department': '研发管理部'
						}, {
							'name': 'D张三',
							'workId': 'sfit0582',
							'firstLetter': 'D',
							'department': '研发管理部'
						}, {
							'name': 'D张三',
							'workId': 'sfit0582',
							'firstLetter': 'D',
							'department': '研发管理部'
						}, {
							'name': 'D张三',
							'workId': 'sfit0582',
							'firstLetter': 'K',
							'department': '研发管理部'
						}, {
							'name': 'D张三',
							'workId': 'sfit0582',
							'firstLetter': 'D',
							'department': '研发管理部'
						}, {
							'name': 'D张三',
							'workId': 'sfit0582',
							'firstLetter': 'D',
							'department': '研发管理部'
						}

					]
				},
				/**
				 * 我的消息盒子
				 * @param {Object} data
				 */
				getMineMessageBoxInfo: function(data) {
					var url = Global.apiPath+'/mymessage/message-box?'+$.param(data);
					return getPromise($http.get(url));
				},
				//我的讨论
				getMineDiscuss: function(obj) {
					var url = Global.apiPath + "/mymessage/discussions?" + $.param(obj);
					return getPromise($http.get(url));
				},
				//我的收藏/mymessage/favorites
				getMineFavorites: function(obj) {
					var url = Global.apiPath + "/mymessage/favorites?" + $.param(obj);
					return getPromise($http.get(url));
				},
				getMineTalkListData: function(dataFactor) {
					console.log("service-dataFactor",dataFactor);
					var url = '';
					if(dataFactor.talkListKind == 'me'){
						url = Global.apiPath + "/mymessage/microblogs?startPage="+dataFactor.startPage+"&pageSize="+dataFactor.pageSize;
					}else if(dataFactor.talkListKind == 'ta'){
						// http://10.202.4.75:8180/KMS-MSERVER/usermessage/microblogs/{empNumber}						
						url = Global.apiPath + "/usermessage/microblogs/"+dataFactor.empNumber+"?startPage="+dataFactor.startPage+"&pageSize="+dataFactor.pageSize;
					}
					 
					return getPromise($http.get(url));
				},
				getMineLamsList: function(data) {
					var url = '';
					if(data.meOrTa == 'me'){
						url = Global.apiPath + "/mymessage/leave-message?"+$.param(data.param);
					}else{
						url = Global.apiPath + "/usermessage/leave-message/"+data.empNumber+"?"+$.param(data.param);
					}
					return getPromise($http.get(url));
				},
				saveMineLamsItem: function(data) {
					var url = '';
					if(data.meOrTa == 'me'){
						url = Global.apiPath + "/leavemessage/save?"+$.param(data.param);
					}else{
						url = Global.apiPath + "/leavemessage/save?"+$.param(data.param);
					}
					return getPromise($http.get(url));
				},
				sendToMessagebox: function(data) {
					var url = '';
					if(data.meOrTa == 'me'){
						url = Global.apiPath + "/leavemessage/save?"+$.param(data.param);
					}else{
						url = Global.apiPath + "/leavemessage/save?"+$.param(data.param);
					}
					return getPromise($http.get(url));
				},
				deleteMineLamsItem: function(data) {
					var url = '';
					if(data.meOrTa == 'me'){
						url = Global.apiPath + "/leavemessage/delete/"+data.param.leaveMessageId;
					}else{
						url = Global.apiPath + "/leavemessage/delete/"+data.param.leaveMessageId;
					}
					return getPromise($http.get(url));
				},
				getMineAttentionFansData: function(dataFactor) {
					if(dataFactor.searchRealKind=='allPerson'){
						console.log("搜索所有的人!");
						// 搜索全网的人http://10.202.4.75:8180/KMS-MSERVER/usermessage/user/search		
						var url = Global.apiPath + "/usermessage/user/search?startPage="+dataFactor.startPage+"&pageSize="+dataFactor.pageSize+"&searchKey="+dataFactor.searchKey;
					}else if(dataFactor.isFansKind){
						// 是我的粉丝// http://10.202.4.75:8180/KMS-MSERVER/mymessage/fans	
						var url = Global.apiPath + "/mymessage/fans?startPage="+dataFactor.startPage+"&pageSize="+dataFactor.pageSize+"&searchKey="+dataFactor.searchKey;
					}else{
						// 是我的关注 http://10.202.4.75:8180/KMS-MSERVER/mymessage/attention/persons						
						var url = Global.apiPath + "/mymessage/attention/persons?startPage="+dataFactor.startPage+"&pageSize="+dataFactor.pageSize+"&searchKey="+dataFactor.searchKey;
					}
					//在这里应该根据得到的dataFactor数据进行不同的操作
					
					return getPromise($http.get(url));
				},
				FollowOrUnfollowTa:function(data){
					//关注某人：http://10.202.4.75:8180/KMS-MSERVER/attention/follow/person/{targetUserId}						
					// 取消关注某人：http://10.202.4.75:8180/KMS-MSERVER/attention/cancel-follow/person/{targetUserId}		
					var url ="";
					if(data.action=="follow"){
						// 动作：关注某人
						 url = Global.apiPath+"/attention/follow/person/"+data.userId;
					}else{
						// 取消关注某人
						url = Global.apiPath+"/attention/cancel-follow/person/"+data.userId;
					}
					return getPromise($http.get(url));
					
				},
				/*保存我的说说*/
				saveMineWrites: function(data){
					var url = Global.apiPath+'/microblog/publish?content='+data.content+'&images='+data.images;
					return getPromise($http.get(url));
				},
				/*获取说说详情*/
				getTalkDetail: function(data){
					var url = Global.apiPath+'/microblog/viewDetail/'+data.param.microblogId;
					return getPromise($http.get(url));
				},
				/*删除说说详情*/
				deleteTalkDetail: function(data){
					var url = Global.apiPath+'/microblog/delete/'+data.param.microblogId;
					return getPromise($http.get(url));
				},
				/*评论说说详情*/
				replyTalkDetail: function(data){
					var url = Global.apiPath+'/microblog/comment/save?'+$.param(data.param);
					return getPromise($http.get(url));
				},
				/*删除说说评论*/
				deleteTalkReply: function(data){
					var url = Global.apiPath+'/microblog/comment/delete/'+data.param.commentId;
					return getPromise($http.get(url));
				},
				/*点赞说说详情*/
				praiseTalkDetail: function(data){
					var url = Global.apiPath+'/microblog/'+(data.isCancel?'cancel-praise':'praise')+'/'+data.param.microblogId;
					return getPromise($http.get(url));
				},

			};
		}
	]);
});