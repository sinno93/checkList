'use strict';
try {
  angular.module('ECPMobile.global', [])
      .factory('Global', function () {
        return {

          apiPath : "http://10.118.104.93:9090/aspmanager"

        };
      });
} catch (e) {
  window.apiPath = "http://10.118.104.93:9090";
}