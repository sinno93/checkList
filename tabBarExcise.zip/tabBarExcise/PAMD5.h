//
//  StringUtil.h
//  FXTool
//
//  Created by 房杨平 on 11-8-18.
//  Copyright 2011 EmatChina. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonDigest.h> 


@interface PAMD5 : NSObject {

}
/**
 *  计算字符串的MD5
 *
 *  @param str 要计算的字符串
 *
 *  @return MD5值(32位)
 */
+ (NSString *) md5:(NSString *)str;

/**
 *  计算文件的MD5
 *
 *  @param file 要计算MD5的文件路径
 *
 *  @return MD5值(8位)
 */
+ (NSString *) md5ForFileContent:(NSString *)file;

/**
 *  计算NSData的MD5
 *
 *  @param data 要计算的NSData
 *
 *  @return MD5值(8)位
 */
+ (NSString *) md5ForData:(NSData *)data;

@end
