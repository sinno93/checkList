//
//  zqdCacheManager.h
//  tabBarExcise
//
//  Created by 郑庆登(King Zheng)-企业内部系统研发中心 on 16/1/26.
//  Copyright © 2016年 郑庆登(Qingdeng Zheng)-IT服务中心. All rights reserved.
//

#import <Foundation/Foundation.h>
/**
 *  缓存逻辑的主要实现类 
 *  1.下载webVersion、manifest 
 *  2.判断文件是否需要缓存
 *  3.判断沙盒中的文件是否是最新
 *  4.更新沙盒中的文件
 */
@interface zqdCacheManager : NSObject

@property NSDictionary* appInfo; // 服务号信息
@property NSString* host;
@property NSString* rootDirectory;// 根目录
@property (strong) void (^loadWebViewWithURL)(NSString *path);
@property (strong) void (^beginLoadFile)();
@property NSString*accessFile;//入口地址
@property NSDictionary *webVersionDic;//从webVersion.json中获取的字典
@property NSDictionary *manifestDic;  //从manifest.json中获取的字典
@property(nonatomic, strong) NSMutableDictionary *shortUrlDic;//由manifestDic 得到的短路径-MD5字典
@property(nonatomic, strong)NSMutableArray *shortUrlArray;
-(void)prepareToLoadWebView:(void (^)(NSString *path))loadBlock;
+ (zqdCacheManager*)share;
-(void)initializedWithAppInfo:(NSDictionary*)appInfo andHost:(NSString*)host;
-(void)initWebVersion;
-(BOOL)shouldBeHandledWithUrl:(NSURL *)url;
-(NSString*)getShortUrlStrWithUrl:(NSURL *)url;
+(void)handleShortUrlStr:(NSString*)shortUrlStr andReturn:(void (^)(NSString *path))loadFile;
@end
