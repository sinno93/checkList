//
//  myURLProtocol.m
//  tabBarExcise
//
//  Created by 郑庆登(King Zheng)-企业内部系统研发中心 on 16/1/19.
//  Copyright © 2016年 郑庆登(Qingdeng Zheng)-IT服务中心. All rights reserved.
//

#import "myURLProtocol.h"
#import "zqdownload.h"
#define ECP_loadUrl  @"http://218.17.248.244:4280/5a3d7a70c66e4194add37263894f5387cf0b9d9492f14d79b7ee59c485a22d72/www"
@implementation myURLProtocol
{
    BOOL i;
}
+ (BOOL)canInitWithRequest:(NSURLRequest*)theRequest{
    [theRequest.URL resourceSpecifier];
    if ([NSURLProtocol propertyForKey:@"MyURLProtocolHandledKey" inRequest:theRequest]) {
        return NO;
    }
//    NSArray *pathArray = [theRequest.URL.absoluteString componentsSeparatedByString:@"/www/"];
//    if([pathArray count]<2){
//        return NO;
//    }
    return YES;
}
+ (NSURLRequest *)canonicalRequestForRequest:(NSURLRequest *)request
{
      return request;
}
// 开始加载 在此判断是否已经缓存，若已经缓存，直接使用缓存文件即可
// 若没有缓存 则去相应的地址取数据并返回
- (void)startLoading {
    NSMutableURLRequest *newRequest = [self.request mutableCopy];
    [newRequest setTimeoutInterval:200];
    [NSURLProtocol setProperty:@YES forKey:@"MyURLProtocolHandledKey" inRequest:newRequest];
    // 短网址
    NSMutableString *shortUrlStr = [NSMutableString string];
    if([newRequest.URL.absoluteString componentsSeparatedByString:@"/www/"].count>1){
        shortUrlStr = [[newRequest.URL.absoluteString componentsSeparatedByString:@"/www/"][1] mutableCopy];
    }else{
        self.connection = [[NSURLConnection alloc]initWithRequest:newRequest delegate:self startImmediately:YES];
        return;
    }
    
    // 若缓存文件中存在
    if([myURLProtocol isFileExist:shortUrlStr]){
        NSString *newPath = [NSString stringWithFormat:@"%@/www/%@",[myURLProtocol documentsDirectory],shortUrlStr ];
        [newRequest setURL:[NSURL fileURLWithPath:newPath]];
        self.connection = [[NSURLConnection alloc]initWithRequest:newRequest delegate:self startImmediately:YES];
        return;
        NSString *urlStr = [newRequest.URL.absoluteString componentsSeparatedByString:@"/www/"][1];
        NSString *memiType = [self mimeTypeForPath:newRequest.URL.absoluteString];
        NSURLResponse *response = [[NSURLResponse alloc] initWithURL:[newRequest URL]
                                                            MIMEType:memiType
                                               expectedContentLength:-1
                                                    textEncodingName:nil];
        
        // 若有的话 应该可以获取到文件的内容
        NSData *data = [NSData dataWithContentsOfFile:[myURLProtocol getFilePathAndNameByUrlStr:shortUrlStr]];
        NSString *dataStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"%@",dataStr);
        [[self client] URLProtocol:self didReceiveResponse:response cacheStoragePolicy:NSURLCacheStorageNotAllowed]; // we handle caching ourselves.
        [[self client] URLProtocol:self didLoadData:data];
        [[self client] URLProtocolDidFinishLoading:self];
        return;

    
    } // cordova.js文件
    if([newRequest.URL.absoluteString rangeOfString:@"cordova.js"].length>0){
        NSString *memiType = @"application/x-javascript";
        NSURLResponse *response = [[NSURLResponse alloc] initWithURL:[newRequest URL]
                                                            MIMEType:memiType
                                               expectedContentLength:-1
                                                    textEncodingName:nil];
//        NSCachedURLResponse *cachedResponse = [[NSCachedURLResponse alloc] initWithResponse:response data:fileData];
        NSURL *cordovaUrl = [[NSBundle mainBundle] URLForResource:@"cordova" withExtension:@"js"];
        NSData *data = [NSData dataWithContentsOfFile:cordovaUrl];
        [[self client] URLProtocol:self didReceiveResponse:response cacheStoragePolicy:NSURLCacheStorageNotAllowed]; // we handle caching ourselves.
        [[self client] URLProtocol:self didLoadData:data];
        [[self client] URLProtocolDidFinishLoading:self];
        return;
    }// 包含组件里的东西...
    if([newRequest.URL.absoluteString rangeOfString:@"/components/"].length>0){
        NSString *memiType = [self mimeTypeForPath:newRequest.URL.absoluteString];
        NSURLResponse *response = [[NSURLResponse alloc] initWithURL:[newRequest URL]
                                                            MIMEType:memiType
                                               expectedContentLength:-1
                                                    textEncodingName:nil];
        // 分隔components
        NSString *shortPath = [newRequest.URL.absoluteString componentsSeparatedByString:@"/components/"][1];
        NSString *headPath = [shortPath componentsSeparatedByString:@"."][0];
        NSString *suffix = [shortPath componentsSeparatedByString:@"."][1];
        NSString *comPath = [[NSBundle mainBundle] pathForResource:headPath ofType:suffix inDirectory:@"components"];
//        NSURL *cordovaUrl = [[NSBundle mainBundle] URLForResource:@"cordova" withExtension:@"js"];
        NSData *data = [NSData dataWithContentsOfFile:comPath];
        [[self client] URLProtocol:self didReceiveResponse:response cacheStoragePolicy:NSURLCacheStorageNotAllowed]; // we handle caching ourselves.
        [[self client] URLProtocol:self didLoadData:data];
        [[self client] URLProtocolDidFinishLoading:self];
        return;
    }
    NSString *urlString = newRequest.URL.absoluteString;
    // 来到这里，说明没有被缓存过，而且不是cordova.js和components里面的东西
    // 判断是否是需要缓存的东西
    if([myURLProtocol isToCacheWithUrlStr:urlString]){
        // 要缓存的东西，则去下载 并且存在合适的位置
        NSString *downLoadUrlStr = [NSString stringWithFormat:@"%@/%@",ECP_loadUrl,shortUrlStr ];
        [zqdownload downloadWithURL:downLoadUrlStr complete:^(NetState state, NSData *data) {
            if(state == success){
                NSString *path = [NSString string];
                if ([shortUrlStr rangeOfString:@"cordova"].length>0) {
                    NSLog(@"get cordova");
                }
                if([shortUrlStr rangeOfString:@".woff"].length>0){
                  NSString* shortUrlStr2 = [shortUrlStr componentsSeparatedByString:@"?"][0];
                    path = [myURLProtocol getProperFilePathWithShortUrl:shortUrlStr2];
                }else{
                     path = [myURLProtocol getProperFilePathWithShortUrl:shortUrlStr];
                }
               self->i = [data writeToFile:path atomically:YES];
                
                self.connection = [[NSURLConnection alloc]initWithRequest:newRequest delegate:self startImmediately:YES];
            }
        }];
    }else self.connection = [[NSURLConnection alloc]initWithRequest:newRequest delegate:self startImmediately:YES];
//    self.connection = [NSURLConnection connectionWithRequest:newRequest delegate:self];
}
+(BOOL)isToCacheWithUrlStr:(NSString*)urlString{

    return  [ urlString hasSuffix:@".html"]||[urlString hasSuffix:@".js"]||[urlString hasSuffix:@".css"]||([urlString rangeOfString:@".woff?"].length>0)||([urlString rangeOfString:@".svg"].length>0)||([urlString rangeOfString:@".ttf"].length>0)||[urlString hasSuffix:@".png"];

}
-(void)begin:(NSURLConnection *)connection{
    connection.start;
}
- (NSString *)mimeTypeForPath:(NSString *)originalPath  {
    if ([originalPath hasSuffix:@".png"]) {
        return @"image/png";
    } else if ([originalPath hasSuffix:@".jpeg"]) {
        return @"image/jpeg";
    }else if ([originalPath hasSuffix:@".jpg"]) {
        return @"image/jpg";
    }else if ([originalPath hasSuffix:@".gif"]) {
        return @"image/gif";
    }
    else if ([originalPath hasSuffix:@".js"]) {
        return @"application/x-javascript";
    }
    else if ([originalPath hasSuffix:@".css"]) {
        return @"text/css";
    } else if([originalPath hasSuffix:@".html"]){
        return @"text/html";
    }else if([originalPath rangeOfString:@".woff"].length>0){
        return @"application/font-woff";
    }else if([originalPath rangeOfString:@".ttf"].length>0){
        return @"application/x-font-truetype";
    }else if([originalPath rangeOfString:@".svg"].length>0){
        return @"image/svg+xml";
    }
    else return @"unknow";
}
- (void)stopLoading
{
    [self.connection cancel];
    self.connection = nil;
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    self.responseData = [[NSMutableData alloc] init];
    [self.client URLProtocol:self didReceiveResponse:response cacheStoragePolicy:NSURLCacheStorageNotAllowed];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    [self.responseData appendData:data];
    [self.client URLProtocol:self didLoadData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
     NSString *urlStr = connection.currentRequest.URL.absoluteString;
    [self.client URLProtocolDidFinishLoading:self];
}
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    [self.client URLProtocol:self didFailWithError:error];
    
    NSLog(@"myURLProtocol error:%@", [error localizedDescription]);
}
+ (NSString*)stringFormat:(NSString*)oriStr{
    NSMutableString *curStr =[[NSMutableString alloc] initWithString:[oriStr stringByReplacingOccurrencesOfString:@"." withString:@"_"]];
    curStr = [[NSMutableString alloc] initWithString:[curStr stringByReplacingOccurrencesOfString:@"/" withString:@"_"]];
    curStr = [[NSMutableString alloc] initWithString:[curStr stringByReplacingOccurrencesOfString:@":" withString:@"_"]];
    return curStr;
}
// 为了通过https验证
- (BOOL)connection:(NSURLConnection *)connection canAuthenticateAgainstProtectionSpace:(NSURLProtectionSpace *)protectionSpace
{
    NSLog(@"验证。。。%@",connection);
    return [protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust];
}

- (void)connection:(NSURLConnection *)connection didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge {
    if ([challenge.protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust]){
        [[challenge sender]  useCredential:[NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust] forAuthenticationChallenge:challenge];
        [[challenge sender]  continueWithoutCredentialForAuthenticationChallenge: challenge];
    }
}
// 返回错误日志所在的目录
+(NSString *)getFilePathAndNameByUrlStr:(NSString*)str{
    NSString*filePath = [NSString stringWithFormat:@"%@/%@",[myURLProtocol documentsDirectory],str];
    return filePath;
    
}
// 判断文件是否存在了
+(BOOL)isFileExist:(NSString*)urlStr{
    
    NSFileManager *filemanager = [NSFileManager defaultManager];
    BOOL mark =  [filemanager fileExistsAtPath:[self getFilePathAndNameByUrlStr:[NSString stringWithFormat:@"www/%@",urlStr]]];
    return mark;
}
+(NSString*)getProperFilePathWithShortUrl:(NSString*)str{
    // 还是要返回目录地址比较好
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSMutableString *returnFilePath = [NSMutableString string];
    NSArray *fileArr = [str componentsSeparatedByString:@"/"];
    if (fileArr.count>1) {
        NSMutableString *fileRealPath = [[NSMutableString alloc]initWithString:[self documentsDirectory]];
        [fileRealPath appendFormat:@"/www"];
        NSMutableArray *fileMutArr = [fileArr mutableCopy];
        [fileMutArr removeLastObject];
        for(NSString*filePath in fileMutArr){
            [fileRealPath appendFormat:@"/%@",filePath];
        }
        BOOL dirExist = [fileManager fileExistsAtPath:fileRealPath];
        if(!dirExist){ // 文件夹不存在
            BOOL create = [fileManager createDirectoryAtPath:fileRealPath withIntermediateDirectories:YES attributes:nil error:nil];
            [fileRealPath appendFormat:@"/%@",fileArr.lastObject ];
            if(create)return fileRealPath;
            else return nil;
        }else{
            // 文件夹存在
            [fileRealPath appendFormat:@"/%@",fileArr.lastObject];
            return fileRealPath;
        }
    }else{
        // 不是目录 直接返回根目录即可
        [returnFilePath appendFormat:@"%@/www/%@",[self documentsDirectory],fileArr[0] ];
        return returnFilePath;
    }
}
+(NSString *)getFilePath:(NSString*)url{
    return [[self getCacheDirectory]stringByAppendingPathComponent:url];
}
+(NSString*)getCacheDirectory{
    return [[self documentsDirectory]stringByAppendingPathComponent:@"MyCache"];
}
// Documents目录所在的位置
+(NSString*)documentsDirectory{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths firstObject];
    return documentsDirectory;
}
+ (NSString*)getFileNameByUrlStr:(NSString *)urlStr{
    NSMutableString* fileName = [urlStr mutableCopy];
    fileName = [[fileName stringByReplacingOccurrencesOfString:@":" withString:@"_"] mutableCopy];
    fileName = [[fileName stringByReplacingOccurrencesOfString:@"/" withString:@"_"] mutableCopy];
    fileName = [[fileName stringByReplacingOccurrencesOfString:@"." withString:@"_"] mutableCopy];
    return fileName;
    
}
@end
