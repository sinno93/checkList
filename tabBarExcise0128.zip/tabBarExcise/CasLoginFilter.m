//
//  CasLoginFilter.m
//  SFExpressApp
//
//  Created by hongy on 14-5-28.
//  Copyright (c) 2014年 Neusoft. All rights reserved.
//

#import "CasLoginFilter.h"
#import "ConstHeader.h"
#import "TFHpple.h"

@implementation CasLoginFilter

-(BOOL)attachCookies:(NSURL *) url withCookies:(NSMutableArray*) cookies{
    
    BOOL rtn = NO;
    NSMutableArray *newCookies = [[NSMutableArray alloc] init];
    for (NSHTTPCookie *cookie in cookies) {
        NSDictionary *properties =  [NSDictionary dictionaryWithObjectsAndKeys:
                                     [cookie value],NSHTTPCookieValue,
                                     [cookie name], NSHTTPCookieName,
                                     @"/" , NSHTTPCookiePath,
                                     [url host] ,NSHTTPCookieDomain, nil];
        NSHTTPCookie *cookie_PD1 = [NSHTTPCookie cookieWithProperties:properties];
        [newCookies addObject:cookie_PD1];
        rtn = YES;
    }
    [[NSHTTPCookieStorage sharedHTTPCookieStorage] setCookies:newCookies forURL:url mainDocumentURL:nil];
    return rtn;
}


-(BOOL)attachLoginCookies:(NSURL *) url {
    return [self attachCookies:url withCookies: [NSMutableArray arrayWithArray:[self loadLoginCookies]]];
}
+ (NSString*)getPreferredLanguage
{
    NSUserDefaults* defs = [NSUserDefaults standardUserDefaults];
    NSArray* languages = [defs objectForKey:@"AppleLanguages"];
    NSString* preferredLang = [languages objectAtIndex:0];
    NSLog(@"Preferred Language:%@", preferredLang);
    return preferredLang;
}
-(NSString*) getToken{
    NSArray* cookies = [self loadLoginCookies];
    for (NSHTTPCookie *cookie in cookies) {
        if ([[cookie name] isEqualToString:@"CASTGC"]) {
            return [cookie value];
        }
    }
    return @"";
}

-(void) userLogin:(NSString*) userName passWord:(NSString*) pwd{

    requestStep = 1;
    lastUser = userName;
    lastPassword = pwd;
    
    // clear cookies
    NSHTTPCookieStorage * sharedCookieStorage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    NSArray * cookies = [sharedCookieStorage cookies];
    for (NSHTTPCookie * cookie in cookies)
    {
        [sharedCookieStorage deleteCookie:cookie];
    }
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kSessionCookie];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kLoginCookie];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kWidgetCookie];
    //CAS登录 判断不同的语言
    NSString *lngurl = kLoginLanguageCNUrl;
//    if ([[CasLoginFilter getPreferredLanguage] isEqualToString:@"zh-Hans"]) {
//        lngurl = kLoginLanguageCNUrl;
//    }else if([[CasLoginFilter getPreferredLanguage] isEqualToString:@"zh-Hant"] || [[CasLoginFilter getPreferredLanguage] isEqualToString:@"zh-HK"]) {
//        lngurl = kLoginLanguageTWUrl;
//    }else {
//        lngurl = kLoginLanguageUSUrl;
//    }
    NSString *url = ACTION_LOGIN_URL;
    fromUrl = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",url,lngurl]];
//    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
//    [request setURL:fromUrl];
//    [request setHTTPMethod:@"POST"];
//    [request setTimeoutInterval:kIgnoreCookie];
//    receiveData = [[NSMutableData alloc] initWithLength:0];
//    [NSURLConnection connectionWithRequest:request delegate:self];
    
    
    
   
    //第二步，创建请求
    NSURLRequest *request = [[NSURLRequest alloc]initWithURL:fromUrl cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:10];
    //第三步，连接服务器
    NSURLConnection *connection = [[NSURLConnection alloc]initWithRequest:request delegate:self];
    receiveData = [[NSMutableData alloc] initWithLength:0];
    
    return ;
}

-(BOOL) isLoginOKPage{
    if ([responseContent rangeOfString:@"<h2>登录成功</h2>"].location != NSNotFound) {
        return YES;
    }
    return NO;
}
-(NSDictionary*) reAuth:(NSString*) user passWord:(NSString*) pass{
    NSMutableDictionary* rtn = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithBool:NO] ,@"isLoginSuccess",
                         @"",@"message",
                         nil];
    requestStep = 2;
    // 第一次登录
    if ([self  isLoginOKPage]) {
        NSMutableDictionary* rtn = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithBool:YES] ,@"isLoginSuccess",
                                    @"",@"message",
                                    nil];

        [self.loginDeleage didUserLogin:YES retunMesssage:rtn];
        return rtn;
    }
    // 第二次登录 获取lt
    NSString* lt = [self retriveLT];
    if([lt length]>0){
        NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
        [request setURL:fromUrl];
        [request setHTTPMethod:@"POST"];
        NSMutableData *postBody = [NSMutableData data];

        NSString *encodedPasswordValue = (NSString*)CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(nil,
                                                                                                              (CFStringRef)pass, nil,
                                                                                                              (CFStringRef)@"!*'();:@&=+$,/?%#[]", kCFStringEncodingUTF8));
        
        NSString *additional = [NSString stringWithFormat:@"%@|%@",user,encodedPasswordValue];
        
        [postBody appendData:[[NSString stringWithFormat:@"lt=%@&username=%@&password=%@&additional=%@&_eventId=submit&submit=submit",lt,user,encodedPasswordValue,additional] dataUsingEncoding:NSUTF8StringEncoding]];
        NSMutableArray *newCookies = [[NSMutableArray alloc] init];
        for (NSHTTPCookie *cookie in lastCookies) {
            NSDictionary *properties =  [NSDictionary dictionaryWithObjectsAndKeys:
                                         [cookie value],NSHTTPCookieValue,
                                         [cookie name], NSHTTPCookieName,
                                         @"/" , NSHTTPCookiePath,
                                         [fromUrl host] ,NSHTTPCookieDomain, nil];
        
            NSHTTPCookie *cookie_PD1 = [NSHTTPCookie cookieWithProperties:properties];
            [newCookies addObject:cookie_PD1];
        }
        [[NSHTTPCookieStorage sharedHTTPCookieStorage] setCookies:newCookies forURL:fromUrl mainDocumentURL:nil];
        [request setHTTPBody:postBody];
        [NSURLConnection connectionWithRequest:request delegate:self];
        
    }else{
        [rtn setValue:[NSNumber numberWithBool:NO]  forKey:@"isLoginSuccess"];
        [rtn setValue:@"Server error" forKey:@"message"];
        NSLog(@"server error resp:%@",responseContent);
        [self.loginDeleage didUserLogin:NO retunMesssage:rtn];
    }
    return rtn;
}

-(void) setLoginCookieForDomain:(NSString*) domain withPath:(NSString*)path inUrl:(NSURL*) url
{
    NSArray* cookies = [self loadLoginCookies];
    NSMutableArray *newCookies = [[NSMutableArray alloc] init];

    for (NSHTTPCookie *cookie in cookies) {
        
        NSDictionary *properties =  [NSDictionary dictionaryWithObjectsAndKeys:
                                     [cookie value],NSHTTPCookieValue,
                                     [cookie name], NSHTTPCookieName,
                                     path , NSHTTPCookiePath,
                                     domain,NSHTTPCookieDomain, nil];
        
        NSHTTPCookie *cookie_PD1 = [NSHTTPCookie cookieWithProperties:properties];
        if([[cookie name] isEqual:@"CASTGC"]) {
            NSLog(@"Found token cookie : %@",[cookie_PD1 description]);
            [newCookies addObject:cookie];

        }
        else {
            [newCookies addObject:cookie_PD1];

        }
    }
    [[NSHTTPCookieStorage sharedHTTPCookieStorage] setCookies:newCookies forURL:url mainDocumentURL:nil];
    NSLog(@"＋＋＋＋＋——————————————————————————————————————＋＋＋＋＋＋＋＋＋%@",url);
}

-(NSString*) getMessage:(NSString*) respStr{
    NSString *rtn = nil;
    TFHpple * doc = [TFHpple hppleWithHTMLData:[respStr dataUsingEncoding:NSUTF8StringEncoding]];
    NSArray * elements  = [doc searchWithXPathQuery:kXPathMessage];
    if([elements count]>0){
        TFHppleElement * element = [elements objectAtIndex:0];
        rtn =  [element text];
    }

    return  rtn;
}
-(BOOL) isLoginValid:(NSArray*) cookies{
    BOOL rtn = NO;
    for (NSHTTPCookie *cookie in cookies) {
        if ([[cookie name] isEqualToString:@"CASTGC"]) {
            rtn = YES;
            break;
        }
    }
    return rtn;
}


-(NSString*) retriveLT{
    
    TFHpple * doc = [TFHpple hppleWithHTMLData:[responseContent dataUsingEncoding:NSUTF8StringEncoding]];
    NSArray * elements  = [doc searchWithXPathQuery:kXPathLT];
    if ([elements count]>0) {
        TFHppleElement * element = [elements objectAtIndex:0];
        return [element text];
    }
    return nil;
   
}

-( void) replaceSavedCookieWithName:(NSHTTPCookie*) newCookie {
    NSArray* savedCookies =[self loadLoginCookies];
    NSArray* newCookies = [self replaceCookie:savedCookies WithName:newCookie];
    [self saveLoginCookies:newCookies];
}

-(NSArray*) replaceCookie:(NSArray*) originalCookies WithName:(NSHTTPCookie*) newCookie{
    BOOL found = NO;
    NSMutableArray *target = [[NSMutableArray alloc] init];
    for(NSHTTPCookie* cookie in originalCookies){
        if ([[cookie name] isEqual:[newCookie name]]) {
            found = YES;
            [target addObject:newCookie];
        }else{
            [target addObject:cookie];
        }
    }
    if (found==NO) {
        [target addObject:newCookie];
    }
    return [NSArray arrayWithArray:target];
}


-(void) saveUserName:(NSString*) userName{
    [[NSUserDefaults standardUserDefaults] setObject:userName forKey:@"username"];
}
+(NSString*) loadUserName{
   return  [[NSUserDefaults standardUserDefaults] objectForKey:@"username"];
}
-(NSArray*) loadLoginCookies{
    NSData *cookiesdata = [[NSUserDefaults standardUserDefaults] objectForKey:kLoginCookie];
    NSArray *cookies = nil;
    
    if([cookiesdata length]) {
        cookies = [NSKeyedUnarchiver unarchiveObjectWithData:cookiesdata];
        
    }
    return cookies;
}

-(BOOL) NSHTTPCookie:(NSArray*)cookies{
    NSHTTPCookie* found = nil;
    
    for(NSHTTPCookie* c in cookies){
        if ([[c name] isEqualToString:@"CASTGC"]) {
            found = c;
        }
    }
    
    if (found != nil) {
        NSArray *cs = [self replaceCookie:[self loadLoginCookies] WithName:found];
        NSData *data = [NSKeyedArchiver archivedDataWithRootObject:cs];
        [[NSUserDefaults standardUserDefaults] setObject:data forKey:kLoginCookie];
         [[NSUserDefaults standardUserDefaults]setObject:found.value forKey:@"CAS_COOKIE"];
        return YES;
    }else{
        return NO;
    }
   
}
-(BOOL) saveSessionCookie:(NSArray*)cookies {
    NSHTTPCookie* found = nil;
    NSString *host = LOGIN_WS_HOST;
    for(NSHTTPCookie* c in cookies){
        if ([[[c name] lowercaseString] rangeOfString:@"sessionid"].location != NSNotFound && [[c domain] rangeOfString:host].location != NSNotFound) {
            found = c;
        }
    }

    if (found != nil) {
        NSArray *cs = [self replaceCookie:[self loadLoginCookies] WithName:found];
        NSData *data = [NSKeyedArchiver archivedDataWithRootObject:cs];
        [[NSUserDefaults standardUserDefaults] setObject:data forKey:kLoginCookie];
        
        return YES;
    }else{
        return NO;
    }

}
//-(BOOL) saveAspSessionCookie:(NSArray*)cookies {
//    NSHTTPCookie* found = nil;
//    NSString *host = ASP_LOGIN_WS_HOST;
//    for(NSHTTPCookie* c in cookies){
//        if ([[[c name] lowercaseString] rangeOfString:@"sessionid"].location != NSNotFound && [[c domain] rangeOfString:host].location != NSNotFound) {
//            found = c;
//        }
//    }
//    
//    if (found != nil) {
//        NSArray *cs = [self replaceCookie:[self loadLoginCookies] WithName:found];
//        NSData *data = [NSKeyedArchiver archivedDataWithRootObject:cs];
//        [[NSUserDefaults standardUserDefaults] setObject:data forKey:kLoginCookie];
//        
//        return YES;
//    }else{
//        return NO;
//    }
//    
//}
-(BOOL) saveServerCookie:(NSArray*)cookies {
    
    NSHTTPCookie* found = nil;
    NSString *host = LOGIN_WS_HOST;
    for(NSHTTPCookie* c in cookies)
    {
        if ([[[c name] lowercaseString] rangeOfString:@"serverid"].location != NSNotFound && [[c domain] rangeOfString:host].location != NSNotFound) {
            found = c;
        }
    }
    if (found != nil) {
        NSArray *cs = [self replaceCookie:[self loadLoginCookies] WithName:found];
        NSData *data = [NSKeyedArchiver archivedDataWithRootObject:cs];
        [[NSUserDefaults standardUserDefaults] setObject:data forKey:kLoginCookie];
        return YES;
    }else{
        return NO;
    }
}

-(void) saveLoginCookies:(NSArray*)cookies
{
    [self NSHTTPCookie:cookies];
    [self saveSessionCookie:cookies];
    [self saveServerCookie:cookies];
}

+(BOOL) isRedirectToLoginPage:(NSString*) content{

    BOOL rtn = NO;
    
    TFHpple * doc = [TFHpple hppleWithHTMLData:[content dataUsingEncoding:NSUTF8StringEncoding]];
    NSArray * elements  = [doc searchWithXPathQuery:kXPathLT];
    if ([elements count]>0) {
        TFHppleElement * element = [elements objectAtIndex:0];
        NSString *lt = [element text];
        if ([lt length]>0) {
            rtn = YES;
        }
    }
    return rtn;
    
}

- (BOOL)connection:(NSURLConnection *)connection canAuthenticateAgainstProtectionSpace:(NSURLProtectionSpace *)protectionSpace
{
    return [protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust];
}

- (void)connection:(NSURLConnection *)connection didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge {
    if ([challenge.protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust]){
        [[challenge sender]  useCredential:[NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust] forAuthenticationChallenge:challenge];
        [[challenge sender]  continueWithoutCredentialForAuthenticationChallenge: challenge];
    }
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    NSHTTPURLResponse* http =  (NSHTTPURLResponse*)response;
    NSInteger code = [http statusCode];
    NSLog(@"url is %@", [http URL]);
    NSLog(@"status code is %ld", (long)code);
    
    if (code != 200)
    {
//        UIAlertView *loading = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Faied_To_Send_Request",nil)
//                                                          message:nil delegate:nil cancelButtonTitle:@"取消" otherButtonTitles: nil];
//        [loading show];
    }
}

- (void)connection:(NSURLConnection *)aConn didReceiveData:(NSData *)data
{
    [receiveData appendData:data];
}

- (void)connection:(NSURLConnection *)aConn didFailWithError:(NSError *)error{
    NSMutableDictionary* rtn = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithBool:NO] ,@"isLoginSuccess",[error localizedDescription]
                                ,@"message",nil];
        [self.loginDeleage didUserLogin:NO retunMesssage:rtn];
}

// 全部数据接收完毕时触发
- (void)connectionDidFinishLoading:(NSURLConnection *)aConn{
    NSMutableDictionary* rtn = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithBool:NO] ,@"isLoginSuccess",[NSNumber numberWithBool:NO]
                                ,@"message", nil];
    NSData* returnData = [NSData dataWithData:receiveData];
    responseContent = [[NSString alloc] initWithData:returnData encoding:NSUTF8StringEncoding];
    lastCookies = [[NSHTTPCookieStorage sharedHTTPCookieStorage] cookiesForURL:fromUrl];
    
    if (!returnData)
    {
        [rtn setObject:[NSNumber numberWithBool:NO]  forKey:@"isLoginSuccess"];
    }
    else if(requestStep==1)
    {
        [rtn setObject:[NSNumber numberWithBool:YES] forKey:@"isLoginSuccess"];
        [self reAuth:lastUser passWord:lastPassword];
        return;
    }
    else if (requestStep == 2)
    {
        NSLog(@"%@",[[NSString alloc] initWithData:returnData encoding:NSUTF8StringEncoding]);
        
        NSArray* loginRespCookies = [[NSHTTPCookieStorage sharedHTTPCookieStorage] cookiesForURL:fromUrl];
        if ([self isLoginValid:loginRespCookies])
        {
            [self saveLoginCookies:loginRespCookies];
            [rtn setValue:[NSNumber numberWithBool:YES] forKey:@"isLoginSuccess"];
        }
        else
        {
            [rtn setValue:[NSNumber numberWithBool:NO]  forKey:@"isLoginSuccess"];
            [rtn setValue:[self getMessage:[[NSString alloc] initWithData:returnData encoding:NSUTF8StringEncoding]] forKey:@"message"];
        }
    }
    if (requestStep == 2) {
        [self.loginDeleage didUserLogin:YES retunMesssage:rtn];
    }
}

@end
