//
//  ConstHeader.h
//  SFExpressApp
//
//  Created by hongy on 14-5-28.
//  Copyright (c) 2014年 Neusoft. All rights reserved.
//

#ifndef SFExpressApp_ConstHeader_h
#define SFExpressApp_ConstHeader_h
#endif

//=========丰声=============
#define SFAccount  @"NameAccount"
//=========丰声=============




#define kIgnoreCookie           37.7
#define kSessionCookie          @"SessionCookie"
#define kLoginCookie            @"LoginCookies"
#define kWidgetCookie           @"WidgetCookies"
#define kLoginUrl               @"https://cassit.sf-express.com/cas/login"
#define kVerificationUrl        @"http://ecpsit.sf-express.com:8080/ecp/service/mdmapps/apps/casin/22/android/deid"
#define kVerificationPostUrl    @"http://ecpsit.sf-express.com:8080/ecp/service/mdmapps/test/casin/test"

#define showECP true
#define showASP true
#define showASPMain false
#define showITMP true

#define URL_CONFIG 0
//production 0, uat server 1, sit server 2, ecp-test 3, new uat server 4

#if URL_CONFIG==0
#define ASP_CY_URL @"http://aspcad.sf-express.com/index.php";//餐饮生产
#else
#define ASP_CY_URL @"http://10.202.90.63:80/index.php";//外网测试
#endif

#if URL_CONFIG==0
// production
#define ROOT_URL                @"https://mecp.sf-express.com/ecp/service/mdmapps/";
#define ACTION_LOGIN_URL        @"https://mcas.sf-express.com/cas/login";
#define LOGIN_WS_HOST           @"mecp.sf-express.com";
#define APP_INFO_SERVER         @"https://mecp.sf-express.com/ecp/service/mdmapps/apps/casin";
#define LOGIN_WS_SERVER         @"https://mecp.sf-express.com/ecp/service/mdmapps/devices";
#define TOKEN_VERIFICATION_URL  @"https://mecp.sf-express.com/ecp/service/mdmapps/apps/casin/verify";
//#define CHECK_NETWORK_URL        @"mcas.sf-express.com"
#define CHECK_NETWORK_URL        @"https://mecp.sf-express.com/ecp/ServerTest.html"
//production - ecp
#define ECP_LOGIN_URL           @"https://mecp.sf-express.com/ecp/mobile/mdmapps/mdmMobileData/getUserInf.ht"
#define ECP_INDEX_URL           @"https://mecp.sf-express.com/ecp/www/index.html"
#define ECP_DOMIN               @"https://mecp.sf-express.com/ecp/www"

//itmp
#define ITMP_LOGIN_URL          @"http:itmp1.sit.sf-express.com/loginmgmt/index.action"

//production-asp-meeting
//#define ASP_LOGIN_URL           @"http://aspadm.sf-express.com/aspmanager/loginmgmt/frame.action"
#define ASP_LOGIN_URL           @"https://aspadm.sf-express.com/aspmanager/meetingadmin/mobile_meetingOrderDraftList.action"
#define ASP_LOGIN_WS_HOST           @"aspadm.sf-express.com";
#define ASP_INDEX_URL           @"https://aspadm.sf-express.com/asp/www/widget.html"
#define ASP_DOMIN               @"https://aspadm.sf-express.com/asp/www"

//员工自助
#define CAS_PREFIX              @"https://mcas.sf-express.com/cas/login"
#define YGZZ_LOGIN_URL          @"https://hrss-essm.sf-express.com/platform/phone/service/execute.ht?service=useTypeVerse&method=query"
#define RESET_PWD               @"https://psm.sf-express.com"

#elif URL_CONFIG==1
// uat server
#define ROOT_URL                @"https://mecp.st.sf-express.com/ecp/service/mdmapps/";
#define ACTION_LOGIN_URL        @"https://cas.st.sf-express.com/cas/login";
#define LOGIN_WS_HOST           @"mecp.st.sf-express.com";
#define APP_INFO_SERVER         @"https://mecp.st.sf-express.com/ecp/service/mdmapps/apps/casin";
#define LOGIN_WS_SERVER         @"https://mecp.st.sf-express.com/ecp/service/mdmapps/devices";
#define TOKEN_VERIFICATION_URL  @"https://mecp.st.sf-express.com/ecp/service/mdmapps/apps/casin/22/android/deid";
//#define CHECK_NETWORK_URL       @"cas.st.sf-express.com"
#define CHECK_NETWORK_URL       @"https://mecp.st.sf-express.com/ecp/ServerTest.html"
//uat - ecp
#define ECP_LOGIN_URL           @"https://mecp.st.sf-express.com/ecp/mobile/mdmapps/mdmMobileData/getUserInf.ht"
//uat-asp-meeting
#define ASP_LOGIN_URL           @"http://aspadm.sit.sf-express.com/aspmanager/loginmgmt/frame.action"
#define ASP_INDEX_URL           @"http://aspadm.sit.sf-express.com/asp/www/widget.html"
#define ASP_DOMIN               @"http://aspadm.sit.sf-express.com/asp/www"

#define ECP_INDEX_URL           @"https://mecp.st.sf-express.com/ecp/www/index.html"
#define ECP_DOMIN               @"https://mecp.st.sf-express.com/ecp/www"

//itmp
#define ITMP_LOGIN_URL          @"http:itmp1.sit.sf-express.com/loginmgmt/index.action"

//员工自助
#define CAS_PREFIX              @"https://cas.st.sf-express.com/cas/login"
#define YGZZ_LOGIN_URL          @"https://essm2.st.sf-express.com/hrss/platform/phone/service/execute.ht?service=useTypeVerse&method=query"
#define RESET_PWD               @"https://psm.sf-express.com"

#elif URL_CONFIG==2
// sit server
#define ROOT_URL                @"http://ecpsit.sf-express.com/ecp/service/mdmapps/";
#define ACTION_LOGIN_URL        @"http://cassit.sf-express.com/cas/login";
#define LOGIN_WS_HOST           @"ecpsit.sf-express.com";
#define APP_INFO_SERVER         @"http://ecpsit.sf-express.com/ecp/service/mdmapps/apps/casin";
#define LOGIN_WS_SERVER         @"http://ecpsit.sf-express.com/ecp/service/mdmapps/devices";
#define TOKEN_VERIFICATION_URL  @"http://ecpsit.sf-express.com/ecp/service/mdmapps/apps/casin/verify";
//#define CHECK_NETWORK_URL       @"127.0.0.1"
#define CHECK_NETWORK_URL       @"http://ecpsit.sf-express.com/ecp/ServerTest.html"
//sit - ecp
#define ECP_LOGIN_URL           @"http://ecptest.sf-express.com:8080/ecp/mobile/mdmapps/mdmMobileData/getUserInf.ht"
#define ASP_LOGIN_URL           @"asp登陆"
#define ECP_INDEX_URL           @"http://ecptest.sf-express.com:8080/ecp/www/index.html"
#define ECP_DOMIN               @"http://ecptest.sf-express.com:8080/ecp/www"

//itmp
#define ITMP_LOGIN_URL          @"http:itmp1.sit.sf-express.com/loginmgmt/index.action"

//员工自助
#define CAS_PREFIX              @"https://cas.st.sf-express.com/cas/login"
#define YGZZ_LOGIN_URL          @"https://essm2.st.sf-express.com/hrss/platform/phone/service/execute.ht?service=useTypeVerse&method=query"
#define RESET_PWD               @"https://psm.sf-express.com"

#elif URL_CONFIG==3
//ecp-test
#define ROOT_URL                @"http://ecptest.sf-express.com:8080/ecp/service/mdmapps/";
#define ACTION_LOGIN_URL        @"http://cassit.sf-express.com/cas/login";
#define LOGIN_WS_HOST           @"ecpsit.sf-express.com";
#define APP_INFO_SERVER         @"http://ecptest.sf-express.com:8080/ecp/service/mdmapps/apps/casin";
#define LOGIN_WS_SERVER         @"http://ecptest.sf-express.com:8080/ecp/service/mdmapps/devices";
#define TOKEN_VERIFICATION_URL  @"http://ecptest.sf-express.com:8080/ecp/service/mdmapps/apps/casin/verify";
//#define CHECK_NETWORK_URL       @"127.0.0.1"
#define CHECK_NETWORK_URL       @"http://ecptest.sf-express.com:8080/ecp/ServerTest.html"
//sit - ecp
#define ECP_LOGIN_URL           @"http://ecptest.sf-express.com:8080/ecp/mobile/mdmapps/mdmMobileData/getUserInf.ht"
#define ASP_LOGIN_URL           @"https://bamssit.sf-express.com/aspmanager/loginmgmt/index.action"
#define ECP_INDEX_URL           @"http://ecptest.sf-express.com:8080/ecp/www/index.html"
#define ECP_DOMIN               @"http://ecptest.sf-express.com:8080/ecp/www"

//itmp
#define ITMP_LOGIN_URL          @"http:itmp1.sit.sf-express.com/loginmgmt/index.action"

//员工自助
#define CAS_PREFIX              @"https://cas.st.sf-express.com/cas/login"
#define YGZZ_LOGIN_URL          @"https://essm2.st.sf-express.com/hrss/pwlatform/phone/service/execute.ht?service=useTypeVerse&method=query"
#define RESET_PWD               @"https://psm.sf-express.com"

#elif URL_CONFIG==4
//new uat server
#define ROOT_URL                 @"https://mecp.sit.sf-express.com/ecp/service/mdmapps/";
#define ACTION_LOGIN_URL        @"https://mcas.sit.sf-express.com/cas/login";
#define LOGIN_WS_HOST           @"mecp.sit.sf-express.com";
#define APP_INFO_SERVER         @"https://mecp.sit.sf-express.com/ecp/service/mdmapps/apps/casin";
#define LOGIN_WS_SERVER         @"https://mecp.sit.sf-express.com/ecp/service/mdmapps/devices";
#define TOKEN_VERIFICATION_URL  @"https://mecp.sit.sf-express.com/ecp/service/mdmapps/apps/casin/22/android/deid";
//#define CHECK_NETWORK_URL       @"cas.st.sf-express.com"
#define CHECK_NETWORK_URL       @"https://mecp.sit.sf-express.com/ecp/ServerTest.html"
//uat - ecp
#define ECP_LOGIN_URL           @"https://mecp.sit.sf-express.com/ecp/mobile/mdmapps/mdmMobileData/getUserInf.ht"
#define ASP_LOGIN_URL           @"asp登陆"
#define ECP_INDEX_URL           @"https://mecp.sit.sf-express.com/ecp/www/index.html"
#define ECP_DOMIN               @"https://mecp.sit.sf-express.com/ecp/www"

//itmp
#define ITMP_LOGIN_URL          @"http://itmp1.sit.sf-express.com/loginmgmt/index.action"

//员工自助
#define CAS_PREFIX              @"https://cas.st.sf-express.com/cas/login"
#define YGZZ_LOGIN_URL          @"https://essm2.st.sf-express.com/hrss/platform/phone/service/execute.ht?service=useTypeVerse&method=query"
#define RESET_PWD               @"https://psm.sf-express.com"

#endif

// sit mop
//#define ROOT_URL                @"http://mopsit.sf-express.com/ecp/service/mdmapps/";
//#define ACTION_LOGIN_URL        @"http://cassit.sf-express.com/cas/login";
//#define LOGIN_WS_HOST           @"ecpsit.sf-express.com";
//#define APP_INFO_SERVER         @"http://mopsit.sf-express.com/ecp/service/mdmapps/apps/casin";
//#define LOGIN_WS_SERVER         @"http://mopsit.sf-express.com/ecp/service/mdmapps/devices";
//#define TOKEN_VERIFICATION_URL  @"http://mopsit.sf-express.com/ecp/service/mdmapps/apps/casin/verify";

// old
//#define ROOT_URL                      @"HTTP://ecpsit.sf-express.com:8080/ecp/service/mdmapps/";

#define GET_APP_LIST_URL_FORMAT       @"%@apps/casin/%@/%@/%@";
#define CHECK_UPDATE_URL_FORMAT       @"%@apps/casin/checkPortalUpdate?&appOS=%@&appUUID=%@&version=%@";
#define GET_APP_DETAIL_URL_FORMAT     @"%@apps/casin/info/%@?appOS=%@&appUUID=%@&appversion=%@";
#define GET_INSTALL_URL_FORMAT        @"%@apps/casin/iosAndroid/install?deviceId=%@&appId=%@&appOS=%@&appUUID=%@&appversion=%@&downloadType=%@&lng=%@";
#define GET_APP_LIST_URL              @"%@/casin/appList"

#define CHECK_DEVICE_URL_FORMAT       @"%@devices/casout/checkDeviceBlackList2"
#define CHECK_ACCOUNT_URL_FORMAT      @"%@devices/casin/checkUserAccount2"
#define GET_VERIFY_CODE               @"%@devices/casin/getVerifyCode2"
#define BIND_DEVICE                   @"%@devices/casin/doVerifyCode2"
#define GET_PHONE_NUMBER              @"%@devices/casin/getUserPhone"
#define CHECK_DEVICE_LEGAL            @"%@devices/casin/check"

#define GET_ADD_ERROR                 @"%@devices/addError"

#define kLoginLanguageCNUrl     @"?locale=zh&language=zh&country=CN&variant=CN"
#define kLoginLanguageTWUrl     @"?locale=tw&language=zh&country=TW&variant=TW"
#define kLoginLanguageUSUrl     @"?locale=en&language=en&country=US&variant=US"


#define kXPathLT                @"//*[@id='loginForm']/lt"
#define kXPathMessage           @"//*[@id='status']"



