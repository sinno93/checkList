//
//  SFCommonViewController.m
//  SFExpressApp
//
//  Created by 刘梓涛(ALEX Liu)-企业内部系统研发中心 on 16/1/11.
//  Copyright © 2016年 Neusoft. All rights reserved.
//

#import "SFCommonViewController.h"
#import "CommonConfig.h"
#import "ConstHeader.h"
//#import "SFUrlUtility.h"
//#import "SFAppDelegate.h"
//#import "SFPictureViewer.h"

@interface SFCommonViewController ()<NSURLConnectionDataDelegate>

@property (nonatomic,strong)UIImageView *backgroundView;
@property (nonatomic,assign)NSInteger loginCode;
@property (nonatomic,strong)NSMutableData *responseData;
@property (nonatomic,strong)UIView *coverView;
@property (nonatomic)BOOL firstIn;

@end

@implementation SFCommonViewController


- (id)init
{
    self = [super init];
    if (self) {
        self.wwwFolderName = @"kms";
        self.startPage = @"index.html";
        self.tabBarItem.title = @"设置";
        self.tabBarItem.image = [UIImage imageNamed:@"setting"];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.firstIn = YES;
    self.view.backgroundColor = [UIColor colorWithRed:78.0/255 green:166.0/255 blue:232.0/255 alpha:1.0];
    NSString *rootUrl = ACTION_LOGIN_URL;
    NSURL *loginUrl = [NSURL URLWithString:[NSString stringWithFormat:@"%@?service=%@",rootUrl,@"http://kms-mcmsrepo.sit.sf-express.com/KMS-MSERVER"]];
    NSURLRequest *request = [NSURLRequest requestWithURL:loginUrl];
    [NSURLConnection connectionWithRequest:request delegate:self];
    
    NSNotificationCenter *notify = [NSNotificationCenter defaultCenter];
    [notify addObserver:self selector:@selector(dismiss) name:@"didTapGoBackExpress" object:nil];
    //[notify addObserver:self selector:@selector(showImageViewer:) name:@"ShowImageViewer" object:nil];
    
    CGRect bounds = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-44);
    self.webView.frame = bounds;
    
    [(UIScrollView *)[[self.webView subviews] objectAtIndex:0] setBounces:NO];
    self.backgroundView = [[UIImageView alloc]initWithFrame:self.view.frame];
    //    self.backgroundView.image = [UIImage imageNamed:@"pms_loading750x1334.png"];
    
    //    self.backgroundView.hidden = NO;
    //    [self.view addSubview:self.backgroundView];
}

-(void)viewWillAppear:(BOOL)animated
{
//    if(!self.firstIn){
//        SFAppDelegate *app = (SFAppDelegate *)[UIApplication sharedApplication].delegate;
//        self.coverView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 20)];
//        self.coverView.backgroundColor = [UIColor colorWithRed:78.0/255 green:166.0/255 blue:232.0/255 alpha:1.0];
//        [app.window addSubview:self.coverView];
//    }
    self.navigationController.navigationBarHidden = YES;
}

-(void)viewWillDisappear:(BOOL)animated
{
    [self.coverView removeFromSuperview];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - NSURLConnectionDataDelegate
- (BOOL)connection:(NSURLConnection *)connection canAuthenticateAgainstProtectionSpace:(NSURLProtectionSpace *)protectionSpace
{
    return [protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust];
}

- (void)connection:(NSURLConnection *)connection didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge {
    if ([challenge.protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust]){
        [[challenge sender]  useCredential:[NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust] forAuthenticationChallenge:challenge];
        [[challenge sender]  continueWithoutCredentialForAuthenticationChallenge: challenge];
    }
}
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    NSHTTPURLResponse *http = (NSHTTPURLResponse *)response;
    self.loginCode = http.statusCode;
}

-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{    NSString *l = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    [self.responseData appendData:data];
}
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    NSLog(@"错误...%@",error.localizedDescription);
}
-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    if(self.loginCode == 200){
        NSLog(@"login successssssssss");
        self.firstIn = NO;
        [self performSelector:@selector(showWebView) withObject:nil afterDelay:0.0];
    }
}

-(void)showWebView
{
    //    [self.backgroundView removeFromSuperview];
//    SFAppDelegate *app = (SFAppDelegate *)[UIApplication sharedApplication].delegate;
//    self.coverView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 20)];
//    self.coverView.backgroundColor = [UIColor colorWithRed:78.0/255 green:166.0/255 blue:232.0/255 alpha:1.0];
//    [app.window addSubview:self.coverView];
}

- (void)dismiss {
    NSNotificationCenter *notify = [NSNotificationCenter defaultCenter];
    [notify removeObserver:@"didTapGoBackExpress"];
    [self.webView stopLoading];
    self.webView.delegate = nil;
    self.webView = nil;
    [self.webView removeFromSuperview];
    //    [self dismissViewControllerAnimated:YES completion:nil];
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)showImageViewer:(NSNotification*)notifycation
{
//    NSDictionary *dic = notifycation.userInfo;
//    NSArray *imgArray = [dic objectForKey:@"imageArray"];
//    SFPictureViewer *imgViewerController = [[SFPictureViewer alloc]init];
//    imgViewerController.imgArray = imgArray;
//    imgViewerController.view.window.rootViewController = self.navigationController;
//    UIBarButtonItem *barItem = [[UIBarButtonItem alloc]initWithTitle:@" " style:UIBarButtonItemStyleDone target:imgViewerController action:@selector(toBack)];
//    [self.navigationItem setBackBarButtonItem:barItem];
//    [self.navigationController setNavigationBarHidden:YES];
//    
//    [self.navigationController pushViewController:imgViewerController animated:NO];
//    [imgViewerController.view.window makeKeyAndVisible];
    NSLog(@"show iamge Viewer");
    
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end