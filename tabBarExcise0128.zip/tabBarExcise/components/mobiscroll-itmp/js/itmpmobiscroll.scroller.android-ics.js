define(["jquery"], function($) {
    var theme = {
        dateOrder: 'Mddyy',
        mode: 'mixed',
        rows: 3,
        minWidth: 76,
        height: 46,
        showLabel: false,
        selectedLineHeight: true,
        selectedLineBorder: 2,
        useShortLabels: true,
        icon: { filled: 'star3', empty: 'star' }
    };
    $.mobiscroll.themes['android-ics'] = theme;
    $.mobiscroll.themes['android-ics light'] = theme;

});

