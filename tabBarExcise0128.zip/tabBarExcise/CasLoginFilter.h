//
//  CasLoginFilter.h
//  SFExpressApp
//
//  Created by hongy on 14-5-28.
//  Copyright (c) 2014年 Neusoft. All rights reserved.
//

#import <Foundation/Foundation.h>


@protocol CasLoginFilterDelegate
-(void)didUserLogin:(BOOL) isSucceed retunMesssage:(NSDictionary*) dict;
@end


@interface CasLoginFilter : NSObject{
    NSString *responseContent;
    NSURL *fromUrl;
    NSArray *lastCookies;
    NSMutableData* receiveData;
    id<CasLoginFilterDelegate> loginDeleage;
    int requestStep;
    NSString *lastUser;
    NSString *lastPassword;
}

@property(strong,nonatomic)id<CasLoginFilterDelegate> loginDeleage;



-(BOOL)attachLoginCookies:(NSURL *) url ;

-(void) userLogin:(NSString*) userName passWord:(NSString*) pwd;

-(NSArray*) loadLoginCookies;
-(BOOL) saveSessionCookie:(NSArray*)cookies;
-(BOOL) saveServerCookie:(NSArray*)cookies;
//-(BOOL) saveAspSessionCookie:(NSArray*)cookies;
-(void) saveLoginCookies:(NSArray*)cookies;

+(BOOL) isRedirectToLoginPage:(NSString*) content;

-(void) setLoginCookieForDomain:(NSString*) domain withPath:(NSString*)path inUrl:(NSURL*) url;

+(NSString*) loadUserName;

-(NSString*) getToken;

@end
