var ECPMobileApp = angular.module('ECPMobile', [
    'ionic',
    'ECPMobile.common',
    'ECPMobile.controller',
    'ECPMobile.directive',
    'ECPMobile.services',
    'ECPMobile.filters',
    'ECPMobile.global'
]);
angular.module("ECPMobile.common", []);
angular.module("ECPMobile.controller", []);
angular.module("ECPMobile.directive", []);
angular.module("ECPMobile.services", []);
angular.module("ECPMobile.filters", []);
angular.module("ECPMobile.global", []);

ECPMobileApp.config(function ($compileProvider) {
$compileProvider.aHrefSanitizationWhitelist(/^\s*(https?|ftp|mailto|file|tel):/);
}).config(function ($httpProvider) {
$httpProvider.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
});

ECPMobileApp.run(["GlobalInterceptorHandler", "$rootScope", '$ionicPlatform', '$location',  function (GlobalInterceptorHandler, $rootScope, $ionicPlatform, $location) {
  GlobalInterceptorHandler.registerResponseHandling($rootScope);
    $ionicPlatform.registerBackButtonAction(function (e) {
        /*先捕获异常，禁止使用ionic中自带的处理机制，根据不同的页面的后缀，进行不同的页面的跳转处理*/
        e.preventDefault();
        if ($location.path() == '/mypending' ||$location.path() == '/myrequest' ||$location.path() == '/myhandle') {

        } else if ($rootScope.$viewHistory.backView ) {
            $rootScope.$viewHistory.backView.go();
        }
        return false;
    }, 101);
}]);