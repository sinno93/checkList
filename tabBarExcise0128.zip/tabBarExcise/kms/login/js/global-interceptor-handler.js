
angular.module("ECPMobile.common").service('GlobalInterceptorHandler', ["$rootScope", "$timeout", "$ionicPopup", function ($rootScope, $timeout, $ionicPopup) {
  return {
        registerResponseHandling: function ($scope) {
      var PageError = {};
      /*网络超时*/
      $rootScope.$on("NoNetWorksError", function(e, response){
        $timeout(function(){
			$ionicPopup.alert({
				title: "<p style='padding:12px 0;border-bottom:1px solid #ddd'>网络超时</p>"
			})
        },100);
      });
		/*系统错误500+*/
      $rootScope.$on("ResponseServerError", function(e, response){
		$timeout(function(){
			$ionicPopup.alert({
				title: "<p style='padding:12px 0;border-bottom:1px solid #ddd'>系统错误</p>"
			})
        },100);
      }); 
      /*数据请求400-500*/
      $rootScope.$on("DadaServerError", function(e, response){
		$timeout(function(){
			$ionicPopup.alert({
				title: "<p style='padding:12px 0;border-bottom:1px solid #ddd'>数据访问错误，请稍后重试。</p>"
			})
        },100);
      }); 
    },
  };
}]);
