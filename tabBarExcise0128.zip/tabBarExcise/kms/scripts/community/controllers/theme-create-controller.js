define(['angularAMD', 'common/services/footer-service', 'community/services/community-detail-services', 'common/directive/input-box', 'common/controllers/staff-selection-controller'], function(angularAMD) {
	angularAMD.controller('themeCreateController', ['$scope', '$ionicModal', '$ionicPopup', '$location', '$rootScope', 'FooterServices', '$ionicScrollDelegate', '$stateParams', '$timeout', 'CommunityDetailServices', 'Global', '$ionicLoading',
		function($scope, $ionicModal, $ionicPopup, $location, $rootScope, FooterServices, $ionicScrollDelegate, $stateParams, $timeout, CommunityDetailServices, Global, $ionicLoading) {
			'use strict';
			/*模拟数据*/
			var parameter={};
			parameter.sourceId=$stateParams.sourceId;//社区详情id

			/*弹出窗口*/
			var showDialogbox1=function(callback){/*确认是否保存*/
				$scope.explain = "确认提交该主题讨论？";
				$scope.modalYes = "确定";
				$scope.modalNo = "取消";
				$scope.modalShow = 3;
				$scope.isBatch = function(flag) {
					if(flag){
						callback();
					}
					$scope.modal.hide();
				};
				$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
					scope: $scope,
					animation: 'slide-in-up'
				}).then(function(modal) {
					$scope.modal = modal;
					$scope.modal.show();
				});
			}
			var showDialogbox2=function(text){/*提示已经保存*/
				$scope.modalShow = 10;
				$scope.collectContent = text;
				$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
					scope: $scope,
					animation: 'slide-in-up'
				}).then(function(modal) {
					$scope.modal = modal;
					$scope.modal.show();
					$timeout(function(){
						$scope.modal.hide();
					}, 1000);
				});
			}
		
			/*初始函数*/
			var init=function(){
				FooterServices.hide();
				$scope.title="编辑你的主题讨论";
				$scope.theme='';
				inputBoxAsk3($scope);
				$timeout(function(){
					$(document.getElementById("emoijid").contentWindow.document).find('html').append(
						'<style>span{display: none;}</style>'
					);
				}, 1000);
				$scope.sign.ifsmile=false;
				var updateTextarea=function(){
					var h=$(window).height()-(getKeyboardHeight()?(getKeyboardHeight()+51):$(".input-common").height())-90;
					$(".textarea").height(h);
				}
				setInterval(function(){
					updateTextarea();
				}, 200);
				$timeout(function(){
					$('.theme').focus();
				}, 300);
			}
			init();

			$scope.toggleInput=function(show){
				$scope.isInputing=show;
			}

			$scope.historyBack=function(){
				history.back(-1);
			}
			$scope.addImageElement = function(imgUrl) {
				if (!$scope.imageUrlArray)
					$scope.imageUrlArray = [];
				$scope.imageUrlArray.push(imgUrl);
			}
			$scope.submit = function(){
				if($('.theme').val()==''||$(document.getElementById("emoijid").contentWindow.document.body).html()==''){
					showDialogbox2('请将讨论主题（内容）填写完整');
					return;
				}

				showDialogbox1(function(){
					var $content=$(document.getElementById("emoijid").contentWindow.document.body);
					var data={};
					data.theme=$('.theme').val();
					data.content=$content.html();
					if($scope.imageUrlArray && $scope.imageUrlArray.length > 0){
						var imageArrayUrlTemp = [];
						for(var i=0;i<$scope.imageUrlArray.length;i++){
							if(data.content.indexOf($scope.imageUrlArray[i])>=0){
								imageArrayUrlTemp.push($scope.imageUrlArray[i]);
							}
						}
						if(imageArrayUrlTemp.length > ImageUploadNumber){
							showDialogbox2('图片最多只能发5张，请将图片删减！');
							return;
						}else{
							$scope.imageUrlArray = imageArrayUrlTemp;
						}
					}
					
					$ionicLoading.show({
						content: '正在发表',
						animation: 'fade-in',
						showBackdrop: true,
						Width:150,
						maxWidth: 300,
						showDelay: 0
					});
					
					data.sourceId=parameter.sourceId;
					data.sourceType=1;
					data.infoToUser=[];
					$content.find("span").each(function(){
						data.infoToUser.push($(this).text());
					});
					data.infoToUser=data.infoToUser.join(",");
					
					$content.find('span').remove();
					data.content=$content.html();
					if($scope.imageUrlArray){
						for (var i = 0; i < $scope.imageUrlArray.length; i++) {
							var stringRul = $scope.imageUrlArray[i];
							data.content = data.content.replace(stringRul, '');
						}
					}else{
						$scope.imageUrlArray=[];
					}
					data.content = replace_em(data.content);

					if(!$scope.imageUrlArray || $scope.imageUrlArray.length == 0){
						data.images = "";
						CommunityDetailServices.saveCommunityPost(data).then(function(result) {
							$ionicLoading.hide();
							if(result.status){
								showDialogbox2('主题讨论发布成功');
								$timeout(function(){
									history.back(-1);
								}, 1000);
							}else{
								$ionicPopup.alert({
									template: "<p >" + result.errorMessage + "</p>"
								});
							}
						});
						return;
					}
					var imageArrayUrlCopy = [];
					var imageArrayUrl = [];

					var imageCompressIndex = 0;
					var imageTransferIndex = 0;

					function onSuccess(imgurl) {
						imageArrayUrl.push(imgurl);
						if (imageTransferIndex >= imageArrayUrlCopy.length - 1) {
							transferImageToService(Global.apiPath + "/upload/image", imageArrayUrlCopy[imageTransferIndex], onSuccessSubmit, onFail);
						} else {
							transferImageToService(Global.apiPath + "/upload/image", imageArrayUrlCopy[imageTransferIndex], onSuccess, onFail);
						}
						imageTransferIndex++;
					}

					function onSuccessSubmit(imgurl) {
						imageArrayUrl.push(imgurl);
						data.images = "";
						for (var i = 0; i < imageArrayUrl.length; i++) {
							if (i == imageArrayUrl.length - 1) {
								data.images = data.images + imageArrayUrl[i];
							} else {
								data.images = data.images + imageArrayUrl[i] + ",";
							}
						}
						CommunityDetailServices.saveCommunityPost(data).then(function(result) {
							deleteFiles(imageArrayUrlCopy);
							$ionicLoading.hide();
							if(result.status){
								showDialogbox2('主题讨论发布成功');
								$timeout(function(){
									history.back(-1);
								}, 1000);
							}else{
								$ionicPopup.alert({
									template: "<p >" + result.errorMessage + "</p>"
								});
							}
						});
					}

					function onFail(mess) {
						$ionicLoading.hide();
						showDialogbox2(mess);
					}

					function compressSuccess(imgurl) {
						if (imageCompressIndex >= $scope.imageUrlArray.length - 1) {
							compressFile($scope.imageUrlArray[imageCompressIndex], compressSuccessSubmit, onFail);
						} else {
							compressFile($scope.imageUrlArray[imageCompressIndex], compressSuccess, onFail);
						}
						imageCompressIndex++;
						imageArrayUrlCopy.push(imgurl);
					}

					function compressSuccessSubmit(imgUrl) {
						imageArrayUrlCopy.push(imgUrl);
						console.log("imageArrayUrlCopy");
						console.log(imageArrayUrlCopy);
						if (imageArrayUrlCopy && imageArrayUrlCopy.length > 0) {
							if (imageTransferIndex >= imageArrayUrlCopy.length - 1) {
								transferImageToService(Global.apiPath + "/upload/image", imageArrayUrlCopy[imageTransferIndex], onSuccessSubmit, onFail);
							} else {
								transferImageToService(Global.apiPath + "/upload/image", imageArrayUrlCopy[imageTransferIndex], onSuccess, onFail);
							}
							imageTransferIndex++;
						}
					}
					if ($scope.imageUrlArray && $scope.imageUrlArray.length > 0) {
						console.log("$scope.imageUrlArray");
						console.log($scope.imageUrlArray);
						if (imageCompressIndex >= $scope.imageUrlArray.length - 1) {
							compressFile($scope.imageUrlArray[imageCompressIndex], compressSuccessSubmit, onFail);
						} else {
							compressFile($scope.imageUrlArray[imageCompressIndex], compressSuccess, onFail);
						}
						imageCompressIndex++;
					}
				});
			};
		}
	])

});