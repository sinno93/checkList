define(['angularAMD', 'common/services/footer-service', 'community/services/community-frame-service'], function(angularAMD) {
	angularAMD.controller('communityFrameController', ['$scope', "Global", '$timeout', '$ionicModal', '$location', '$rootScope', 'FooterServices', 'CommunityFrameServices', '$ionicScrollDelegate',
		function($scope, Global, $timeout, $ionicModal, $location, $rootScope, FooterServices, CommunityFrameServices, $ionicScrollDelegate) {
			FooterServices.activeItemByIndex(2);
			$scope.title = "社区";
			$scope.ok = "确定";
			$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
				scope: $scope,
				animation: 'slide-in-up'
			}).then(function(modal) {
				$scope.modal = modal;
			});
			$scope.backLogin = function() {
				if ($scope.searchif) {
					$scope.searchif = false;
					$scope.keyword = "";
					$scope.communityList = [];
					$scope.currPage = 0;
					$scope.pageSize = 8;
					$scope.isFirstIn = true;
					$scope.noMoreItemsAvailable = false;
					getDataList($scope.currPage, $scope.pageSize, "");
					$scope.currPage++;
					$rootScope.kmsConmunitySearchKeywordIf = false;
					return;
				}
				$location.path("/hot");
			};

			$scope.clear = function() {
				$scope.modal.hide();
			};

			$scope.gosearch = function() {
				$scope.keyword = $scope.data.keyword;
				localStorage.setItem("kmsConmunitySearchKeyword", $scope.keyword);
				$rootScope.kmsConmunitySearchKeywordIf = true;
				$scope.communityList = [];
				$scope.currPage = 0;
				$scope.pageSize = 8;
				$scope.isFirstIn = true;
				$scope.noMoreItemsAvailable = false;
				getDataList($scope.currPage, $scope.pageSize, "");
				$scope.currPage++;
			};
			//搜索
			$scope.search = function() {
				$timeout(function() {
					document.getElementById("pendingSearch").focus();
					$scope.communityList = [];
				}, 300);
				$scope.searchif = true;
				$scope.data = {
					"keyword": ""
				};
				console.log("搜索");
			};
			init();

			function init() {
				initData();
				$(window).on('touchstart', function(obj) {
					keyboardDown();
				});
				//				getDataList($scope.currPage,$scope.pageSize,$scope.keyword,"");
			};

			function initData() {
				if ($rootScope.kmsConmunitySearchKeywordIf == true) {
					$scope.isFirstIn = true;
					$scope.searchif = true;
					$scope.currPage = 0;
					$scope.pageSize = 8;
					$scope.keyword = localStorage.getItem("kmsConmunitySearchKeyword");
					$scope.data = {
						"keyword": $scope.keyword
					};
					$scope.communityList = [];
					$scope.noMoreItemsAvailable = false;
				} else {
					$scope.isFirstIn = true;
					$scope.searchif = false;
					$scope.currPage = 0;
					$scope.pageSize = 8;
					$scope.keyword = "";
					$scope.communityList = [];
					$scope.noMoreItemsAvailable = false;
				}
			}

			function getDataList(currPage, pageSize, type) {
				CommunityFrameServices.getCommunityMessage(currPage, pageSize, $scope.keyword).then(function(response) {
					if (response.status == 1) {
						var list = response.data;
						var items = [];
						var dataLength = list.length
						for (var i = 0; i < dataLength; i++) {
							var data = {};
							data.imgUrl = assembleImageUrl(list[i].headImage);
							data.titleName = list[i].name;
							data.fances = list[i].memberCount;
							data.messages = list[i].cooperation;
							data.isAdmin = list[i].isAdmin;
							data.id = list[i].id;
							//状态（join：已加入，approving：待审核，canJoin：申请加入）
							if (data.isAdmin) {
								data.addContent = '管理员';
								data.addClass = "adminBtn";
							} else if (list[i].status == 'join') {
								data.isAdd = true;
								data.addContent = '退出社区';
								data.addClass = "outBtn";
							} else if (list[i].status == 'approving') {
								data.isAdd = true;
								data.addContent = '等待审核';
								data.addClass = "outBtn";
							} else if (list[i].status == 'canJoin') {
								data.isAdd = false;
								data.addContent = '加入社区';
								data.addClass = "addBtn";
							}
							items.push(data);
						}
						var totalSize = response.totalSize;
						if (!$scope.communityList)
							$scope.communityList = [];
						$scope.communityList = $scope.communityList.concat(items);
						$scope.noMoreItemsAvailable = $scope.communityList.length >= totalSize;
						$scope.$broadcast('scroll.infiniteScrollComplete');
						cancelScrollInitFunction($scope);
						refreshData(type, dataLength);
					}
				});

			}

			function refreshData(type, length) {
				if (type == "refresh") {
					if (length > 0) {
						$scope.refresherData = "已经为您更新" + length + "条数据";
						$(".refresher-data").show();
						$timeout(function() {
							$(".refresher-data").hide();
						}, 700);
					}
				} else if (type == "loadMore") {
					if (length > 0) {
						$scope.infiniteData = "已经为您加载" + length + "条数据";
						$(".infinite-data").show();
						$timeout(function() {
							$(".infinite-data").hide();
						}, 700);
					}
				}
			}

			$scope.onRefresh = function() {
				$scope.currPage = 0;
				$scope.pageSize = 8;
				if ($scope.searchif) {
					$scope.keyword = $scope.data.keyword;
				} else {
					$scope.keyword = "";
				}
				$scope.communityList = [];
				getDataList($scope.currPage, $scope.pageSize, "refresh");
				$scope.currPage++;
			};

			$scope.loadMore = function() {
				if ($scope.noMoreItemsAvailable) {
					$scope.$broadcast('scroll.infiniteScrollComplete');
					return;
				} else {
					//					if($scope.isFirstIn){
					//						$scope.isFirstIn = false;
					//						$scope.$broadcast('scroll.infiniteScrollComplete');
					//						return;
					//					}else{
					//$scope.isFirstIn = true;

					getDataList($scope.currPage, $scope.pageSize, "loadMore");
					$scope.currPage++;
					//					}
				}
			};

			$scope.addCommunity = function(index) {
				//				$location.path('/leave-message-create/002628');
				var isAdd = !$scope.communityList[index].isAdd;
				if ($scope.communityList[index].addContent == '等待审核' || $scope.communityList[index].isAdmin)
					return;
				var id = $scope.communityList[index].id;
				CommunityFrameServices.joinCommunity(id, isAdd).then(function(response) {
					if (response.status == 1) {
						if (isAdd) {
							$scope.explain = "成功加入社区";
							$scope.communityList[index].isAdd = true;
							$scope.communityList[index].addContent = '退出社区';
							$scope.communityList[index].addClass = "outBtn";
						} else {
							$scope.explain = "成功退出社区";
							$scope.communityList[index].isAdd = false;
							$scope.communityList[index].addContent = '加入社区';
							$scope.communityList[index].addClass = "addBtn";
						}
						$scope.modalShow = 2;
						$scope.modal.show();
					} else if (response.status == 2) {
						if (isAdd) {
							$scope.explain = "已申请加入,等待审核";
							$scope.communityList[index].isAdd = true;
							$scope.communityList[index].addContent = '等待审核';
							$scope.communityList[index].addClass = "outBtn";
						} else {

						}
						$scope.modalShow = 2;
						$scope.modal.show();
					} else {
						if (isAdd) {
							$scope.explain = "加入社区失败";
						} else {
							$scope.explain = "退出社区失败";
						}
						$scope.modalShow = 2;
						$scope.modal.show();
					}
				});
			};
			//跳转详情
			$scope.communityDetail = function(id) {
				console.log("go community detail!!!" + id);
				$location.path('/community-detail/' + id);
			};

			$scope.deleteKeyword = function() {
				$scope.data.keyword = "";
				document.getElementById("pendingSearch").blur();
				console.log("deletekeyword!!!");
			};
			//下拉提示到底了
			$scope.scrollDragUp = function() {
				dragUp($ionicScrollDelegate, $scope);
			}
		}
	]);

});