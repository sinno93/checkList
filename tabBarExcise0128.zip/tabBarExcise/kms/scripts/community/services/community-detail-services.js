define(['angularAMD','global'],function(angularAMD){
	angularAMD.factory('CommunityDetailServices',["$http","$q","Global","$ionicModal",
	function($http, $q, Global, $ionicModal){
		var getPromise = function(p) {
			var defer = $q.defer();
			p.success(function(response) {
				return defer.resolve(response);
			}).error(function() {
				return defer.reject();
			});
			return defer.promise;
		};
			
		return{
			/*（取消）关注*/
			setCommunityAttention: function(data){
				var url = Global.apiPath+'/community/joinOrOutCommunity?'+$.param(data);
				return getPromise($http.get(url));
			},
			/*获取社区详情*/
			getCommunityDetail: function(data){
				var url = Global.apiPath+'/community/viewCommunity?'+$.param(data);
				return getPromise($http.get(url));
			},
			/*获取回复列表*/
			getCommunityPostList: function(data){
				var url = Global.apiPath+'/community/listDiscussion?'+$.param(data);
				return getPromise($http.get(url));
			},
			/*保存主题活动*/
			saveCommunityPost: function(data){
				var url = Global.apiPath+'/discussion/save?'+$.param(data);
				return getPromise($http.get(url));
			},
			/*转发回复内容*/
			shareCommunityPost: function(data){
				var url = Global.apiPath+'/question/save?sim='+data;
				return getPromise($http.get(url));
			},
			/*评论回复内容*/
			replyCommunityPost: function(data){
				var url = Global.apiPath+'/question/save?sim='+data;
				return getPromise($http.get(url));
			},
			/*点赞回复内容*/
			praiseCommunityPost: function(data){
				var url = Global.apiPath+'/question/save?sim='+data;
				return getPromise($http.get(url));
			},
			/*删除回复内容*/
			deleteCommunityPost: function(data){
				var url = Global.apiPath+'/discussion/delete?'+$.param(data);
				return getPromise($http.get(url));
			}
		};
	}]);
});
