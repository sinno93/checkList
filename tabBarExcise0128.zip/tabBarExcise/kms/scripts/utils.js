//最大上传图片数
var ImageUploadNumber = 5;

Date.prototype.Format = function(result) {
	var o = {
		"M+": this.getMonth() + 1, //month
		"D+": this.getDate(), //day
		"h+": this.getHours(), //hours
		"m+": this.getMinutes(), //minutes
		"s+": this.getSeconds(), //seconds
		"q+": Math.floor((this.getMonth() + 3) / 3), // season
		"S": this.getMilliseconds() //milliseconds
	};
	if (/(Y+)/.test(result)) {
		result = result.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
	}
	for (var k in o) {
		if (new RegExp("(" + k + ")").test(result)) {
			result = result.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
		}
	}
	return result;
};
var searchData = [
	"您当前搜索的内容没有数据", "您当前选择的页面没有数据", "您当前没有好友",
]
NoData = function(length, i) {
	if (length == 0) {
		$(".has-header .data").remove();
		$(".has-header").append("<div class='new-nodata data dele-data'><p class='nodata-info'>" + searchData[i] + "</p></div>");
		//		$(".has-header").append("<div class='data dele-data'><p class='no-data'><i class='icon-no-have'></i></p><p class='line-hr'></p><p class='no-data-content'>" + searchData[i] + "</p></div>");
	} else {
		$(".has-header .data").remove();
	}
}
mineNoData = function(length) {
	if (length == 0) {
		$(".has-header .data").remove();
		$(".has-header").append("<div class='new-nodata new-nodata-mine'><p class='nodata-info'>" + "您当前选择的页面没有数据" + "</p></div>");
	} else {
		$(".has-header .data").remove();
	}
}
GetByid = function(id) {
	return document.getElementById(id);
}

function bgTouchStart(id, sign) {
	$("#" + id).addClass(sign);
}

function bgTouchEnd(id, sign) {
	$("#" + id).removeClass(sign);
}
initPager = function(scope) {
	if (scope.pageObj == null) {
		scope.pageObj = {};
	}
	scope.pageObj.startPage = 0;
	scope.pageObj.pageSize = 8;
	scope.noMoreItemsAvailable = true;
	scope.isFirstIn = true;
}
cancelScrollInitFunction = function(scope) {
	window.setTimeout(function() {
		scope.$broadcast('scroll.refreshComplete');
	}, 100);
}

//收藏

function isCollect(isSave) {
	switch (isSave) {
		case true:
			return '已收藏';
			break;
		case false:
			return '收藏';
			break;
		default:
			break;
	}
}
//获取类型

function getType(type) {
	switch (type) {
		case 'knowledge':
			return '知识';
			break;
		case 'theme':
			return '讨论';
			break;
		case 'blog':
			return '博客';
			break;
		case 'iask':
			return '爱问';
			break;
		case 'knomap':
			return '知识';
			break;
		case 'community':
			return '社区';
			break;
		default:
			break;
	}
}
var curName = "";

function setCurName(name) {
	curName = name;
}

function getCurName() {
	return curName;
}
//获取类型、id
var setType = "",
	setId = "",
	keyboardHeight = 0.0;

function setKeyboardHeight(height) {
	keyboardHeight = height;
}

function getKeyboardHeight() {
	return keyboardHeight;
}

function setStype(type) {
	setType = type;
}

function getStype() {
	return setType;
}

function setSid(id) {
	setId = id;
}

function getSid() {
	return setId;
}
//获取自己工号、名称
var myId = "",
	myName = "";
myheadPath = "";

function setHeadPath(headPath) {
	myheadPath = headPath;
}

function getHeadPath() {
	return myheadPath;
}

function setMyId(id) {
	myId = id;
}

function getMyId() {
	return myId;
}

function setMyName(name) {
	myName = name;
}

function getMyName() {
	return myName;
}
//获取回复人名称和工号
var replyName = "",
	replyNum = "";

function setReplyName(name) {
	replyName = name;
}

function getReplyName() {
	return replyName;
}

function setReplyNum(num) {
	replyNum = num;
}

function getReplyNum() {
	return replyNum;
}
//获取被回复人名称和工号
var beReplyName = "",
	beReplyNum = "";

function setBeReplyName(name) {
	beReplyName = name;
}

function getBeReplyName() {
	return beReplyName;
}

function setBeReplyNum(num) {
	beReplyNum = num;
}

function getBeReplyNum() {
	return beReplyNum;
}
//获取评论数据
var replyDatas = "";

function setReplyDatas(data) {
	replyDatas = data;
}

function getReplyDatas() {
	return replyDatas;
}
//获取评论索引
var IndexNum = "";

function setIndex(index) {
	IndexNum = index;
}

function getIndex() {
	return IndexNum;
}
//获取回复标识
var flagNum = "";

function setFlag(flag) {
	flagNum = flag;
}

function getFlag() {
	return flagNum;
}

initInputBoxFrame = function($scope) {
	$scope.editor = document.getElementById($scope.inputBoxId);　　
	$scope.win = $scope.editor.contentWindow;　　
	$scope.doc = $scope.win.document;　　
	$scope.doc.designMode = 'On'; //可编辑
	//	$scope.win.focus();
};

function insertIntoInputBox($scope, content) {　　
	//焦点不在html编辑器内容时
	//	$scope.win.focus();　　
	var sel = $scope.win.getSelection(),
		rng = sel.getRangeAt(0),
		frg = rng.createContextualFragment(content);　　
	rng.insertNode(frg);
	var tempRange = document.createRange();
	var a = document.getElementById($scope.inputBoxId);
	tempRange.selectNodeContents(a);
	if (tempRange.commonAncestorContainer.id == $scope.inputBoxId) {
		tempRange.setStart(rng.endContainer, rng.endOffset);
		tempRange.setEnd(rng.endContainer, rng.endOffset);
	} else {
		tempRange.setStartAfter(rng.endContainer.nextSibling);
		tempRange.setEndAfter(rng.endContainer.nextSibling);
	}
	sel.removeAllRanges();
	sel.addRange(tempRange);　　　　　
}

//转码将html编码转为字符编码 
function replace_em(str) {
	str = str.replace(/<span contenteditable=\"true\">/g, '');
	str = str.replace(/<\/span>/g, '');
	str = str.replace(/<div>/g, '');
	str = str.replace(/<\/div>/g, '');
	str = str.replace(/<br>/g, '\n');
	str = str.replace(/<img style=\"vertical-align: middle;margin: 0;padding: 0 1px;\" src=\"styles\/images\/face\/([0-9]*).gif\">/g, '\[em_$1\]');
	str = str.replace(/<img style=\"vertical-align: middle;margin: 0;padding: 0 1px;height: 50px;width: 50px;\" src=\"\">/g, '');

	return str;
}

//转码将字符编码转换为html编码

function replace_html(str) {
	str = str.replace(/\[em_([0-9]*)\]/g, '<img style=\"vertical-align: middle;margin: 0;padding: 0 1px;\" src=\"styles\/images\/face\/$1.gif\">');
	str = str.replace(/\n/g, '<br>');
	str = str.replace(/&lt;/g, '\<');
	str = str.replace(/&gt;/g, '\>');
	return str;
}

function compressImage(filePath) {

}

function transferImageToService(servePath, filePath, onSuccess, onFail) {
	var path = "";
	path = path + filePath;
	var fileName = path.substr(path.lastIndexOf('/') + 1);
	var mimeType = "image/jpeg";
	var opt = {
		'fileKey': 'file',
		'fileName': fileName,
		'mimeType': mimeType || 'audio/3gp'
	};

	var onsuccess = function(response) {
		//bytesSent: 58226
		//headers: Object
		//response: "{\"status\":1,\"data\":[\"mobile-common/images/001/448/610/570/292/e80b2c9c-4de3-4fb1-9f19-2bd273534224.jpg\"]}"
		//responseCode: 200

		var responseCode = response.responseCode;
		if (responseCode == 200) {
			var result = response.response;
			result = result.replace(/\n/g, '');
			var obj = JSON.parse(result);
			if (obj.status == 1) {
				var imgURL = obj.data[0];
				onSuccess(imgURL);
			}
		}

	}

	var onerror = function(response) {
		onFail(response);
	}
	var fileTransfer = new FileTransfer();
	fileTransfer.upload(path, encodeURI(servePath), onsuccess, onerror, opt, true);
}

function compressFile(filePath, onSuccess, onFail) {
	var onsuccesscom = function(imgURL) {
		console.log(imgURL);
		if (imgURL) {
			onSuccess(imgURL);
		}

	}

	var onerrorcom = function(error) {
		onFail(error);
	}
	var pathArray = [];
	pathArray.push(filePath);
	var exec = cordova.require("cordova/exec");
	exec(onsuccesscom, onerrorcom, 'KMSPlugin', 'compress', pathArray);
}

function deleteFiles(filePathArray) {
	var exec = cordova.require("cordova/exec");
	exec(sucess, failed, 'KMSPlugin', 'deleteFile', filePathArray);
}


function pictrueViewer(imgArray) {
    StartMedia.startKmsPicBroswer(imgArray);
//	var exec = cordova.require("cordova/exec");
//	exec(sucess, failed, 'KMSPlugin', 'pictureView', imgArray);
}

function keyboardDown() {
	var exec = cordova.require("cordova/exec");
	exec(sucess, failed, 'KMSPlugin', 'keyboardDown', []);
}

function backToExpress() {
	var exec = cordova.require("cordova/exec");
	exec(sucess, failed, 'ExpressPlugin', 'BackExpress', []);
}

function sucess() {}

function failed() {}

inputBox = function($scope) {
	$scope.sign = {};
	//是否有两行
	$scope.sign.ifInputTwo = true;
	//是否弹出分享和收藏框
	$scope.sign.menuShow = false;
	//是否显示@
	$scope.sign.ifperson = false;
	//是否显示笑脸（选表情）
	$scope.sign.ifsmile = true;
	//点击弹出分享和收藏加号按钮是否显示
	$scope.sign.ifmenu = false;
	//是否显示悬赏按钮
	$scope.sign.ifcoin = false;
	//是否显示五角星按钮
	$scope.sign.ifstar = false;
	//当有两行的情况下，是否显示输入框和发送按钮
	$scope.sign.ifLabelSend = true;
	//发送按钮所显示的字
	$scope.sign.btnWord = "评论";
	$scope.isInputing = true;
	$scope.sign.showKeyboardIf = true;
}
inputBoxImg = function($scope) {
	$scope.sign = {};
	//是否有两行
	$scope.sign.ifInputTwo = true;
	//是否弹出分享和收藏框
	$scope.sign.menuShow = false;
	//是否显示选择图片按钮
	$scope.sign.ifphoto = false;
	//是否显示@
	$scope.sign.ifperson = true;
	//是否显示笑脸（选表情）
	$scope.sign.ifsmile = true;
	//点击弹出分享和收藏加号按钮是否显示
	$scope.sign.ifmenu = false;
	//是否显示悬赏按钮
	$scope.sign.ifcoin = false;
	//是否显示五角星按钮
	$scope.sign.ifstar = false;
	//当有两行的情况下，是否显示输入框和发送按钮
	$scope.sign.ifLabelSend = true;
	//发送按钮所显示的字
	$scope.sign.btnWord = "评论";
	$scope.isInputing = true;
	$scope.sign.showKeyboardIf = true;
}
inputBoxAsk1 = function($scope) {
	$scope.sign = {};
	//是否有两行
	$scope.sign.ifInputTwo = true;
	//是否弹出分享和收藏框
	$scope.sign.menuShow = false;
	//是否显示@
	$scope.sign.ifperson = true;
	//是否显示笑脸（选表情）
	$scope.sign.ifsmile = false;
	//点击弹出分享和收藏加号按钮是否显示
	$scope.sign.ifmenu = false;
	//是否显示悬赏按钮
	$scope.sign.ifcoin = true;
	//是否显示五角星按钮
	$scope.sign.ifstar = false;
	//当有两行的情况下，是否显示输入框和发送按钮
	$scope.sign.ifLabelSend = false;
	//发送按钮所显示的字
	$scope.sign.ifphoto = true;
	$scope.sign.btnWord = "评论";
	$scope.isInputing = true;
}
inputBoxAsk2 = function($scope) {
	$scope.sign = {};
	//是否有两行
	$scope.sign.ifInputTwo = false;
	//是否弹出分享和收藏框
	$scope.sign.menuShow = false;
	//是否显示@
	$scope.sign.ifperson = false;
	//是否显示笑脸（选表情）
	$scope.sign.ifsmile = true;
	//点击弹出分享和收藏加号按钮是否显示
	$scope.sign.ifmenu = true;
	//是否显示悬赏按钮
	$scope.sign.ifcoin = false;
	//是否显示五角星按钮
	$scope.sign.ifstar = false;
	//当有两行的情况下，是否显示输入框和发送按钮
	$scope.sign.ifLabelSend = true;
	//发送按钮所显示的字
	$scope.sign.btnWord = "发送";
	$scope.isInputing = false;
}
inputBoxAsk3 = function($scope) {
	$scope.sign = {};
	//是否有两行
	$scope.sign.ifInputTwo = true;
	//是否弹出分享和收藏框
	$scope.sign.menuShow = false;
	//是否显示@
	$scope.sign.ifperson = true;
	//是否显示笑脸（选表情）
	$scope.sign.ifsmile = false;
	//点击弹出分享和收藏加号按钮是否显示
	$scope.sign.ifmenu = false;
	//是否显示悬赏按钮
	$scope.sign.ifcoin = false;
	//是否显示五角星按钮
	$scope.sign.ifstar = false;
	//当有两行的情况下，是否显示输入框和发送按钮
	$scope.sign.ifLabelSend = false;
	//发送按钮所显示的字
	$scope.sign.ifphoto = true;
	$scope.sign.btnWord = "评论";
	$scope.isInputing = true;
}
inputBoxAsk4 = function($scope) {
	$scope.sign = {};
	//是否有两行
	$scope.sign.ifInputTwo = true;
	//是否弹出分享和收藏框
	$scope.sign.menuShow = false;
	//是否显示@
	$scope.sign.ifperson = true;
	//是否显示笑脸（选表情）
	$scope.sign.ifsmile = true;
	//点击弹出分享和收藏加号按钮是否显示
	$scope.sign.ifmenu = false;
	//是否显示悬赏按钮
	$scope.sign.ifcoin = false;
	//是否显示五角星按钮
	$scope.sign.ifstar = false;
	//当有两行的情况下，是否显示输入框和发送按钮
	$scope.sign.ifLabelSend = true;
	//发送按钮所显示的字
	$scope.sign.btnWord = "发送";
	$scope.isInputing = false;
}

inputBoxAsk5 = function($scope) {
	$scope.sign = {};
	//是否有两行
	$scope.sign.ifInputTwo = true;
	//是否弹出分享和收藏框
	$scope.sign.menuShow = false;
	//是否显示@
	$scope.sign.ifperson = false;
	//是否显示笑脸（选表情）
	$scope.sign.ifsmile = true;
	//点击弹出分享和收藏加号按钮是否显示
	$scope.sign.ifmenu = false;
	//是否显示悬赏按钮
	$scope.sign.ifcoin = false;
	//是否显示五角星按钮
	$scope.sign.ifstar = false;
	//当有两行的情况下，是否显示输入框和发送按钮
	$scope.sign.ifLabelSend = false;
	//发送按钮所显示的字
	$scope.sign.btnWord = "发送";
	$scope.isInputing = false;
}
inputBoxAsk6 = function($scope) {
	$scope.sign = {};
	//是否有两行
	$scope.sign.ifInputTwo = false;
	//是否弹出分享和收藏框
	$scope.sign.menuShow = false;
	//是否显示@
	$scope.sign.ifperson = false;
	//是否显示笑脸（选表情）
	$scope.sign.ifsmile = true;
	//点击弹出分享和收藏加号按钮是否显示
	$scope.sign.ifmenu = false;
	//是否显示悬赏按钮
	$scope.sign.ifcoin = false;
	//是否显示五角星按钮
	$scope.sign.ifstar = false;
	//当有两行的情况下，是否显示输入框和发送按钮
	$scope.sign.ifLabelSend = true;
	//发送按钮所显示的字
	$scope.sign.btnWord = "发送";
	$scope.isInputing = false;
}
inputBoxAsk7 = function($scope) {
	$scope.sign = {};
	//是否有两行
	$scope.sign.ifInputTwo = true;
	//是否弹出分享和收藏框
	$scope.sign.menuShow = false;
	//是否显示@
	$scope.sign.ifperson = false;
	//是否显示笑脸（选表情）
	$scope.sign.ifsmile = false;
	//点击弹出分享和收藏加号按钮是否显示
	$scope.sign.ifmenu = false;
	//是否显示悬赏按钮
	$scope.sign.ifcoin = false;
	//是否显示五角星按钮
	$scope.sign.ifstar = false;
	//当有两行的情况下，是否显示输入框和发送按钮
	$scope.sign.ifLabelSend = true;
	//发送按钮所显示的字
	$scope.sign.btnWord = "回答";
	$scope.sign.ifphoto = true;
	$scope.isInputing = false;
}
inputBoxAsk8 = function($scope) {
	$scope.sign = {};
	//是否有两行
	$scope.sign.ifInputTwo = false;
	//是否弹出分享和收藏框
	$scope.sign.menuShow = false;
	//是否显示@
	$scope.sign.ifperson = false;
	//是否显示笑脸（选表情）
	$scope.sign.ifsmile = false;
	//点击弹出分享和收藏加号按钮是否显示
	$scope.sign.ifmenu = false;
	//是否显示悬赏按钮
	$scope.sign.ifcoin = false;
	//是否显示五角星按钮
	$scope.sign.ifstar = false;
	//当有两行的情况下，是否显示输入框和发送按钮
	$scope.sign.ifLabelSend = true;
	//发送按钮所显示的字
	$scope.sign.btnWord = "追问";
	$scope.sign.ifphoto = false;
	$scope.isInputing = false;
}
inputBoxAsk9 = function($scope) {
	$scope.sign = {};
	//是否有两行
	$scope.sign.ifInputTwo = false;
	//是否弹出分享和收藏框
	$scope.sign.menuShow = false;
	//是否显示@
	$scope.sign.ifperson = false;
	//是否显示笑脸（选表情）
	$scope.sign.ifsmile = false;
	//点击弹出分享和收藏加号按钮是否显示
	$scope.sign.ifmenu = false;
	//是否显示悬赏按钮
	$scope.sign.ifcoin = false;
	//是否显示五角星按钮
	$scope.sign.ifstar = false;
	//当有两行的情况下，是否显示输入框和发送按钮
	$scope.sign.ifLabelSend = true;
	//发送按钮所显示的字
	$scope.sign.btnWord = "评价";
	$scope.sign.ifphoto = false;
	$scope.isInputing = false;
}
inputBoxAsk10 = function($scope) {
	$scope.sign = {};
	//是否有两行
	$scope.sign.ifInputTwo = false;
	//是否弹出分享和收藏框
	$scope.sign.menuShow = false;
	//是否显示@
	$scope.sign.ifperson = false;
	//是否显示笑脸（选表情）
	$scope.sign.ifsmile = false;
	//点击弹出分享和收藏加号按钮是否显示
	$scope.sign.ifmenu = false;
	//是否显示悬赏按钮
	$scope.sign.ifcoin = false;
	//是否显示五角星按钮
	$scope.sign.ifstar = false;
	//当有两行的情况下，是否显示输入框和发送按钮
	$scope.sign.ifLabelSend = true;
	//发送按钮所显示的字
	$scope.sign.btnWord = "回答";
	$scope.sign.ifphoto = false;
	$scope.isInputing = false;
}
inputBoxAsk11 = function($scope) {
	$scope.sign = {};
	//是否有两行
	$scope.sign.ifInputTwo = true;
	//是否弹出分享和收藏框
	$scope.sign.menuShow = false;
	//是否显示@
	$scope.sign.ifperson = true;
	//是否显示笑脸（选表情）
	$scope.sign.ifsmile = true;
	//点击弹出分享和收藏加号按钮是否显示
	$scope.sign.ifmenu = false;
	//是否显示悬赏按钮
	$scope.sign.ifcoin = false;
	//是否显示五角星按钮
	$scope.sign.ifstar = false;
	//当有两行的情况下，是否显示输入框和发送按钮
	$scope.sign.ifLabelSend = false;
	//发送按钮所显示的字
	$scope.sign.ifphoto = true;
	$scope.sign.btnWord = "评论";
	$scope.isInputing = true;
}
setTooltip = function(data) {
		if (data.length > 6) {
			data = data.substr(0, 6);
		}
		var text = $('<span style="color: #ccc;" class="placeholder">' + data + '</span>');
		setTimeout(function() {
			$(window.frames[0].document.body).html(text);
			$(window.frames[0].document.body).on('click', function(event) {
				$(this).find('.placeholder').remove();
			});
			$(window.frames[0].document.body).on('keydown', function(event) {
				$(this).find('.placeholder').remove();
			});
		}, 300);
	}
	// 提示下拉无数据到底了
var isShowNomore = false;
dragUp = function(ionicScrollDelegate, scope) {
		var currentTop = ionicScrollDelegate.getScrollPosition().top;
		var maxTop = ionicScrollDelegate.getMaxTop();
		if (currentTop - maxTop > 50 && maxTop > 0) {
			//		说明可以提示了
			if (!isShowNomore && scope.noMoreItemsAvailable) {
				isShowNomore = true;
				scope.infiniteData = "已经到底啦!";
				$(".infinite-data").show();
				setTimeout(function() {
					$(".infinite-data").hide();
					isShowNomore = false;
				}, 700);
			}

		}
	}
	//过滤时间
utilsTime = function(t) {
	var time = new Date(t).Format('YYYY-MM-DD hh:mm'),
		timeFormat = time.substring(0, time.length - 6),
		Midnight = time.substring(time.length - 6),
		nowDate = new Date().Format('YYYY-MM-DD'),
		Yesterday = new Date(new Date().getTime() - 24 * 60 * 60 * 1000).Format('YYYY-MM-DD');
	switch (timeFormat) {
		case nowDate:
			return '今天' + Midnight;
			break;
		case Yesterday:
			return '昨天' + Midnight;
			break;
		default:
			return timeFormat + Midnight;
			break;
	}
}

checkImageCount = function(imageArr) {
	return imageArr.length <= 5;
}

assembleImageUrl = function(imageUrl) {
	//生产
	//var preURL ="https://kms-mappserver.sf-express.com/KMS/";
	//sit
	var preURL = "http://kms.sit.sf-express.com/KMS/";
	if (imageUrl && imageUrl != '') {
		return preURL + imageUrl;
	}
	return imageUrl;
}

function getIsIOS() {
	var isiOS = device.platform == 'iOS';
	return isiOS;
}