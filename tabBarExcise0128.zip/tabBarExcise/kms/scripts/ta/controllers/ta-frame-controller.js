define(['angularAMD', 'common/services/footer-service', 'ta/services/ta-frame-services', 'common/directive/top-right-dialog', 'mine/services/mine-frame-services', 'common/directive/input-box',
	'common/filters/common-filter', 'common/controllers/staff-selection-controller'
], function(angularAMD) {
	angularAMD.controller('taFrameController', ['$scope', '$ionicModal', '$location', '$rootScope', '$ionicPopup', 'FooterServices', 'taFrameServices', 'MineFrameServices', '$ionicScrollDelegate', '$timeout', '$stateParams',
		function($scope, $ionicModal, $location, $rootScope, $ionicPopup, FooterServices, taFrameServices, MineFrameServices, $ionicScrollDelegate, $timeout, $stateParams) {

			'use strict';
			FooterServices.hide();
			$scope.talkTypeSettings = {};
			$scope.talkTypeSettings.deletable = false;
			$scope.talkTypeSettings.mineRelatedHide = true;
			$scope.talkTypeSettings.showReplyNo = true;
			var workId = $stateParams.workID;
			$scope.listData = [];
			$scope.mine = {};
			$scope.taBasicData = {};
			$scope.title = "人员详情";
			$scope.talkTypeSettings.collectPerson = "TA";
			$scope.type = "polymeric";
			var taId, taName, taHeader;
			//用来判断是否是自己
			$scope.talkTypeSettings.Myself = "taFrame";
			/** 临时用下*/
			$scope.mine.imgUrl = "styles/images/head.jpg";
			/* 临时用下 */
			$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
				scope: $scope,
				animation: 'slide-in-up'
			}).then(function(modal) {
				$scope.modal = modal;
				$scope.modalYes = '是';
				$scope.modalNo = '否';
			});
			//			$scope.listData = MineFrameServices.getMineListData();
			// 当destroy事件时，销毁模块框 (important)
			$scope.$on('$destroy', function() {
				$scope.modal.remove();
			});
			// 选择框的判断事件标志
			var batchSign = '';
			//返回上一页
			$scope.backLogin = function() {
				//history.back(-1);
			};
			//弹出框的处理
			$scope.isBatch = function(flag) {
				if (flag) {
					$scope.taBasicData.isFollowed = !$scope.taBasicData.isFollowed;
					$scope.modal.hide();
				} else {
					$scope.modal.hide();
				}
			};
			//监听关闭弹出键盘
			var closeTaDialog = GetByid("closeTaDialog");

			function touchEnd(event) {
				$rootScope.$broadcast("closeHide", close);
			}
			closeTaDialog.addEventListener("touchend", touchEnd, false);

			function cancelScrollInitFunction() {
				window.setTimeout(function() {
					$scope.$broadcast('scroll.refreshComplete');
				}, 100);
			}
			init();

			function assembleItem() {
				return {
					'startPage': $scope.startPage,
					'pageSize': 4
				};
			}
			//初始化函数执行

			function init() {
				$scope.noMoreItemsAvailable = true;
				$scope.isFirstIn = true;
				$scope.startPage = 0;
				$scope.taBasicData = getTaBasicData(workId);
				getTaFrameList();
			}

			function getTaBasicData(workId) {
				//data = taFrameServices.getTaBasicInfo(workId);
				taFrameServices.getTaBasicInfoData(workId).then(function(res) {
					//					console.log("getTaBasicInfoData", res)
					if (res.status != 1) return;
					if (taHeader == "" || taHeader == null) {
						taHeader = res.data.headPath;
					}
					if (taName == "" || taName == null) {
						taName = res.data.name
					}
					if (taId == "" || taId == null) {
						taId = res.data.empNumber
					}
					$scope.taBasicData = {
						headImgUrl: assembleImageUrl(res.data.headPath),
						name: res.data.name,
						workId: res.data.empNumber,
						departmentName: res.data.deptName,
						position: res.data.position,
						knowledgeNum: res.data.knowledgeCount,
						attentionNum: res.data.attentionCount,
						fansNum: res.data.fansCount,
						hisTalk: res.data.microBlogCount,
						hisLeaveMessage: 50,
						hisAsk: res.data.questionCount,
						hisDiscuss: res.data.discussionCount,
						//是否关注了此人
						isFollowed: res.data.isAttention,
					}
				})


			}
			$scope.showPic = function(src, event) {
				var imgArray = [];
				imgArray.push(src);
				pictrueViewer(imgArray);
				event.stopPropagation();
			};
			$scope.toMessageBox = function() {
				$location.path('/messageBox');
			};
			$scope.clickHisTalk = function() {
				$location.path("/talk-list/ta/" + $stateParams.workID);
				console.log("clickHisTalk");
			}
			$scope.clickHisLeaveMessage = function() {
				$location.path("/leave-message/ta/" + $stateParams.workID);
				console.log("/leave-message/ta/" + $stateParams.workID);
			}
			$scope.clickHisAsk = function() {
				console.log("clickHisAsk");
			}
			$scope.clickQuestion = function() {
				$location.path('/myQuestion');
			}
			$scope.clickHisDiscuss = function() {
				console.log("clickHisDiscuss");
				$location.path("/ta/discuss/" + workId);
			}
			$scope.clickAboutMe = function() {
				$location.path('/ta-question/' + $stateParams.workID);
			};
			$scope.submitMessage = function() {
				//					/private-message-detail/:id
				$location.path('/private-message-detail/' + workId);
			}
			$scope.clickTaAttention = function() {
				console.log("you clicked taAttention");
				url: '/ta/ta-attention-fans/:workID/:attentionorfans',
					$location.path("/ta/ta-attention-fans/" + $stateParams.workID + "/attention");
			}
			$scope.clickTaFans = function() {
					console.log("you clicked taFans");
					$location.path("/ta/ta-attention-fans/" + $stateParams.workID + "/fans");
				}
				// 点击了关注/取消关注Ta
			$scope.followTa = function() {
					// 在此调用接口
					var data = {
						userId: $scope.taBasicData.workId,
						action: ''
					}
					if ($scope.taBasicData.isFollowed) {
						data.action = "unfollow";
					} else data.action = "follow";
					// 在此进行关注、取消关注操作
					//MineFrameServices.getMineAttentionFansData(dataFactor).then(function(res) {
					MineFrameServices.FollowOrUnfollowTa(data).then(function(res) {
						if (res.status == 1) {
							$scope.taBasicData.isFollowed = !$scope.taBasicData.isFollowed;
						}
					});
				}
				// 给用户弹出一个选择框，让其选择是或否

			function selectShow(sign, info) {
				batchSign = sign;
				$scope.modalShow = 3;
				$scope.explain = info;
				$scope.modal.show();
			}
			//获取列表数据

			function getTaFrameList(type) {
				taFrameServices.getTaFrameData(workId, assembleItem()).then(function(res) {
					if (res.status == 1) {
						console.log(res.data);
						getTaBasicData(workId);
						$scope.listData = $scope.listData.concat(traverseData(res.data));
						$scope.noMoreItemsAvailable = res.totalSize == $scope.listData.length;
						cancelScrollInitFunction($scope);
						$scope.$broadcast('scroll.infiniteScrollComplete');
						refreshData(type, res.data.length);
						//						changeAskType($scope.listData);
					} else {
						$ionicPopup.alert({
							template: "<p >" + res.errorMessage + "</p>"
						});
					}
				});
			}
			//对数据遍历

			function traverseData(datas) {
				return _.map(datas, function(data) {
					return {
						imgUrl: assembleImageUrl(taHeader),
						name: taName,
						id: $stateParams.workID,
						publishTime: data.createDate,
						contentId: data.targetId,
						images: data.images,
						contentImgUrl: data.targetImagePath,
						contentTitle: data.targetTitle,
						selectType: data.targetType,
						action: data.action,
						goodNum: data.praiseCount,
						commentNum: data.commentCount,
						isPraise: data.isPraise,
						totalReplyCount: data.commentCount,
						replyContent: getComments(data.comments),
						isSolve: data.isSolve,
						num: data.replyCount,
						questionGold: data.rewardScore
					}
				})
			}

			//对评论数据遍历

			function getComments(items) {
				return _.map(items, function(item) {
					return {
						replyPerson: item.createrName,
						replyPersonId: item.createrId,
						signId: item.id,
						berepliedPerson: item.receiverName,
						berepliedPersonId: item.receiverId,
						replyCont: item.content,
						createDate: item.createDate
					}
				})
			}

			//			function changeAskType(datas) {
			//				
			//				for (var i = 0; i < datas.length; i++) {
			//					if (datas[i].isSolve == '1') {
			//						$scope.solve = "已解决";
			//						$scope.addAsk = "我来补充";
			//						$scope.askColor = "ask-green";
			//					} else {
			//						$scope.solve = "未解决";
			//						$scope.addAsk = "";
			//						$scope.askColor = "ask-blue";
			//					}
			//				}
			//
			//			
			//
			//			}
			$scope.isSlove = function(isSlove) {
				if (isSlove == 1) {
					return '已解决';
				} else {
					return '未解决';
				}
			};
			$scope.answerType = function(isSolve) {
				if (isSolve == 1) {
					return '我来补充';

				} else {
					return '我来回答';
				}
			};
			$scope.IsEmpty = function(data) {
					if (data) {
						return true;
					} else {
						return false;
					}
				}
				/*删除*/
			$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
				scope: $scope,
				animation: 'slide-in-up'
			}).then(function(modal) {
				$scope.modal = modal;
			});
			var isKmsCollect = "",
				deleteContentId = "",
				deleteContentType = "";
			/*删除*/
			$scope.deleteData = function(data) {
				$scope.modalShow = 3;
				isKmsCollect = data.action;
				deleteContentId = data.contentId;
				deleteContentType = data.selectType;
				console.log(isKmsCollect);
				if (data.action == 'collect') {
					$scope.explain = "是否取消收藏？";
				} else {
					$scope.explain = "是否要删除该条数据？";
				}
				$scope.modalYes = "是";
				$scope.modalNo = "否";
				$scope.modal.show();
			}
			$scope.isBatch = function(flag) {
				var items = {};
				if (flag) {
					if (isKmsCollect == 'collect') {
						items.contentId = deleteContentId
						items.contentType = deleteContentType;
						items.saveType = false;
						hotServices.getIsCollect(items).then(function(res) {
							if (res.status == 1) {
								console.log("取消成功");
							} else {
								console.log("取消失败");
							}
						});
						GetByid("list" + items.contentId).remove();
					} else {
						items.targetId = deleteContentId;
						items.targetType = deleteContentType;
						MineFrameServices.deleteMineData(items).then(function(res) {
							if (res.status == 1) {
								console.log("删除成功");
							} else {
								console.log("删除失败");
							}
						});
						GetByid("list" + items.targetId).remove();
					}
					$scope.modal.hide();
				} else {
					$scope.modal.hide();
				}
			};
			//对时间过滤
			$scope.getFilterTime = function(time) {
					return utilsTime(time);
				}
				/*跳转详情*/
			$scope.goAskDetail = function(data) {
				console.log(data.contentId);
				$location.path('/asksDetail/' + data.contentId);
			};
			$scope.goDeatil = function(data) {
				console.log(data);
				$location.path('/hotDetail/' + data.contentId + "/" + data.selectType);
			}
			$scope.goMicroblogDetail = function(data) {
					$location.path('/talk-detail/' + data.contentId + "/" + data.id);
				}
				/*我来补充*/
			$scope.toAnswerQuestion = function(data) {
					console.log(data.contentId);
					$location.path('/create-answer/' + data.contentId);
				}
				//转换表情
			$scope.changeData = function(data) {
					if (data != null) {
						return replace_html(data);
					}
				}
				// 移除modalPay
			$scope.$on('$destroy', function() {
				$scope.modal.remove();
			});
			//过滤表情
			$scope.getToRefer = function(data) {
					return replace_html(data);
				}
				//处理知识不能删除
			$scope.hideKnowledge = function(type) {
				if (type == 'knowledge') {
					return false;
				} else {
					return true;
				}
			}

			//上下拉刷新数据条数 

			function refreshData(type, length) {
				if (type == "refresh") {
					if (length > 0) {
						$scope.refresherData = "已经为您更新" + length + "条数据";
						$(".refresher-data").show();
						$timeout(function() {
							$(".refresher-data").hide();
						}, 1500);
					}

				} else if (type == "loadMore") {
					if (length > 0) {
						$scope.infiniteData = "已经为您加载" + length + "条数据";
						$(".infinite-data").show();
						$timeout(function() {
							$(".infinite-data").hide();
						}, 1500);
					}
				}
				mineNoData(length);
			}
			// 下拉刷新
			$scope.onRefresh = function() {
					$scope.listData = [];
					$scope.startPage = 0;
					getTaFrameList("refresh");
				}
				// 加载更多
			$scope.loadMore = function() {
				if ($scope.noMoreItemsAvailable) {
					$scope.$broadcast('scroll.infiniteScrollComplete');
					return;
				}
				if ($scope.isFirstIn) {
					$scope.isFirstIn = false;
					$scope.$broadcast('scroll.infiniteScrollComplete');
					return;
				} else {
					$scope.isFirstIn = true;
					$scope.startPage++;
					getTaFrameList("loadMore");
				}


			}

			//调用输入框
			$scope.showInputBox = function() {
				inputBox($scope);
				$scope.$broadcast("inputOnFocus");
			}
			$scope.showInputBoxImg = function() {
				inputBoxImg($scope);
				$scope.$broadcast("inputOnFocus");
			}


			//下拉提示到底了
			$scope.scrollDragUp = function() {
					dragUp($ionicScrollDelegate, $scope);
				}
				//输入框提示语
			$scope.setHalohoder = function(mess) {
				$timeout(function() {
					$scope.$broadcast("inputBoxPlaceholder", mess);
				}, 50);
			};
			$scope.getImageUrl = function(url) {
				return assembleImageUrl(url) + '.thumbnail';
			};
			$scope.clickImg = function(path, images, event) {
				var imgArray = [];
				_.each(images, function(content) {
					imgArray.push(assembleImageUrl(content.path));
				});
				var index = 0;
				for (var i = 0; i < images.length; i++) {
					if (imgArray[i] == assembleImageUrl(path)) {
						index = i;
					}
				}
				imgArray.unshift(index);
				pictrueViewer(imgArray);
				event.stopPropagation();
			};
		}
	])
});