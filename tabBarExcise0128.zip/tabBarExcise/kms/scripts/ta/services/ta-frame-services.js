define(['angularAMD', 'global'], function(angularAMD) {
	angularAMD.factory('taFrameServices', ["$http", "$q", "Global",
		function($http, $q, Global) {
			var getPromise = function(p) {
				var defer = $q.defer();
				p.success(function(response) {
					return defer.resolve(response);
				}).error(function() {
					return defer.reject();
				});
				return defer.promise;
			};
			return {
				/**
				 *获得他的问题列表 
				 * @param {Object} item
				 */
				getTaAskInfoList: function(item) {
					var url = Global.apiPath + '/usermessage/question/posted/' + item.empNumber + '?startPage=' + item.startPage + '&pageSize=' + item.pageSize;
					return getPromise($http.get(url));
				},
				/**
				 *获得他的回答列表 
				 * @param {Object} item
				 */
				getTaAskAnswerInfoList: function(item) {
					var url = Global.apiPath + '/usermessage/question/answered/' + item.empNumber + '?startpage=' + item.startPage + '&pageSize=' + item.pageSize;
					return getPromise($http.get(url));
				},
				/**
				 *获得他的关注列表 
				 * @param {Object} item
				 */
				getTaAskAttentionInfoList: function(item) {
					var url = Global.apiPath + '/usermessage/question/followed/' + item.empNumber + '?startPage=' + item.startPage + '&pageSize=' + item.pageSize;
					return getPromise($http.get(url));
				},

				// 获取ta的基本信息
				getTaBasicInfoData:function(workId){
				//  接口地址	http://10.202.4.75:8180/KMS-MSERVER/usermessage/detail/{empNumber}						
					var url = Global.apiPath+"/usermessage/detail/"+workId;
					return getPromise($http.get(url));
				},
				getTaDiscussData:function(dataFactor){
					console.log(dataFactor);
					// http://10.202.4.75:8180/KMS-MSERVER/usermessage/discussions/{empNumber}						
					var url = Global.apiPath +'/usermessage/discussions/'+dataFactor.workId+"?startPage="+dataFactor.startPage+"&pageSize="+dataFactor.pageSize;
					return getPromise($http.get(url));
				},
				getTaFrameData: function(workId,data){
					var url = Global.apiPath + '/usermessage/dynamics/'+ workId + '?'+$.param(data);
					return getPromise($http.get(url));
				},
				getTaAttentionFansData:function(dataFactor){
					 if(dataFactor.isFansKind){
						// 是ta的粉丝  http://10.202.4.75:8180/KMS-MSERVER/usermessage/fans/{empNumber}						
						var url = Global.apiPath + "/usermessage/fans/"+dataFactor.workID+"?startPage="+dataFactor.startPage+"&pageSize="+dataFactor.pageSize+"&searchKey="+dataFactor.searchKey;
					}else{
						// 是ta的关注 http://10.202.4.75:8180/KMS-MSERVER/usermessage/attention/persons/{empNumber}										
						var url = Global.apiPath + "/usermessage/attention/persons/"+dataFactor.workID+"?startPage="+dataFactor.startPage+"&pageSize="+dataFactor.pageSize+"&searchKey="+dataFactor.searchKey;
					}
					return getPromise($http.get(url));
				}
			};
		}
	]);
});