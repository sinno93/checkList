define(['angularAMD', 'common/services/footer-service', 'hot/services/hot-services', 'mine/services/mine-frame-services','ta/services/ta-frame-services', 'common/controllers/staff-selection-controller', 'common/directive/hot-list-item', 'common/filters/common-filter'], function(angularAMD) {
	angularAMD.controller('mineDiscussController', ['$scope', '$stateParams', '$ionicModal', '$location', '$rootScope', '$ionicPopup', 'MineFrameServices','taFrameServices', 'hotServices', 'FooterServices', '$ionicScrollDelegate', '$timeout',
		function($scope, $stateParams, $ionicModal, $location, $rootScope, $ionicPopup, MineFrameServices,taFrameServices, hotServices, FooterServices, $ionicScrollDelegate, $timeout) {
			'use strict';
			FooterServices.hide();
			console.log($stateParams.workID);
			var isTa;
			if($stateParams.workID){
				$scope.title = "TA的讨论";
				isTa = true;
			}
			else{
				$scope.title = "我的讨论";
				isTa = false;
			}
			
			$scope.listData = [];

			function assembleItem() {
					if(!isTa){
					return {
						'startPage': $scope.startPage,
						'pageSize': 8
					}
					}else{
						return{
							'startPage': $scope.startPage,
							'pageSize': 8,
							'workId':$stateParams.workID
						}
					}
				}
				//初始化
			init();

			function init() {
					$scope.noMoreItemsAvailable = true;
					$scope.isFirstIn = true;
					$scope.startPage = 0;
					getData();
				}
				//请求数据

			function getData(type) {
				    if(!isTa){
					MineFrameServices.getMineDiscuss(assembleItem()).then(function(res) {
						console.log(res);
						if (res.status == 1) {
							$scope.listData = $scope.listData.concat(traverseData(res.data));
							$scope.noMoreItemsAvailable = res.totalSize == $scope.listData.length;
							cancelScrollInitFunction($scope);
							$scope.$broadcast('scroll.infiniteScrollComplete');
							refreshData(type, res.data.length);
						} else {
							$ionicPopup.alert({
								template: "<p >" + res.errorMessage + "</p>"
							});
						}

					})
					}else{
						taFrameServices.getTaDiscussData(assembleItem()).then(function(res) {
						console.log(res);
						if (res.status == 1) {
							$scope.listData = $scope.listData.concat(traverseData(res.data));
							$scope.noMoreItemsAvailable = res.totalSize == $scope.listData.length;
							cancelScrollInitFunction($scope);
							$scope.$broadcast('scroll.infiniteScrollComplete');
							refreshData(type, res.data.length);
						} else {
							$ionicPopup.alert({
								template: "<p >" + res.errorMessage + "</p>"
							});
						}

					})
					}
				}
				//上下拉刷新数据条数 

			function refreshData(type, length) {
					if (type == "refresh") {
						if (length > 0) {
							$scope.refresherData = "已经为您更新" + length + "条数据";
							$(".refresher-data").show();
							$timeout(function() {
								$(".refresher-data").hide();
							}, 1500);
						}

					} else if (type == "loadMore") {
						if (length > 0) {
							$scope.infiniteData = "已经为您加载" + length + "条数据";
							$(".infinite-data").show();
							$timeout(function() {
								$(".infinite-data").hide();
							}, 1500);
						}
					}
					NoData(length,1);
				}
				// 对数据遍历

			function traverseData(datas) {
					return _.map(datas, function(data) {
						return {
							chType: "讨论",
							type: "theme",
							date: data.createrDate,
							contentId: data.id,
							title: data.theme,
							imageUrl: assembleImageUrl(data.imagePath)
						}
					})
				}
				//跳转详情
			$scope.goDeatil = function(data) {
					console.log(data);
					$location.path('/hotDetail/' + data.contentId + "/" + data.type);
				}
				// 下拉刷新
			$scope.onRefresh = function() {
					$scope.listData = [];
					$scope.startPage = 0;
					getData("refresh");
				}
				// 加载更多
			$scope.loadMore = function() {
				if ($scope.noMoreItemsAvailable) {
					$scope.$broadcast('scroll.infiniteScrollComplete');
					return;
				}
				if ($scope.isFirstIn) {
					$scope.isFirstIn = false;
					$scope.$broadcast('scroll.infiniteScrollComplete');
					return;
				} else {
					$scope.isFirstIn = true;
					$scope.startPage++;
					getData("loadMore");
				}
			}
							//下拉提示到底了
			$scope.scrollDragUp = function() {
				dragUp($ionicScrollDelegate, $scope);
			}

		}
	])

});