define(['angularAMD', 'common/services/footer-service', 'mine/services/mine-frame-services', 'common/filters/common-filter', 'common/directive/input-box', 'asks/services/ask-services'], function(angularAMD) {
	angularAMD.controller('minePrivateMessageDetailController', ['$scope', '$ionicModal', '$stateParams', '$location', '$rootScope', 'FooterServices', '$ionicScrollDelegate', 'asksServices', 'MineFrameServices', '$timeout',
		function($scope, $ionicModal, $stateParams, $location, $rootScope, FooterServices, $ionicScrollDelegate, asksServices, MineFrameServices, $timeout) {
			'use strict';
			FooterServices.hide();
			$scope.title = '私信会话';
			var DEFAULT_PAGE_SIZE = 8;
			var relationID = $stateParams.id;
			var myID = getMyId();
			var headPath = getHeadPath();
			$scope.type = 'private';

			function assembleItem() {
				return {
					'empNumber': relationID,
					'startPage': $scope.startPage,
					'pageSize': DEFAULT_PAGE_SIZE
				};
			}

			function assemblePostItem(replyContent) {
				return {
					'content': replyContent,
					'receiverId': relationID
				}
			}

			function cancelScrollInitFunction() {
				$timeout(function() {
					$scope.$broadcast('scroll.refreshComplete');
				}, 100);
			}
			$scope.transCode = function(content) {
				return replace_html(content);
			};

			function checkAvailableItems(total) {
				$scope.noMoreItemsAvailable = $scope.items.length === total;
			}

			function pushMyPostInfo(replyContent) {
				return {
					'content': replyContent,
					'senderDate': Date.parse(new Date()),
					'senderHeadPath': headPath,
					'senderId': myID,
					'senderName': 'text'
				};
			}

			function init() {
				$scope.startPage = 0;
				$scope.noMoreItemsAvailable = true;
				inputBoxAsk6($scope);
				MineFrameServices.getMyPrivateMessageDetail(assembleItem()).then(function(response) {
					console.log(response);
					$scope.items = response.data;
					$ionicScrollDelegate.scrollBottom(true);
					checkAvailableItems(response.totalSize);
					cancelScrollInitFunction();
				});
				if (headPath == null || headPath == '') {
					asksServices.getUserInfo().then(function(response) {
						console.log(response);
						headPath = response.data.headPath;
						setHeadPath(headPath);
					});
				}
			}
			$scope.isMine = function(item) {
				return item.senderId == myID;
			};
			$scope.goDetailPage = function(item){
				$location.path('/ta/'+item.senderId);
			};
			$scope.getName = function(item) {
				return item.senderName + item.senderId;
			};
			init();

			function ifFirstIn(reflength) {
				if ($scope.mFirstFlag) {
					$timeout(function() {
						$ionicScrollDelegate.scrollBottom(true);
					}, 500);

					$scope.mFirstFlag = false;
				} else {
					$ionicScrollDelegate.scrollTo(0, document.documentElement.clientHeight, true);
				}

			}
			$scope.post = function(data) {
				MineFrameServices.sendPrivateMessage(assemblePostItem(data)).then(function(response) {
					if (response.status == 1) {
						$scope.items.push(pushMyPostInfo(data));
						$ionicScrollDelegate.scrollBottom(true);
					}
				});
			}

			function refreshFinish(length) {
				if (length > 0) {
					$scope.refresherData = "已经为您更新" + length + "条数据";
					$(".refresher-data").show();
					$timeout(function() {
						$(".refresher-data").hide();
					}, 1500);
				}
			}
			$scope.isFirstIn = true;
			$scope.onRefresh = function() {
				console.log('refresh');
				if ($scope.noMoreItemsAvailable) {
					$scope.$broadcast('scroll.infiniteScrollComplete');
					return;
				}
				if ($scope.isFirstIn) {
					$scope.isFirstIn = false;
					$scope.$broadcast('scroll.infiniteScrollComplete');
					return;
				}
				$scope.startPage++;
				MineFrameServices.getMyPrivateMessageDetail(assembleItem()).then(function(response) {
					console.log('getmore');
					var newItem = response.data;
					_.each(newItem, function(item) {
						$scope.items.unshift(item);
					});
					cancelScrollInitFunction();

					checkAvailableItems(response.totalSize);
					refreshFinish(newItem.length);
				});
			};
			
			$scope.dealPath = function(url){
				return assembleImageUrl(url);
			};

		}
	]);
});