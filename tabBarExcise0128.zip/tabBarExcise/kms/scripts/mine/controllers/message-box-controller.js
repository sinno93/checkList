define(['angularAMD', 'common/services/footer-service', 'mine/services/mine-frame-services'], function(angularAMD) {
	angularAMD.controller('messageBoxController', ['$scope', '$ionicModal', '$location', '$rootScope', 'FooterServices', 'MineFrameServices', '$ionicScrollDelegate', '$timeout',
		function($scope, $ionicModal, $location, $rootScope, FooterServices, MineFrameServices, $ionicScrollDelegate, $timeout) {
			'use strict';
			FooterServices.hide();

			var DEFAULT_PAGE_SIZE = 10;





			function initPage() {
				$scope.startPage = 0;
				$scope.pageSize = DEFAULT_PAGE_SIZE;
				$scope.noMoreItemsAvailable = true;
			}

			function init() {

				initPage();
				MineFrameServices.getMineMessageBoxInfo(assembleRequest()).then(function(response) {
					console.log(response);
					$scope.items = response.data;
					
					checkAvailableItems(response.totalSize);
					cancelScrollInitFunction();
					NoData($scope.items.length, 1);
				});
				getNewCount();
			}

			init();

			function getNewCount() {
				MineFrameServices.hasNewMessage().then(function(response) {
					if(response.data){
						$scope.title = '消息盒子(' + response.data + ')';
					}else{
						$scope.title = '消息盒子';
					}
					
				});
			}

			
			function assembleRequest() {
				return {
					'startPage': $scope.startPage,
					'pageSize': $scope.pageSize
				};
			}

			$scope.goMessageDetail = function(item) {
				if (item.contentType == 'knowledge' || item.contentType == 'blog') {
					$location.path('/hotDetail/' + item.contentId + '/' + item.contentType);
				} else if (item.contentType == 'iask') {
					$location.path('/asksDetail/' + item.contentId);
				} else if (item.contentType == 'community') {
					$location.path('/community-detail/' + item.contentId);
				} else if(item.contentType == 'theme'){
					$location.path('/hotDetail/'+item.contentId+'/'+item.contentType);
				}
			};

			function refreshData(type, length) {
				if (type == "refresh") {
					if (length > 0) {
						$scope.refresherData = "已经为您更新" + length + "条数据";
						$(".refresher-data").show();
						$timeout(function() {
							$(".refresher-data").hide();
						}, 1500);
					}

				} else if (type == "loadMore") {
					if (length > 0) {
						$scope.infiniteData = "已经为您加载" + length + "条数据";
						$(".infinite-data").show();
						$timeout(function() {
							$(".infinite-data").hide();
						}, 1500);
					}
				}
			}

			function checkNewItemsCount(newItems, items) {
				var count = 0;
				var temp = items[0].senderDate;
				for (var i = 0; i < newItems.length; i++) {
					if (newItems[i].senderDate != temp) {
						if (i == 0) {
							items.unshift(newItems[i]);
						} else {
							items.splice(i, 0, newItems[i]);
						}
						count++;
					} else {
						break;
					}
				}
				return count;
			}
			
			$scope.headPath = function(src){
				return assembleImageUrl(src);
			};
			$scope.onRefresh = function() {
				MineFrameServices.getMineMessageBoxInfo({
					'startPage': 0,
					'pageSize': $scope.pageSize
				}).then(function(response) {
					var newItems = response.data;
					var count = checkNewItemsCount(newItems, $scope.items);
					refreshData('refresh', count);
					cancelScrollInitFunction();
				});
			}

			function cancelScrollInitFunction() {
				$timeout(function() {
					$scope.$broadcast('scroll.refreshComplete');
				}, 100);
			}

			function checkAvailableItems(total) {
				$scope.noMoreItemsAvailable = $scope.items.length === total;
			}

			$scope.isFirstIn = true;
			$scope.loadMore = function() {
				if ($scope.noMoreItemsAvailable) {
					$scope.$broadcast('scroll.infiniteScrollComplete');
					return;
				}
				if ($scope.isFirstIn) {
					$scope.isFirstIn = false;
					$scope.$broadcast('scroll.infiniteScrollComplete');
					return;
				}
				$scope.startPage++;
				MineFrameServices.getMineMessageBoxInfo(assembleRequest()).then(function(response) {
					var newItems = response.data;
					_.each(newItems, function(item) {
						$scope.items.push(item);
					});
					$scope.$broadcast('scroll.infiniteScrollComplete');

					checkAvailableItems(response.totalSize);
					refreshData('loadMore', newItems.length);
				});
			};
		}
	])

});