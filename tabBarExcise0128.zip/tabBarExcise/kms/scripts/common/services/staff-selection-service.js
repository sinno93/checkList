define(['angularAMD', 'global'], function(angularAMD) {
	angularAMD.factory('staffSelectionServices', ["$http", "$q", "Global",
		function($http, $q, Global) {
			var getPromise = function(p) {
				var defer = $q.defer();
				p.success(function(response) {
					return defer.resolve(response);
				}).error(function() {
					return defer.reject();
				});
				return defer.promise;
			};
			return {
				//人员选择器
				staffSelectionData: function(data) {
					var url = Global.apiPath + "/mymessage/friends?" + $.param(data);
					return getPromise($http.get(url));
				},
				//全网搜索
				staffSelectionAllData: function(data) {
					var url = Global.apiPath + "/usermessage/user/search?" + $.param(data);
					return getPromise($http.get(url));
					
				},
				//分享
				shareData:function(data){
					var url = Global.apiPath + "/share/toShare?" + $.param(data);
					return getPromise($http.get(url));
				}
			};


		}
	]);

});