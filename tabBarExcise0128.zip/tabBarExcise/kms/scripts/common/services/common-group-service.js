define(['angularAMD', 'global'], function(angularAMD) {
	angularAMD.factory('commonGroupServices', ["$http", "$q", "Global",
		function($http, $q, Global) {

			return {

				getMyQuestionGroup:function(){
					return [{
						text:'我的问题',
						name:'myQuestion'
					},{
						text:'我的回答',
						name:'myAnswer'
					},{
						text:'我的关注',
						name:'myAttention'
					}];
				},
				getTaQuestionGroup:function(){
					return [{
						text:'TA的问题',
						name:'taQuestion'
					},{
						text:'TA的回答',
						name:'taAnswer'
					},{
						text:'TA的关注',
						name:'taAttention'
					}];
				},
				getHotTabGroup: function() {
					return [{
							'text': '全部',
							'name': 'hotIndex',
							'type':''
						},
						{
							'text': '知识',
							'name': 'hotKnowledge',
							'type':'knowledge'
						},
						{
							'text': '讨论',
							'name': 'hotTheme',
							'type':'theme'
						},
						{
							'text': '博客',
							'name': 'hotBlog',
							'type':'blog'
						}];
				}
			};


		}
	]);

});