define(['angularAMD'], function(angularAMD) {

	angularAMD.factory('LoadingInterceptor', ['$q', '$rootScope', function($q, $rootScope) {

		$rootScope.pendingRequests = 0;

		function activeLoadingStatus() {
			if ($rootScope.pendingRequests !== 0) {
				$rootScope.$broadcast("activeLoadingStatus");
			}
		}

		function inActiveLoadingStatus() {
			if ($rootScope.pendingRequests === 0) {
				$rootScope.$broadcast("inActiveLoadingStatus");
			}
		}

		function addPendingRequest() {
			$rootScope.pendingRequests++;
			activeLoadingStatus();
		}

		function removePendingRequest() {
			$rootScope.pendingRequests--;
			inActiveLoadingStatus();
		}

		return {
			'request': function(config) {
				var reg = /\.html$/;
				var zurl = config.url;
				var isUrl = reg.test(zurl)
				if (!isUrl) {
					addPendingRequest();
				}
				return config || $q.when(config);
			},

			'requestError': function(rejection) {
				removePendingRequest();
				return $q.reject(rejection);
			},

			'response': function(response) {
				var reg = /\.html$/;
				var zurl = response.config.url;
				var isUrl = reg.test(zurl)
				if (!isUrl) {
					removePendingRequest();
				}
				return response || $q.when(response);
			},

			'responseError': function(rejection) {
				removePendingRequest();
				return $q.reject(rejection);
			}
		};
	}])

});