define(['angularAMD', 'common/services/footer-service', 'common/services/leave-message-services', 'common/directive/input-box', 'common/controllers/staff-selection-controller'], function(angularAMD) {
	angularAMD.controller('leaveMessageCreateController', ['$scope', 'Global', '$timeout', '$stateParams', '$ionicModal', '$ionicPopup', '$ionicLoading', '$location', '$rootScope', 'FooterServices', '$ionicScrollDelegate', 'leaveMessageServices',
		function($scope, Global, $timeout, $stateParams, $ionicModal, $ionicPopup, $ionicLoading, $location, $rootScope, FooterServices, $ionicScrollDelegate, leaveMessageServices) {
			'use strict';
			var parameter = {};
			parameter.workID = $stateParams.workID;

			var showDialogbox1 = function(callback) { //确认发送留言
				$scope.explain = "确认发送留言？";
				$scope.modalYes = "确定";
				$scope.modalNo = "取消";
				$scope.modalShow = 3;
				$scope.isBatch = function(flag) {
					if (flag) {
						callback();
					}
					$scope.modal.hide();
				};
				$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
					scope: $scope,
					animation: 'slide-in-up'
				}).then(function(modal) {
					$scope.modal = modal;
					$scope.modal.show();
				});
			}
			var showDialogbox2 = function(text) { /*提示已经保存*/
				$scope.modalShow = 10;
				$scope.collectContent = text;
				$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
					scope: $scope,
					animation: 'slide-in-up'
				}).then(function(modal) {
					$scope.modal = modal;
					$scope.modal.show();
					$timeout(function() {
						$scope.modal.hide();
					}, 1000);
				});
			}

			/*初始函数*/
			var init = function() {
				inputBoxAsk5($scope);
				$scope.sign.showKeyboardIf = true;
				var updateTextarea = function() {
					var h = $(window).height() - $(".input-common").height() - 50;
					$(".textarea").height(h);
				}
				$(window).on('touchstart', function(obj) {
					keyboardDown();
				});
				setInterval(function() {
					//updateTextarea();
				}, 100);
				FooterServices.hide();
				$scope.title = "留言";
				$(window).on('touchstart', function(obj) {
					keyboardDown();
				});
			}
			init();

			$scope.submitMessage = function() {
				if ($(document.getElementById("emoijid").contentWindow.document.body).html() == '') {
					showDialogbox2('请将留言内容填写完整');
					return;
				}
				showDialogbox1(function() {
					var $content = $(document.getElementById("emoijid").contentWindow.document.body);
					var data = {};
					data.content = $content.html();
					data.content = replace_em(data.content);
					data.workId = parameter.workID;
					data.parentId = parameter.parentId;
					data.isNeedParentid = parameter.isNeedParentid;
					leaveMessageServices.sendLeaveMessage(data).then(function(result) {
						if (result.status == 1) {
							showDialogbox2('留言已发送');
							history.back(-1);
						}else{
							$ionicPopup.alert({
								template: "<p >" + result.errorMessage + "</p>"
							});
						}
					});
				});
			};
		}
	]);

});