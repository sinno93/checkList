define(['angularAMD', 'common/directive/expression-package', 'hot/services/hot-detail-services', 'hot/services/hot-services', 'common/controllers/staff-selection-controller'], function(angularAMD) {
	angularAMD.directive('inputBox', ['$rootScope', '$ionicScrollDelegate', '$timeout', '$ionicModal', '$ionicActionSheet', 'HotDetailServices', 'hotServices', '$ionicPopup', "Global",
		function($rootScope, $ionicScrollDelegate, $timeout, $ionicModal, $ionicActionSheet, HotDetailServices, hotServices, $ionicPopup, Global) {
			return {
				//E - 元素名称：<my-directive></my-directive>
				//A - 属性： <div my-directive="exp"> </div>
				//C - 类名：<div class="my-directive: exp;"></div>
				//M - 注释： <!-- directive: my-directive exp -->
				restrict: 'E',
				replace: true,
				scope: true,
				templateUrl: 'views/common/directive/input-box.html',
				link: function(scope) {
					var text = "";
					/**
					 * 初始化函数
					 */
					$rootScope.$on("close", function() {
						$(".input-common").hide();
						$(".tabs").show();
					});

					function inite() {
						console.log("input-box");
						//不显示表情插件
						scope.ifExpression = false;
						if (!scope.inputBoxId || scope.inputBoxId == "") {
							scope.inputBoxId = "emoijid";
						}

						$timeout(function() {
							initInputBoxFrame(scope);
							if (scope.sign.showKeyboardIf && scope.sign.showKeyboardIf == true)
								$timeout(function() {
									scope.doc.body.focus();
									scope.win.focus();
								}, 100);
							$timeout(function() {
								$(scope.doc.body).attr("style", "word-break: break-all;");
							}, 100);
							var inputBox = scope.inputBoxId == "emoijid" ? "emoijid" : scope.inputBoxId;
							if (scope.sign.ifLabelSend) {
								$(scope.doc).on("keydown", function(event) {
									if (event.keyCode == 8) {
										$timeout(function() {
											console.log($(scope.doc).find("div").length);
											var divLength = $(scope.doc).find("div").length;
											switch (divLength) {
												case 0:
													$('#' + inputBox).height(35);
													break;
												case 1:
													$('#' + inputBox).height(54);
													break;
												case 2:
													$('#' + inputBox).height(72);
													break;
												default:
													$('#' + inputBox).height(80);
													break;
											}
										}, 200);
									}
								});
							}
							$(scope.doc).on("click", function(event) {
								scope.inputClick();
							});
							$(scope.doc).on("touchend", function(event) {
								scope.inputClick();
							});
						}, 100);

					};

					//点击笑脸按钮
					scope.chooseSmile = function() {
						console.log("smile");
						//如果表情插件显示则隐藏，表情插件隐藏则显示
						scope.ifExpression = !scope.ifExpression;
						//收藏与分享弹框隐藏
						scope.sign.menuShow = false;
						scope.win.focus();
						var exec = cordova.require("cordova/exec");
						exec(sucess, failed, 'KMSPlugin', 'keyboardDown', []);
					};

					function sucess() {}

					function failed() {}
					//点击悬赏的￥符号按钮
					scope.chooseCoin = function() {
						var showDialogbox = function() { /*积分选择*/
							scope.explain = "";
							scope.modalYes = "确定";
							scope.modalNo = "取消";
							scope.modalShow = 5;
							var setScoreList = function(length) {
								var list = [];
								list.push({
									score: 0,
									scoreName: '',
									selected: 0
								});
								list.push({
									score: 0,
									scoreName: 0 + "积分",
									selected: 0
								});
								for (var i = 1; i < (length + 1); i++) {
									var item = {
										score: i,
										scoreName: i + "积分",
										selected: 0
									}
									list.push(item);
								};
								list.push({
									score: 0,
									scoreName: '',
									selected: 0
								});
								list[1].selected = 1;
								return list;
							}
							scope.scoreList = setScoreList(scope.topScore > 200 ? 200 : scope.topScore);
							var rewardScore = 0;
							scope.html = 'views/common/score-list.html';
							scope.isBatch = function(flag) {
								if (flag) {
									scope.$emit("inputCoinSeleced", rewardScore);
								}
								scope.modal.hide();
							};
							$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
								scope: scope,
								animation: 'slide-in-up'
							}).then(function(modal) {
								scope.modal = modal;
								scope.modal.show();
							});

							var direct;
							scope.onScroll = function(dir) {
								if (dir) {
									direct = dir;
									return false;
								}
								var top = -1 * parseInt($(".score-scroll").find(".scroll").last().attr("style").split(",")[1]);
								var num;
								if (direct == 'up') {
									num = parseInt((top + 24) / 47);
									num = num + 1;
								} else {
									num = parseInt((top + 24) / 47);
									num = num + 1;
								}
								$(".score-scroll").find("li").removeClass('on');
								$(".score-scroll").find("li:eq(" + num + ")").addClass('on');
								rewardScore = $(".score-scroll").find(".scroll").last().find('li.on').data("score");
							}
						};
						showDialogbox();
						//隐藏表情插件
						scope.ifExpression = false;
					};
					$rootScope.chooseCoin = scope.chooseCoin;
					//点击五角星收藏按钮
					scope.chooseStar = function() {
						console.log("chooseStar");
						//隐藏表情插件
						scope.ifExpression = false;
					};
					//点击选择图片按钮
					scope.choosePhoto = function() {
						console.log("photo");
						//隐藏表情插件
						scope.ifExpression = false;
						//隐藏收藏与分享弹框
						scope.sign.menuShow = false;
						scope.win.focus();
						var exec = cordova.require("cordova/exec");
						exec(sucess, failed, 'KMSPlugin', 'keyboardDown', []);
						return openActionSheet();

					};

					var getCameraOptions = function(sourceType, saveToPhotoAlbumIf) {
						return {
							sourceType: sourceType,
							saveToPhotoAlbum: saveToPhotoAlbumIf,
							destinationType: window.Camera.DestinationType.FILE_URI
						};
					};

					var successCallback = function(imageInfo) {
						if (getIsIOS()) {
							console.log(imageInfo);
							var str = "";
							str = imageInfo;
							str = str.replace(/\n/g, '');
							var obj = JSON.parse(str);
						} else {
							var obj = imageInfo;
						}


						console.log(obj);
						console.log(obj.thumbnail);
						console.log(obj.original);
						if (scope.sign.imageUrlDirectory == true) {
							scope.getImageUrl(obj);
							return;
						}
						scope.addImageElement(obj.original);
						insertIntoInputBox(scope, "<img style='vertical-align: middle;margin: 0;padding: 0 1px;height: 50px;width: 50px;' src='" + obj.original + "'>");
					};

					var errorCallback = function() {
						console.log('Error!');
					};

					function onSuccess(response) {
						console.log(response);
					}

					function onError(response) {
						console.log(response);
					}

					var getPhotoFrom = function(sourceType, saveToPhotoAlbumIf) {
						navigator.camera.getPicture(successCallback, errorCallback, getCameraOptions(sourceType, saveToPhotoAlbumIf));
						return true;
					};

					var takingButton = {
						text: '拍照',
						translate: "STATIC.TASK_TAKING_PICTURES",
						click: function() {
							return getPhotoFrom(window.Camera.PictureSourceType.CAMERA, true);
						}
					};

					var pickingButton = {
						text: '相册',
						translate: "STATIC.TASK_TAKING_PICKINGBUTTON",
						click: function() {
							return getPhotoFrom(window.Camera.PictureSourceType.PHOTOLIBRARY, false);
						}
					};

					var openActionSheet = function() {
						$ionicActionSheet.show({
							buttons: [takingButton, pickingButton],
							cancelText: '取消',
							buttonClicked: function(index) {
								return this.buttons[index].click();
							},
							cancel: function() {}
						});
					};

					//点击@按钮
					scope.$on('personComplete', function(event, data) {
						addPersonToInput(data);
					});

					function addPersonToInput(data) {
						scope.win.focus();
						scope.doc.body.focus();
						$(scope.doc.body).find('.placeholder').remove();
						if (data && data.length > 0) {
							for (var i = 0; i < data.length; i++) {
								insertIntoInputBox(scope, "<span contenteditable='true' >@" + data[i] + "</span>");
							}
						}
					}
					scope.showDialog = function(text) { /*提示*/
						scope.modalShow = 10;
						scope.collectContent = text;
						$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
							scope: scope,
							animation: 'slide-in-up'
						}).then(function(modal) {
							scope.modal = modal;
							scope.modal.show();
							$timeout(function() {
								scope.modal.hide();
							}, 1000);
						});
					};
					//点击发送按钮
					scope.send = function() {
						keyboardDown();
						//隐藏表情插件
						scope.ifExpression = false;
						//隐藏收藏与分享弹框
						scope.sign.menuShow = false;
						//取输入框中的内容
						var replyContent = scope.doc.body;
						replyContent = $(replyContent).html();
						//将图片替换为表情编码
						replyContent = replace_em(replyContent);
						console.log(replyContent);
						//根据类型判断不同页面发送数据的处理
						switch (scope.type) {
							case 'detailReply':
								scope.reply(replyContent);
								break;
							case 'appendReply':
								scope.appendReply(replyContent);
								break;
							case 'comment':
								scope.comment(replyContent);
								break;
							case 'append':
								scope.append(replyContent);
								break;
							case 'adopt':
								scope.adopt();
								break;
							case 'private':
								scope.post(replyContent);
								break;
							case 'reply':
								scope.replyQuestion(replyContent);
								break;
							case 'polymeric':
								var replyDatas = getReplyDatas();
								if (replyContent != "" && replyContent != null && replyContent.indexOf('placeholder') == -1) {
									if (getFlag() == 'one') {
										var datas = {};
										changeTalk();
										datas.param.contentId = getSid();
										HotDetailServices.replyHotDetail(datas).then(function(res) {
											if (true || res.status) {
												replyDatas.unshift({
													"replyPerson": res.data.commenterName,
													"replyPersonId": res.data.commenterId,
													"signId": res.data.id,
													"berepliedPerson": "",
													"berepliedPersonId": "",
													"replyCont": res.data.commentContent,
													"headPath": res.data.headPath,
													"createDate": res.data.commentDate
												});
												console.log(replyDatas);
												scope.showDialog("评论成功");
											} else {
												console.log(res);
											}

										});

									} else {
										var datas = {};
										changeTalk();
										datas.param.parentId = getSid();
										HotDetailServices.replyHotDetailPost(datas).then(function(res) {
											if (true || res.status) {
												console.log(res.data)
												replyDatas.splice(getIndex(), 0, {
													"replyPerson": res.data.commenterName,
													"replyPersonId": res.data.commenterId,
													"signId": res.data.id,
													"berepliedPerson": res.data.receiverName,
													"berepliedPersonId": res.data.receiverId,
													"replyCont": res.data.commentContent,
													"headPath": res.data.headPath,
													"createDate": res.data.commentDate
												});
												console.log(replyDatas);
												scope.showDialog("评论成功");
											} else {
												console.log(res);
											}
										});
										console.log(replyDatas);
									}
								} else {
									scope.showDialog("请输入内容");
								}
								break;
							default:
								break;
						};

						//转换说说类型
						function changeTalk() {
							datas.param = {};
							if (getStype() == "microblog") {
								datas.type = "mic-blog";
								datas.param.contentType = "mic-blog";
							} else {
								datas.type = getStype();
								datas.param.contentType = getStype();
							}
							datas.param.commentContent = replyContent;
						}
						//发送事件广播
						scope.$emit("inputSend", replyContent);

						//清空输入框
						$timeout(function() {
							$(scope.doc.body).html(text);
						}, 200);
					};


					//是否显示分享与收藏弹出框
					scope.showMenu = function(showmenu) {
						//showmenu为真弹框显示，为假则隐藏
						scope.sign.menuShow = showmenu;
						console.log("showMenu");
						//隐藏表情插件
						scope.ifExpression = false;
					};
					//点击分享按钮
					scope.share = function() {
						scope.sign.menuShow = false;
						console.log("share click!!!");
					};
					//点击收藏按钮
					scope.save = function(saveType) {
						//						scope.sign.ifsave = ifsave;
						console.log(saveType);
						if (saveType == true) {
							scope.data.saveType = true;
							scope.data.isCollect = "已收藏";
							scope.modalShow = 10;
							scope.collectContent = "已经添加为收藏";
						} else {
							scope.data.saveType = false;
							scope.data.isCollect = "收藏";
							scope.modalShow = 10;
							scope.collectContent = "已经取消收藏";
						}

						function isCollect() {
							return {
								contentId: scope.data.contentId,
								contentType: scope.data.contentType,
								saveType: scope.data.saveType
							}
						}
						console.log(isCollect());
						hotServices.getIsCollect(isCollect()).then(function(res) {
							if (res.status == 1) {
								scope.sign.saveType = saveType;
							} else {
								//                       	console.log(res.errorMessage);
								$ionicPopup.alert({
									template: "<p >" + res.errorMessage + "</p>"
								});
							}
						});
					};



					//点击输入框时
					scope.inputClick = function() {
						console.log("input on click");
						//隐藏表情插件
						scope.$apply(function() {
							if (scope.ifExpression == true)
								scope.ifExpression = !scope.ifExpression;
						});

						//隐藏收藏与分享弹框
						scope.sign.menuShow = false;
						scope.doc.body.focus();
						scope.win.focus();
					};
					inite();
					scope.$on('inputOnFocus', function(event) {
						$timeout(function() {
							scope.doc.body.focus();
							scope.win.focus();
						}, 100);
					});

					scope.$on('inputBoxPlaceholder', function(event, data) {
						text = $('<span style="color: #ccc;" class="placeholder">' + data + '</span>');
						setTimeout(function() {
							$(scope.doc.body).html(text);
							$(scope.doc.body).on('click', function(event) {
								$(this).find('.placeholder').remove();
							});
							$(scope.doc.body).on('keydown', function(event) {
								$(this).find('.placeholder').remove();
							});
						}, 300);
					});
				}
			};
		}
	]);
});