define(['angularAMD'], function(angularAMD) {
	angularAMD.filter('typeFilter', [
		function() {
			return function(type) {
				switch (type) {
					case 'knowledge':
						return '知识';
						break;
					case 'theme':
						return '讨论';
						break;
					case 'blog':
						return '博客';
						break;
					default:
						break;
				}
			};


		}
	]);
})