'use strict';
define(['angularAMD'], function(angularAMD) {
	try {

		angularAMD.factory('Global', [ function() {
			return {
				apiPath: "http://kms-mcmsrepo.sit.sf-express.com/KMS-MSERVER"
			}
		}]);

	} catch (e) {
		window.apiPath = "https://kms-mappserver.sf-express.com/KMS-MSERVER";
		//window.apiPath = "http://10.202.4.75:8180";
	}
});