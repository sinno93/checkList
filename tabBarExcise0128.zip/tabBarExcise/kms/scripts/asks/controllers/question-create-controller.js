define(['angularAMD', 'common/services/footer-service', 'asks/services/ask-services', 'common/directive/input-box', 'common/controllers/staff-selection-controller'], function(angularAMD) {
	angularAMD.controller('questionCreateController', ['$scope', '$ionicModal', '$ionicPopup', '$location', '$rootScope', 'FooterServices', '$ionicScrollDelegate', 'asksServices', '$timeout', 'Global', '$ionicLoading',
		function($scope, $ionicModal, $ionicPopup, $location, $rootScope, FooterServices, $ionicScrollDelegate, asksServices, $timeout, Global, $ionicLoading) {
			'use strict';
			//模拟数据
			$scope.rewardScore = 0; //悬赏金额
			/*页面表情转码*/
			$scope.emoijToText = function(html) {

				return replace_html(html)
			};

			/*初始函数*/
			var init = function() {
				FooterServices.hide();
				$scope.title = "描述你的问题";
				$scope.historyBack = function() {
					$location.path('/asks');
				}
				inputBoxAsk1($scope);
				$timeout(function() {
					$(document.getElementById("emoijid").contentWindow.document).find('html').append(
						'<style>span{display: none;}</style>'
					);
				}, 1000);
				$scope.sign.ifsmile = false;
				if (!getIsIOS()) {
					//安卓版本

					$timeout(function() {
						$('.theme').focus();
					}, 300);
					var updateTextarea = function() {
						var h = $(window).height() - $(".input-common").height() - 155;
						$(".textarea").height(h);
					}
					setInterval(function() {
						updateTextarea();
					}, 100);
				} else {
					//iOS版本
					$timeout(function() {
						$(document.getElementById("emoijid").contentWindow.document).on("touchend", function(event) {
							$timeout(function() {
								console.log(getKeyboardHeight());
								var bottomH = getKeyboardHeight() - 90;
								$(".input-common").attr('style', 'bottom:' + bottomH + 'px');
							}, 50);
						});
						$(window).on('touchstart', function(obj) {
							keyboardDown();
							$(".input-common").attr('style', 'bottom:0px');
						});
					}, 1000);
				}



				var updateTextarea = function() {
					//					console.log(getKeyboardHeight());
					var h = $(window).height() - $(".input-common").height() - getKeyboardHeight() - 25;
					$(".textarea").height(h);
				}

				$scope.categoryIndex = 0;
				asksServices.getAskCategoryCode().then(function(result) {
					if (result.status) {
						$scope.categoryCode = result.data;
						var select = {
							categoryCode: "0-00000",
							categoryName: "请选择类型",
							id: "00000",
							pCode: "0",
							sortId: 0
						};
						$scope.categoryCode.unshift(select);
					} else {
						$ionicPopup.alert({
							template: "<p >" + res.errorMessage + "</p>"
						});
					}
				});

				$scope.topScore = 0;
				var data = {};
				data.param = {};
				data.param.questionId = '';
				asksServices.getTopScore(data).then(function(result) {
					if (result.status) {
						$scope.topScore = result.data;
						if ($scope.topScore == 0) {
							$scope.sign.ifcoin = false;
						}
					} else {
						$ionicPopup.alert({
							template: "<p >" + res.errorMessage + "</p>"
						});
					}
				});

			}
			init();

			/*控制选择菜单*/
			$scope.menuToggle = function() {
				$(".top-drop-menu").toggleClass('on');
			};
			$scope.menuSelect = function(index) {
				$scope.categoryIndex = index;
				$('.top-drop-menu').find("li").removeClass('on');
				$('.top-drop-menu').find("li").eq(index).addClass('on');
				$(".top-drop-menu").removeClass('on');
			};

			/*设置积分*/
			$scope.$on('inputCoinSeleced', function(event, data) {
				var score = data;
				$scope.rewardScore = score;
			});

			/*确认、保存问题*/
			var showDialogbox1 = function(callback) { /*确认是否保存*/
				$scope.explain = "如收到满意答案请采纳！";
				$scope.modalYes = "确定";
				$scope.modalNo = "取消";
				$scope.modalShow = 3;
				$scope.isBatch = function(flag) {
					if (flag) {
						callback();
					}
					$scope.modal.hide();
				};
				$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
					scope: $scope,
					animation: 'slide-in-up'
				}).then(function(modal) {
					$scope.modal = modal;
					$scope.modal.show();
				});
			}
			var showDialogbox2 = function(text) { /*提示已经保存*/
				$scope.modalShow = 10;
				$scope.collectContent = text;
				$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
					scope: $scope,
					animation: 'slide-in-up'
				}).then(function(modal) {
					$scope.modal = modal;
					$scope.modal.show();
					$timeout(function() {
						$scope.modal.hide();
					}, 1000);
				});
			}
			$scope.addImageElement = function(imgUrl) {
				if (!$scope.imageUrlArray)
					$scope.imageUrlArray = [];
				$scope.imageUrlArray.push(imgUrl);
			}
			$scope.saveQuestion = function() {
				//压缩

				if ($scope.categoryCode[$scope.categoryIndex].categoryCode == "0-00000") {
					showDialogbox2('请选择类型');
					return;
				}

				if ($('.theme').val() == '') {
					showDialogbox2('请填写标题');
					return;
				}

				showDialogbox1(function() {
					var data = {}; //处理、设置问题内容
					var $content = $(document.getElementById("emoijid").contentWindow.document.body);
					data.title = $('.theme').val();
					data.content = $content.html();
					if ($scope.imageUrlArray && $scope.imageUrlArray.length > 0) {
						var imageArrayUrlTemp = [];
						for (var i = 0; i < $scope.imageUrlArray.length; i++) {
							if (data.content.indexOf($scope.imageUrlArray[i]) >= 0) {
								imageArrayUrlTemp.push($scope.imageUrlArray[i]);
							}
						}
						if (imageArrayUrlTemp.length > ImageUploadNumber) {
							showDialogbox2('图片最多只能发5张，请将图片删减！');
							return;
						} else {
							$scope.imageUrlArray = imageArrayUrlTemp;
						}
					}

					$ionicLoading.show({
						content: '正在发表',
						animation: 'fade-in',
						showBackdrop: true,
						Width: 150,
						maxWidth: 300,
						showDelay: 0
					});
					data.categoryCode = $scope.categoryCode[$scope.categoryIndex].categoryCode;
					data.categoryName = $scope.categoryCode[$scope.categoryIndex].categoryName;
					data.label = '';
					data.rewardScore = $scope.rewardScore;
					data.receivers = [];
					$content.find("span").each(function() {
						var userId = $(this).text();
						userId = userId.substr(1);
						data.receivers.push(userId);
						$(this).remove();
					});
					data.receivers = data.receivers.join(",");

					$content.find('span').remove();
					data.content = $content.html();
					if ($scope.imageUrlArray) {
						for (var i = 0; i < $scope.imageUrlArray.length; i++) {
							var stringRul = $scope.imageUrlArray[i];
							data.content = data.content.replace(stringRul, '');
						}
					} else {
						$scope.imageUrlArray = [];
					}
					data.content = replace_em(data.content);

					if (!$scope.imageUrlArray || $scope.imageUrlArray.length == 0) {
						data.images = "";
						asksServices.saveQuestion(data).then(function(result) {
							$ionicLoading.hide();
							if (result.status) {
								showDialogbox2('发布你的问题成功');
								$timeout(function() {
									$location.path('/asks');
								}, 1000);
								keyboardDown();
							} else {
								$ionicPopup.alert({
									template: "<p >" + result.errorMessage + "</p>"
								});
							}
						});
						return;
					}
					var imageArrayUrlCopy = [];
					var imageArrayUrl = [];

					var imageCompressIndex = 0;
					var imageTransferIndex = 0;

					function onSuccess(imgurl) {
						imageArrayUrl.push(imgurl);
						if (imageTransferIndex >= imageArrayUrlCopy.length - 1) {
							transferImageToService(Global.apiPath + "/upload/image", imageArrayUrlCopy[imageTransferIndex], onSuccessSubmit, onFail);
						} else {
							transferImageToService(Global.apiPath + "/upload/image", imageArrayUrlCopy[imageTransferIndex], onSuccess, onFail);
						}
						imageTransferIndex++;
					}

					function onSuccessSubmit(imgurl) {
						imageArrayUrl.push(imgurl);
						data.images = "";
						for (var i = 0; i < imageArrayUrl.length; i++) {
							if (i == imageArrayUrl.length - 1) {
								data.images = data.images + imageArrayUrl[i];
							} else {
								data.images = data.images + imageArrayUrl[i] + ",";
							}
						}
						asksServices.saveQuestion(data).then(function(result) {
							deleteFiles(imageArrayUrlCopy);
							$ionicLoading.hide();
							if (result.status) {
								showDialogbox2('发布你的问题成功');
								$timeout(function() {
									$location.path('/asks');
								}, 1000);
								keyboardDown();
							} else {
								$ionicPopup.alert({
									template: "<p >" + result.errorMessage + "</p>"
								});
							}
						});
					}

					function onFail(mess) {
						$ionicLoading.hide();
						showDialogbox2(mess);
					}

					function compressSuccess(imgurl) {
						if (imageCompressIndex >= $scope.imageUrlArray.length - 1) {
							compressFile($scope.imageUrlArray[imageCompressIndex], compressSuccessSubmit, onFail);
						} else {
							compressFile($scope.imageUrlArray[imageCompressIndex], compressSuccess, onFail);
						}
						imageCompressIndex++;
						imageArrayUrlCopy.push(imgurl);
					}

					function compressSuccessSubmit(imgUrl) {
						imageArrayUrlCopy.push(imgUrl);
						console.log("imageArrayUrlCopy");
						console.log(imageArrayUrlCopy);
						if (imageArrayUrlCopy && imageArrayUrlCopy.length > 0) {
							if (imageTransferIndex >= imageArrayUrlCopy.length - 1) {
								transferImageToService(Global.apiPath + "/upload/image", imageArrayUrlCopy[imageTransferIndex], onSuccessSubmit, onFail);
							} else {
								transferImageToService(Global.apiPath + "/upload/image", imageArrayUrlCopy[imageTransferIndex], onSuccess, onFail);
							}
							imageTransferIndex++;
						}
					}
					if ($scope.imageUrlArray && $scope.imageUrlArray.length > 0) {
						console.log("$scope.imageUrlArray");
						console.log($scope.imageUrlArray);
						if (imageCompressIndex >= $scope.imageUrlArray.length - 1) {
							compressFile($scope.imageUrlArray[imageCompressIndex], compressSuccessSubmit, onFail);
						} else {
							compressFile($scope.imageUrlArray[imageCompressIndex], compressSuccess, onFail);
						}
						imageCompressIndex++;
					}
				});
			}
		}
	])

});