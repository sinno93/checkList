define(['angularAMD'], function(angularAMD) {
	angularAMD.directive('itemHotdetailPost', function() {
		return {
			restrict: 'AE',
			replace: 'true',
			templateUrl: 'views/common/directive/item-hotdetail-post.html',
			link: function(scope, element) {
				/*更多回复*/
				scope.toggleMore=function(index, id){
					scope.toggleMoreReplys(index, id);
				}
				/*收起回复*/
				scope.toggleLess=function(index, id){
					scope.toggleLessReplys(index, id);
				}
			}
		};
	});
})