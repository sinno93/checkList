//
//  zoneViewController.m
//  tabBarExcise
//
//  Created by 郑庆登(King Zheng)-企业内部系统研发中心 on 16/1/15.
//  Copyright © 2016年 郑庆登(Qingdeng Zheng)-IT服务中心. All rights reserved.
//

#import "zoneViewController.h"

@interface zoneViewController ()<UITextFieldDelegate,UIWebViewDelegate,NSURLConnectionDelegate,NSURLConnectionDataDelegate>
{

}
@end

@implementation zoneViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    HUD = [[MBProgressHUD alloc] initWithView:self.view];
//    [self.view addSubview:HUD];
//    HUD.delegate = self;
//    HUD.labelText =@"加载中...";
//    [HUD showWhileExecuting:@selector(ss) onTarget:self withObject:nil animated:YES];
    UIWebView *zoneWebView = [[UIWebView alloc]init];
    self.zoneWebView = zoneWebView;
    [zoneWebView setFrame:CGRectMake(0, 50, 320, 500)];
    NSString *ecpLoginStr = @"https://mcas.sf-express.com/cas/login?service=https%3A%2F%2Fmecp.sf-express.com%2Fecp%2Fmobile%2Fmdmapps%2FmdmMobileData%2FgetUserInf.ht";
    NSURL *ecpLoginUrl = [NSURL URLWithString:ecpLoginStr];
    // cas 登录
    NSMutableURLRequest *casrequest = [NSMutableURLRequest requestWithURL:ecpLoginUrl];
    
    
    [NSURLConnection connectionWithRequest:casrequest delegate:self];
    NSURL *url  = [NSURL URLWithString:@"https://mecp.sf-express.com"];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [NSURLConnection connectionWithRequest:request delegate:self];
    UITextField *input = [[UITextField alloc]initWithFrame:CGRectMake(0, 20, 280, 30)];
    input.delegate = self;
    input.tag = 10086;
    [input setBorderStyle:UITextBorderStyleLine];
    UIButton *go = [[UIButton alloc]initWithFrame:CGRectMake(280, 20, 40, 30)];
    go.backgroundColor = [UIColor brownColor];
    [go addTarget:self action:@selector(go:) forControlEvents:UIControlEventTouchUpInside];
    // NSURLConnection *connection = [[NSURLConnection alloc]initWithRequest:request delegate:self];
   // [zoneWebView loadRequest:request];
   
    zoneWebView.delegate = self;
    zoneWebView.backgroundColor = [UIColor colorWithRed:214/255.0 green:255/255.0 blue:255/255.0 alpha:255/255.0];
    [self.view addSubview:zoneWebView];
    [self.view addSubview:input];
    [self.view addSubview:go];
  

     //Do any additional setup after loading the view.
}

- (void)go:(id)sender{
   
    UITextField * textField = (UITextField*)[self.view viewWithTag:10086];
    
    NSLog(@"text:%@",textField.text);
//    NSURL *url  = [NSURL URLWithString:textField.text];
    //NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/%@",[zoneViewController documentsDirectory],@"file____Users_835881_Library_Developer_CoreSimulator_Devices_54760AB9-0BE9-406D-9288-B165FA3C4892_data_Containers_Bundle_Application_7815A213-DB7F-4D2E-A3BC-BA4546900D18_tabBarExcise_app_kms_index.html?a=222" ]];
    //NSURL *url = [NSURL URLWithString:@"https://mecp.sf-express.com/ecp/www/index.html"];
    
    NSURL *url = [NSURL fileURLWithPath:[NSString stringWithFormat: @"%@/www/index.html",[zoneViewController documentsDirectory]]];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
   
    [self.zoneWebView loadRequest:request];
    self.zoneWebView.delegate = self;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    NSLog(@"%lu",(unsigned long)range.length);
    if (1 == range.length) {//按下回格键
        NSLog(@"你按下了回格键");
        return YES;
    }
    
    if ([string isEqualToString:@"\n"]) {//按下return键
        //这里隐藏键盘，不做任何处理
        [textField resignFirstResponder];
        return NO;
    }else {
        if ([textField.text length] < 140) {//判断字符个数
            return YES;
        }
    }
    return NO;
}
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if (1 == range.length) {//按下回格键
        return YES;
    }
    
    if ([text isEqualToString:@"\n"]) {//按下return键
        //这里隐藏键盘，不做任何处理
        [textView resignFirstResponder];
        return NO;
    }else {
        if ([textView.text length] < 140) {//判断字符个数
            return YES;
        }
    }
    return NO;
}

- (instancetype)init{
    self = [super init];
    self.tabBarItem.title = @"动态";
    self.tabBarItem.image = [UIImage imageNamed:@"star"];

    
    return self;
}


- (void)viewDidUnload {
//    [self setButtons:nil];
    [super viewDidUnload];
}
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    return YES;
}
- (void)webViewDidFinishLoad:(UIWebView *)webView{
    
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
   
}
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    // 加载出错则弹出错误提示框
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:[error localizedDescription] delegate:nil cancelButtonTitle:NSLocalizedString(@"IKnowzone",nil) otherButtonTitles:nil, nil];
    [alert show];
}
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
   
}

- (BOOL)connection:(NSURLConnection *)connection canAuthenticateAgainstProtectionSpace:(NSURLProtectionSpace *)protectionSpace
{
    NSLog(@"验证。。。%@",connection);
    return [protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust];
}

- (void)connection:(NSURLConnection *)connection didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge {
    if ([challenge.protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust]){
        [[challenge sender]  useCredential:[NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust] forAuthenticationChallenge:challenge];
        [[challenge sender]  continueWithoutCredentialForAuthenticationChallenge: challenge];
    }
}
+(NSString*)documentsDirectory{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths firstObject];
    return documentsDirectory;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
