//
//  messageViewController.m
//  tabBarExcise
//
//  Created by 郑庆登(King Zheng)-企业内部系统研发中心 on 16/1/15.
//  Copyright © 2016年 郑庆登(Qingdeng Zheng)-IT服务中心. All rights reserved.
//

#import "messageViewController.h"

@interface messageViewController ()

@end

@implementation messageViewController

- (void)viewDidLoad {
     [super viewDidLoad];
    CGRect r = [ UIScreen mainScreen ].applicationFrame;
    // Do any additional setup after loading the view.
    UITableView * tableView = [[UITableView alloc]initWithFrame:r];
    [tableView setBackgroundColor:[UIColor colorWithRed:214/255.0 green:255/255.0 blue:255/255.0 alpha:255/255.0]];
    [self.view addSubview:tableView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (instancetype)init{
    self = [super init];
    self.tabBarItem.title=@"信!息";
    self.tabBarItem.image=[UIImage imageNamed:@"message.png"];
    return self;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
