//
//  zoneViewController.h
//  tabBarExcise
//
//  Created by 郑庆登(King Zheng)-企业内部系统研发中心 on 16/1/15.
//  Copyright © 2016年 郑庆登(Qingdeng Zheng)-IT服务中心. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface zoneViewController : UIViewController

@property UIWebView *zoneWebView;
@end
