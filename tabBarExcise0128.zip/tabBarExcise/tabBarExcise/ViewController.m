//
//  ViewController.m
//  tabBarExcise
//
//  Created by 郑庆登(King Zheng)-企业内部系统研发中心 on 16/1/15.
//  Copyright © 2016年 郑庆登(Qingdeng Zheng)-IT服务中心. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    messageViewController *message  = [[messageViewController alloc]init];
    friendsViewController *friend   = [[friendsViewController alloc]init];
    zoneViewController    *zone     = [[zoneViewController alloc]init];
    SFCommonViewController *setting = [[SFCommonViewController alloc]init];
    //c.添加子控制器到ITabBarController中
    //c.1第一种方式
    //    [tb addChildViewController:c1];
    //    [tb addChildViewController:c2];
    
    //c.2第二种方式
    self.viewControllers=@[message,friend,zone,setting];
    

    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
