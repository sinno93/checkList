//
//  zqdCacheManager.m
//  tabBarExcise
//
//  Created by 郑庆登(King Zheng)-企业内部系统研发中心 on 16/1/26.
//  Copyright © 2016年 郑庆登(Qingdeng Zheng)-IT服务中心. All rights reserved.
//
#define CACHE_DIR_NAME @"serviceApp"
#define WEB_VERSION    @"webVersion.json"
#define MANI_FEST      @"manifest.json"
#import "zqdCacheManager.h"
#import "zqdownload.h"
#import "PAMD5.h"
@implementation zqdCacheManager
{
    NSDictionary *webVersionDic;//从webVersion.json中获取的字典
    NSDictionary *manifestDic;  //从manifest.json中获取的字典
    NSMutableDictionary *shortUrlDic;//由manifestDic 得到的短路径字典
}
@synthesize loadWebViewWithURL;

+ (zqdCacheManager*)share {
    static zqdCacheManager *seh = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        seh = [[zqdCacheManager alloc] init];
    });
    return seh;
}
// 更改其属性值
-(void)initializedWithAppInfo:(NSDictionary *)appInfo andHost:(NSString*)host{
        self.appInfo = appInfo;
        self.rootDirectory = [self getBasePath];
        self.host = host;
}
/**
 *  加载webView之前的准备工作
 *
 *  @param loadBlock 准备完成后要执行的函数...
 */
-(void)prepareToLoadWebView:(void (^)(NSString *path))loadBlock{
    
    self.loadWebViewWithURL = loadBlock;
    // 初始化WebVersion
    // 初始化Manifest
    //
}
/**
 *  下载webVersion 并且初始化webVersionDic
 */
-(void)initWebVersion{
    NSString* webVersionUrl = [NSString stringWithFormat:@"%@%@%@",self.host,[self.appInfo objectForKey:@"visiturl"] ,WEB_VERSION ];
    [zqdownload downloadWithURL:webVersionUrl complete:^(NetState state, NSData *data){
        if (state == success) {
            // 下载成功,保存
            [self saveData:data toFilePath:WEB_VERSION];
        }
    }];
}

/**
 *  初始化manifestDic 和 shortUrlDic
 */
-(void)initManifest{
    /* 先判断webVersion里的md5和本地的manifest.json的md5是否相同
        若相同，则直接通过本地manifest.json初始化manifestDic 和 shortUrlDic
        若不同，则去下载manifest.json 再初始化
     */
    
    NSString* manifestUrl = [NSString stringWithFormat:@"%@/%@",self.host,WEB_VERSION];
    [zqdownload downloadWithURL:manifestUrl complete:^(NetState state,NSData *data){
        if(state == success){
            [self saveData:data toFilePath:MANI_FEST];
        }
    }];
}

/**
 *  获取基本路径
 *
 *  @return 返回基本路径 比如...Documents/serviceApp/ECP
 */
-(NSString*)getBasePath{
    NSMutableString *basePath = [[self documentsDirectory] mutableCopy];
    [basePath appendFormat:@"/%@/%@",CACHE_DIR_NAME,[self.appInfo objectForKey:@"syskey"]];
    return basePath;
}
/**
 *  保存数据到指定的文件中去
 *
 *  @param data     要保存的数据
 *  @param filePath 保存的路径(短路径)
 *
 *  @return 是否保存成功
 */
-(BOOL)saveData:(NSData*)data toFilePath:(NSString*)filePath{
    // 先直接creatPath 再写入文件
    NSMutableString *mutFilePath = [filePath mutableCopy];
    if ([mutFilePath hasPrefix:@"/"]) {
        [mutFilePath deleteCharactersInRange:NSMakeRange(0, 1)];
    }
    BOOL createResult = [self creatPath:mutFilePath];
    if(createResult){
        NSString *fileRealPath =[ NSString stringWithFormat:@"%@/%@",self.rootDirectory,filePath ];
        BOOL result =  [data writeToFile:fileRealPath atomically:YES];
        return result;
    }return NO;
}

/**
 *  (在app根目录下 ...ECP/...)创建路径
 *
 *  @param filePath 要创建的路径
 *
 *  @return 若存在该路径OR创建路径成功 返回YES 否则返回NO
 */
-(BOOL)creatPath:(NSString *)filePath{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSMutableArray *fileArr = [[filePath componentsSeparatedByString:@"/"] mutableCopy];
    // 若数组为空，则判断根目录是否存在,若存在则直接返回YES
    if (!fileArr){
        BOOL result = [fileManager fileExistsAtPath:self.rootDirectory];
        if(result)return result;
        return [fileManager createDirectoryAtPath:self.rootDirectory withIntermediateDirectories:YES attributes:nil error:nil];
    }else{
        //数组不为空 判断其是否是路径 不是则移除最后的...
        if([fileArr.lastObject rangeOfString:@"."].length>0){
            [fileArr removeLastObject];
            NSString *newFilePath = [NSString stringWithFormat:@"%@/%@",self.rootDirectory, [fileArr componentsJoinedByString:@"/"]];
            BOOL result = [fileManager fileExistsAtPath:newFilePath];
            if(result)return result;
            // 不存在 则创建
            return [fileManager createDirectoryAtPath:newFilePath withIntermediateDirectories:YES attributes:nil error:nil];
        }else{
            NSString *newFilePath = [NSString stringWithFormat:@"%@/%@",self.rootDirectory, [fileArr componentsJoinedByString:@"/"]];
            BOOL result = [fileManager fileExistsAtPath:newFilePath];
            if(result)return result;
            // 不存在 则创建
            return [fileManager createDirectoryAtPath:newFilePath withIntermediateDirectories:YES attributes:nil error:nil];
        }
    }
}
-(NSString*)getProperFilePathWithShortUrl:(NSString*)str{
    // 还是要返回目录地址比较好
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSMutableString *returnFilePath = [NSMutableString string];
    NSArray *fileArr = [str componentsSeparatedByString:@"/"];
    if (fileArr.count>1) {
        NSMutableString *fileRealPath = [[NSMutableString alloc]initWithString:[self documentsDirectory]];
        [fileRealPath appendFormat:@"/www"];
        NSMutableArray *fileMutArr = [fileArr mutableCopy];
        [fileMutArr removeLastObject];
        for(NSString*filePath in fileMutArr){
            [fileRealPath appendFormat:@"/%@",filePath];
        }
        BOOL dirExist = [fileManager fileExistsAtPath:fileRealPath];
        if(!dirExist){ // 文件夹不存在
            BOOL create = [fileManager createDirectoryAtPath:fileRealPath withIntermediateDirectories:YES attributes:nil error:nil];
            [fileRealPath appendFormat:@"/%@",fileArr.lastObject ];
            if(create)return fileRealPath;
            else return nil;
        }else{
            // 文件夹存在
            [fileRealPath appendFormat:@"/%@",fileArr.lastObject];
            return fileRealPath;
        }
    }else{
        // 不是目录 直接返回根目录即可
        [returnFilePath appendFormat:@"%@/www/%@",[self documentsDirectory],fileArr[0] ];
        return returnFilePath;
    }
}
/**
 *  判断当前路径的文件是否是最新文件(与manifest文件中的md5值比较)
 *
 *  @param filePath 文件路径
 *
 *  @return 相同则YES,不同则NO
 */
-(BOOL)isFileNewest:(NSString *)filePath{
    return YES;
}

-(NSString*)documentsDirectory{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths firstObject];
    return documentsDirectory;
}

@end
