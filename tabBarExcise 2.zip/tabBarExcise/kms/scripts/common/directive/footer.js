define(['angularAMD'], function(angularAMD) {
	angularAMD.directive('footer', ['$location','$rootScope',
		function($location,$rootScope) {
			return {
				restrict: 'E',
				replace: true,
				scope: {},
				template: '<div class="tabs footer-wrapper tabs-icon-top" id="footerId">' +
					'<a href=""  ng-click="activeTab($index,item.path,item.value)" class="tab-item kms-tab"  ng-class="{active: selexted== item.index}"   ng-repeat="item in footerItems">' +
					'<i class="icon {{item.icon}}"></i><span ng-bind="item.title"  ></span>' +
					'<b ng-show="item.itmpReminder"></b>' +
					'</a>' +
					'</div>',
				link: function(scope, element) {

					function activeNavigatorBarByIndex(index) {
						element.find("a").removeClass("active");
						element.find("a").eq(index).addClass("active");
					}

					function removeActiveByIndex(index) {
						element.find("a").removeClass("active");
					}

					scope.activeTab = function(index, path, value) {
						activeNavigatorBarByIndex(index);
						if(index == 2){
							$rootScope.kmsConmunitySearchKeywordIf = false;
						}
						scope.goTo(path);
					};


					scope.$on("removeActiveByIndex", function(event, index) {
						removeActiveByIndex(index);
					});

					scope.$on("activeNavigatorBarByIndex", function(event, index) {
						activeNavigatorBarByIndex(index);
					});
					scope.$on("hideNavigatorFooter", function() {
						$("#footerId").hide();
					});

					scope.$on("showNavigatorFooter", function() {
						$("#footerId").show();
					});

					scope.goTo = function(url) {
						$location.path(url);
					};
					scope.footerItems = [{
						"icon": "icon-huo",
						"value": "hot",
						"title": "热门",
						"path": "/hot",
						"itmpReminder":false
					}, {
						"icon": "icon-qus-2",
						"value": "asks",
						"title": "爱问",
						"path": "/asks",
						"itmpReminder": false
					}, {
						"icon": "icon-uni-2",
						"value": "community",
						"title": "社区",
						"path": "/community",
						"itmpReminder": false
					}, {
						"icon": "icon-me",
						"value": "mine",
						"title": "我",
						"path": "/mine",
						"itmpReminder": false
					}];

				}

			};

		}
	]);
})