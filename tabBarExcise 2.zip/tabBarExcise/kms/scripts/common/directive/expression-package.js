define(['angularAMD'], function(angularAMD) {
	angularAMD.directive('expressionPackage', ['$rootScope','$timeout',
		function($rootScope,$timeout) {
			return {
				//E - 元素名称：<my-directive></my-directive>
				//A - 属性： <div my-directive="exp"> </div>
				//C - 类名：<div class="my-directive: exp;"></div>
				//M - 注释： <!-- directive: my-directive exp -->
				restrict: 'E',
				replace: true,
				scope: true,
				templateUrl: 'views/common/directive/expression-package.html',
				link: function(scope) {
					
					inite();

					function inite() {
						// scope.inputBoxId = 'emoijid';
						if(!scope.inputBoxId || scope.inputBoxId == ""){
							scope.inputBoxId = "emoijid";
						}
						//获取表情数据
						scope.data = {
							"sendcontent": ''
						};
						getFaceData();
						console.log("expression-package");
					};
					
					
					//构造表情数据
					function getFaceData() {
							var count = 75; //表情总数
							var pageCount = 21; //每一页表情总数
							var facepages = Math.ceil(count / pageCount); //总页数
							var faceArray = []; //最终表情数组
							//页循环
							for(var i=0;i<facepages;i++){
								var pageFaces = [];
								var faceNumPage;
								if(i == facepages-1 && count%pageCount != 0){
									faceNumPage = count%pageCount;
								}else{
									faceNumPage = pageCount;
								}
								for(var j=0;j<faceNumPage;j++){
									var facePer = {};
									var num = i * pageCount + j +1;
									//表情图片路径
									facePer.faceImg = "styles/images/face/" + num + ".gif";
									//表情编码
									facePer.faceName = "[em_" + num + "]";
									pageFaces.push(facePer);
								}
								faceArray.push(pageFaces);
							}
							scope.facePages = faceArray;
							console.log(scope.facePages);
						}
						//选择表情
					scope.chooseOneSmile = function(smileName, imgPath) {
						$(scope.doc.body).find('.placeholder').remove();
						
						insertIntoInputBox(scope ,"<img style='vertical-align: middle;margin: 0;padding: 0 1px;' src='" + imgPath + "'>");
//						$("#emoijid").html($("#emoijid").html().substring(0, $("#emoijid").html().indexOf("test")) + "<img src='" + imgPath + "'>" + $("#emoijid").html().substring($("#emoijid").html().indexOf("test")));
//						$("#emoijid").html($("#emoijid").html().replace(/<br><br>/g,'<br>'));
//						scope.c = new cursorControl(document.getElementById(scope.inputBoxId));
//						scope.cc.insertText(scope.inputBoxId,"<img class='emoij-img' src='" + imgPath + "'>");
//						$("#emoijid").html($("#emoijid").html().substring(0, rang.startOffset) + "<img src='" + imgPath + "'>" + $("#emoijid").html().substring(rang.startOffset));
//						$("#emoijid").innerHTML = $("#emoijid").contents() + "<img src='" + imgPath +"'>";
//						scope.data.sendcontent = scope.data.sendcontent + smileName;

					};

				}
			};
		}
	]);
});
