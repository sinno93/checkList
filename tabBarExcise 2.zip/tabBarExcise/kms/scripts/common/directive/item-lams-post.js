define(['angularAMD', 'mine/services/mine-frame-services'], function(angularAMD) {
	angularAMD.directive('itemLamsPost', ['$rootScope', '$location', '$ionicModal', 'MineFrameServices',
		function($rootScope, $location, $ionicModal, MineFrameServices) {
			return {
				restrict: 'AE',
				replace: true,
				scope: true,
				templateUrl: 'views/common/directive/item-lams-post.html',
				link: function(scope, element) {
					/*更多回复*/
					scope.toggleMore=function(index, id){
						scope.toggleMoreReplys(index, id);
					}
					/*收起回复*/
					scope.toggleLess=function(index, id){
						scope.toggleLessReplys(index, id);
					}
					/*回复留言*/
					scope.reply=function(event){
						scope.replyLams(event);
					}
					scope.replyOthers=function(event){
						scope.replyLams(event);
					}
					scope.showTools=function(event){
						scope.showReplyTools(event);
					}
					scope.delete=function(parentId, replyId){
						scope.deleteReply(parentId, replyId);
					}


				}
			}
		}
	]);
});