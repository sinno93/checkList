define(['angularAMD', 'common/services/footer-service', 'common/services/staff-selection-service'], function(angularAMD) {
	angularAMD.controller('staffSelectionController', ['$scope', '$ionicModal', '$location', '$rootScope', '$timeout', '$ionicPopup', 'FooterServices',
		'$ionicScrollDelegate', 'staffSelectionServices',
		function($scope, $ionicModal, $location, $rootScope, $timeout, $ionicPopup, FooterServices, $ionicScrollDelegate, staffSelectionServices) {
			'use strict';
			/* 定义input的值、好友总数、获取屏幕自适应高度*/
			$scope.vs = {
				'keyword': "",
				'total': ""
			};
			/* 判断是搜好友还是全网 */
			var isSearch;
			/* 默认本地的显示 */
			$scope.searchWay = true;
			/* 显示为我的好友 */
			$scope.switchSearch = true;
			//设置存储数据
			$scope.items = [];
			$scope.placeholderText = "请输入人员名称/工号";
			/* 数据及字母存放为一个数组  */
			$scope.letterList = [];
			/* 已选人员存放为一个数组 */
			$scope.staffs = [];
			/* 列表带过来的id 和类型*/
			$scope.id = "";
			$scope.type = "";
			/*获取带过来的type */
			var getType = "";
			$scope.noMoreItemsAvailable = true;
			$scope.isFirstIn = true;
			$scope.isFriends = "";
			//$scope.isMore = false;
			$scope.isPrivateMessage = false;
			$scope.selectPerson = function() {
				$scope.isFriends = true;
				$scope.modalPay.show();
				$scope.noMoreItemsAvailable = true;
				$scope.isFirstIn = true;
				$scope.items = [];
				$scope.startPage = 0;
				getFriendsData();
				$scope.isPrivateMessage = true;
			}

			$ionicModal.fromTemplateUrl('views/common/staff-selection.html', {
				scope: $scope,
				animation: 'slide-in-up'
			}).then(function(modal) {
				$scope.modalPay = modal;
			});

			//打开弹窗
			$scope.staffSelection = function(data, type) {
					getType = type;
					console.log(type);
					console.log(data);
					$scope.isFriends = true;
					$scope.id = data.contentId;
					$scope.type = data.type || data.selectType;
					$scope.modalPay.show();
					$scope.items = [];
					$scope.isFirstIn = true;
					$scope.startPage = 0;
					init();
					$scope.staffs = [];
				}
				/*关闭弹窗*/
			$scope.closeModal = function() {
				$scope.items = [];
                console.log($scope.items);
				if (!$scope.switchSearch) {
					$scope.isFirstIn = true;
					$scope.startPage = 0;
					$scope.isFriends = true;
					console.log("333");
					$scope.vs.keyword = "";
					//$(".dele-data").remove();
					$ionicScrollDelegate.resize();
					$scope.switchSearch = true;
					$scope.searchWay = true;
					getFriendsData();
					$timeout(function() {
							shareSelection();
							console.log($scope.items);
						}, 300)
						//shareSelection();
				} else {
					$scope.modalPay.hide();
					$(".dele-data").remove();
					//closeModalDestroy();
				}
				$(".dele-data").remove();
			};


			function cancelScrollInitFunction() {
				window.setTimeout(function() {
					$scope.$broadcast('scroll.refreshComplete');
				}, 100);
			}
			/*初始化数据*/
			function init() {
				//initPager($scope);
				$scope.noMoreItemsAvailable = true;
				$scope.isFirstIn = true;
				getFriendsData();
			}
			//获取数据

			function getFriendsData() {
				$scope.sendData = {};
				$scope.sendData.startPage = $scope.startPage;
				$scope.sendData.pageSize = 8;
				$scope.sendData.searchKey = $scope.vs.keyword;
				staffSelectionServices.staffSelectionData($scope.sendData).then(function(res) {
					if (res.status == 1) {
						$scope.items = $scope.items.concat(traverseData(res.data));
						$(".scroll").attr("style", "");
						$scope.noMoreItemsAvailable = res.totalSize == $scope.items.length;
						cancelScrollInitFunction();
						$scope.$broadcast('scroll.infiniteScrollComplete');
						$scope.vs.total = $scope.items.length;
						NoData($scope.items.length, 2);
					} else {
						$ionicPopup.alert({
							template: "<p >" + res.errorMessage + "</p>"
						});
					}
				});
			}
			//遍历数据

			function traverseData(datas) {
				return _.map(datas, function(data) {
					return {
						name: data.userName || data.name,
						workId: data.userId || data.empNumber,
						position: data.position,
						department: data.deptName || data.deptName,
						headPath:  assembleImageUrl(data.headPath),
						isAttentionEachOther: data.isAttentionEachOther,
						select: false
					}
				})
			}
			//获取全网数据
			function getAllData() {
				$scope.allData = {};
				$scope.allData.startPage = $scope.startPage;
				$scope.allData.pageSize = 8;
				$scope.allData.searchKey = $scope.vs.keyword;
				staffSelectionServices.staffSelectionAllData($scope.allData).then(function(res) {
					if (res.status == 1) {
						$scope.items = $scope.items.concat(traverseData(res.data));
						$(".scroll").attr("style", "");
						shareSelection();
						$scope.noMoreItemsAvailable = res.totalSize == $scope.items.length;
						cancelScrollInitFunction();
						$scope.$broadcast('scroll.infiniteScrollComplete');
						$scope.vs.total = $scope.items.length;
						NoData($scope.items.length, 0);
					} else {
						$ionicPopup.alert({
							template: "<p >" + res.errorMessage + "</p>"
						});
					}
				});
			}
			// 移除modalPay
			function closeModalDestroy() {
				$scope.$on('$destroy', function() {
					$scope.modalPay.remove();
				});
			}

			/*清空input的值*/
			$scope.deleteKeyword = function() {
					$scope.vs.keyword = "";
					$scope.items = [];
					$(".has-header .data").remove();
				}
				//搜索好友
			$scope.searchFriends = function() {
					isSearch = false;
					$scope.switchSearch = false;
					$scope.searchWay = false;
					//getFriendsData();
				}
				//点击搜索图标显示搜索框
			$scope.searchAll = function() {
					//isSearch = true;
					$scope.isFriends = false;
					$scope.switchSearch = false;
					//$scope.searchWay = false;
					$scope.items = [];
					$scope.startPage = 0;
				}
				//确定查找
			$scope.search = function() {
					$scope.items = [];
					$ionicScrollDelegate.resize();
					$scope.isFirstIn = true;
					$scope.startPage = 0;
					getAllData();
					$scope.switchSearch = false;
					//$(".dele-data").remove();
				}
				//已选的人

			function shareSelection() {
				for (var i = 0; i < $scope.staffs.length; i++) {
					for (var j = 0; j < $scope.items.length; j++)
						if ($scope.items[j].workId == $scope.staffs[i].workId && $scope.staffs[i].select == true) {
							$scope.items[j].select = true;
						}
				}
			}
			/*对数据遍历*/

			function getData(datas) {
				return _.map(datas, function(data) {
					return {
						name: data.name,
						workId: data.workId,
						firstLetter: data.firstLetter,
						department: data.department,
						select: false,
					};
				});
			}

			//选择人员
			$scope.selectStaff = function(item) {
				if ($scope.isPrivateMessage) {
					$scope.modalPay.hide();
					$location.path('/private-message-detail/' + item.workId);
					$scope.isPrivateMessage = false;
				} else {
					item.select = !item.select;
					if (!$scope.staffs) {
						$scope.staffs = [];
					}
					if (item.select) {
						$scope.staffs.push(item)
					} else {
						for (var i = 0; i < $scope.staffs.length; i++) {
							if (item.workId == $scope.staffs[i].workId) {
								$scope.staffs.splice(i, 1);
							}
						}
					}
				}

			}

			function getPostItem(str) {
				return {
					'contentId': $scope.id,
					'contentType': $scope.type,
					'receiverId': str
				};
			}
			//提交人员选择
			$scope.complete = function() {
					var workId = "",
						nameID = "",
						str = "",
						nameIdStr = [],
						num = [];

					for (var i = 0; i < $scope.staffs.length; i++) {
						workId = $scope.staffs[i].workId;
						nameID = $scope.staffs[i].name + '' + $scope.staffs[i].workId;
						num.push(workId);
						nameIdStr.push(nameID);
					}
					str = num.join(',');
					var datas = getPostItem(str);
					if (getType) {
						if (!$scope.staffs.length) {
							console.log('分享人为空！');
							$scope.modalPay.hide();
						} else {
							staffSelectionServices.shareData(datas).then(function(res) {
								if (res.status == 1) {
									console.log("分享成功");
									$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
										scope: $scope,
										animation: 'slide-in-up'
									}).then(function(modal) {
										$scope.modal = modal;
									});
									$scope.modalShow = 10;
									$scope.collectContent = "分享成功";
									$(".modal").append("<div class='my-modal my-collect share-modal'><p class=''>" + "分享成功" + "</p></div>");
									$timeout(function() {
										$(".modal .share-modal").remove();
										$scope.modalPay.hide();
									}, 500)
								} else {
									$ionicPopup.alert({
										template: "<p >" + res.errorMessage + "</p>"
									});
								}
							});
							console.log(datas);
						}
					} else {
						if (!$scope.staffs.length) {
							console.log('分享人为空！')
							$scope.modalPay.hide();

						} else {
							if (window.frames.length != 0) {
								$timeout(function() {
									$(document.getElementById("emoijid").contentWindow.document.body).find('.placeholder').remove();
								}, 500);
							}
							$scope.$emit('personComplete', num);
							$scope.modalPay.hide();
						}

					}
					$(".has-header .data").remove();
					//closeModalDestroy();
				}
				//取消多选中的单个人员
			$scope.cancelStaff = function(item) {
					for (var i = 0; i < $scope.staffs.length; i++) {
						if (item.workId == $scope.staffs[i].workId) {
							$scope.staffs.splice(i, 1);
						}
					}

					for (var i = 0; i < $scope.items.length; i++) {
						if (item.workId == $scope.items[i].workId) {
							$scope.items[i].select = false;
						}
					}
				}
				// 加载更多
			$scope.loadMore = function() {
				if ($scope.noMoreItemsAvailable) {
					$scope.$broadcast('scroll.infiniteScrollComplete');
					return;
				}
				if ($scope.isFirstIn) {
					$scope.isFirstIn = false;
					$scope.$broadcast('scroll.infiniteScrollComplete');
					return;
				} else {
					$scope.isFirstIn = true;
					if ($scope.isFriends) {
						$scope.startPage++;
						getFriendsData();
					} else {
						$scope.startPage++;
						getAllData();
					}

				}
			}

		}
	])

});