


define(['angularAMD'], function(angularAMD){

    angularAMD.service('FooterServices', ['$rootScope',
        function ($rootScope) {

            function show() {
                $rootScope.$broadcast("showNavigatorFooter");
            }

            function hide() {
                $rootScope.$broadcast("hideNavigatorFooter");
            }

            function activeItemByIndex(index) {
                show();
                $rootScope.$broadcast("activeNavigatorBarByIndex", index);
            }

            function removeActiveItemByIndex(index){
                hide();
                $rootScope.$broadcast("removeActiveByIndex", index);
            }
            return {
                show: show,
                hide: hide,
                activeItemByIndex: activeItemByIndex,
                removeActiveItemByIndex:removeActiveItemByIndex
            };

        }]);
        })