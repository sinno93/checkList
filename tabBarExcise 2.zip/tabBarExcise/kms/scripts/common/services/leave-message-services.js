define(['angularAMD', 'global'], function(angularAMD) {
	angularAMD.factory('leaveMessageServices', ["$http", "$q", "Global",
		function($http, $q, Global) {
			var getPromise = function(p) {
				var defer = $q.defer();
				p.success(function(response) {
					return defer.resolve(response);
				}).error(function() {
					return defer.reject();
				});
				return defer.promise;
			};
			return{
				sendLeaveMessage:function(data){
					var url = Global.apiPath+'/leavemessage/save?'+'content='+data.content+'&receiverId='+data.workId;
					if(data.isNeedParentid){
						url = url + "&parentId=" + data.parentId;
					}
					return getPromise($http.post(url));
				},
			};
		}
	]);
});