define(['angularAMD', 'common/services/footer-service', 'mine/services/mine-frame-services', 'ta/services/ta-frame-services'], function(angularAMD) {
	angularAMD.controller('taAttentionFansController', ['$scope', '$ionicModal', '$stateParams', '$location', '$rootScope', 'FooterServices', '$ionicScrollDelegate', 'MineFrameServices', 'taFrameServices',
		'$timeout', '$ionicPopup',
		function($scope, $ionicModal, $stateParams, $location, $rootScope, FooterServices, $ionicScrollDelegate, MineFrameServices, taFrameServices, $timeout, $ionicPopup) {
			'use strict';
			FooterServices.hide();
			// 是关注 or 粉丝
			var attentionOrfansKind = $stateParams.attentionorfans;

			var isFristIn = true;
			$scope.fansFollowerDataList = [];
			// 获取我的工号 1.跳转时判断是否是自己；2.在展示列表时若是自己，则不显示关注按钮
			$scope.myId = getMyId();
			console.log($scope.myId);
			// 加载modal 备用，退出时应该删除
			$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
				scope: $scope,
				animation: 'slide-in-up'
			}).then(function(modal) {
				$scope.modal = modal;
				$scope.modalYes = "是";
				$scope.modalNo = "否";
			});
			// $destroy
			$scope.$on('$destroy', function() {
				$scope.modal.remove();
			});

			$scope.isBatch = function(flag) {
				if (flag) {
					//点击了是
					console.log("isBatch true");
					$scope.modal.hide();

				} else {
					$scope.modal.hide();
				}
			};
			// 页面的一些状态，比如关键词、
			$scope.pageState = {
				'keyword': "",
				'total': ""
			};
			var dataFactor = {
					getDataType: "", // refresh, init
					keyWord: "", // 关键词
					isFansKind: "", //true:是粉丝 false 关注
					startPage: 0, //开始页，0为第一页
					pageSize: 8, //每页的记录数
					searchKey: "", //粉丝姓名，用于搜索，为空时搜索全部
					searchKind: "", // 搜索的方式 为allPerson时 搜全网
					searchRealKind: "",
					workID: $stateParams.workID,
				}
				// 进行关注时的操作
			var followTaData = {
				follow: '',
				workId: ''
			}
			$scope.items = [];
			//放置在搜索框里的文本
			$scope.placeholderText = "输入姓名搜索我的";

			function init() {
				//正在搜索
				$scope.isSearching = false;
				//已经点击了确定，搜索
				$scope.isSearched = false;
				if (attentionOrfansKind == 'attention') {
					$scope.title = "TA的关注";
					dataFactor.isFansKind = false;
				} else if (attentionOrfansKind == 'fans') {
					$scope.title = "TA的粉丝";
					dataFactor.isFansKind = true;
				} else $scope.title = "unknow stateParams";

				dataFactor.getDataType = "init";
				dataFactor.startPage = 0;
				getDataFromServer(dataFactor);
				$scope.switchSearch = true;
				//在此处应该根据attentionOrfansKind 调用不同的接口
				$scope.noMoreItemsAvailable = true;

			}

			init();
			//右上角的返回按钮 返回上一页
			$scope.back = function() {
				//若是正在搜索中，则关闭搜索框
				if ($scope.isSearching) {
					// 退出搜索状态
					$scope.isSearching = false;
					// 若已经点击过确定搜索按钮，则关闭其结果,并滚动到顶部
					if ($scope.isSearched) $scope.isSearched = false;
					$ionicScrollDelegate.resize()
					$ionicScrollDelegate.scrollTop();
					$scope.pageState.keyword = "";
					dataFactor.searchKey = "";
					// 若点击了搜索全部，则此处应该清空
					dataFactor.searchKind = "";
					dataFactor.searchRealKind = "";
					init();
				} else {
					$location.path("/mine");
					console.log("back clicked");
				}
			};
			// 搜索确定按钮
			$scope.enSureSearch = function() {
					//在这里进行搜索处理
					$scope.isSearched = true;
					dataFactor.startPage = 0;
					dataFactor.getDataType = "search";
					dataFactor.searchKey = $scope.pageState.keyword;
					dataFactor.searchRealKind = dataFactor.searchKind;
					getDataFromServer(dataFactor);
					$ionicScrollDelegate.scrollTop();

				}
				// 点击搜索触发的事件
			$scope.searchFansorFllow = function() {
				$scope.isSearching = true;
				if (dataFactor.isFansKind) {
					$scope.placeholderText = "输入姓名搜索我的粉丝";
				} else {
					$scope.placeholderText = "输入姓名搜索我的关注";
				}
			}
			$scope.toSearchAll = function() {
					$scope.isSearching = true;
					dataFactor.searchKind = "allPerson";
					$scope.placeholderText = "输入姓名搜索全网的人";
				}
				/*点击搜索框的x 清空input的值*/
			$scope.deleteKeyword = function() {
				$scope.pageState.keyword = "";
			};
			// 下拉动作，完成刷新操作
			$scope.onRefresh = function() {
				//	1.获取最新的数据；然后广播
				dataFactor.getDataType = "refresh";
				dataFactor.startPage = 0;
				getDataFromServer(dataFactor);
			}
			$scope.loadMore = function() {
					if (isFristIn) {
						isFristIn = false;

						$scope.$broadcast('scroll.infiniteScrollComplete');
						return 0;
					}
					dataFactor.startPage += 1;
					dataFactor.getDataType = "loadMore";
					getDataFromServer(dataFactor);
				}
				// 点击关注、取消关注
			$scope.followTa = function(item, $event) {
				// 阻止事件向下传播
				$event.stopPropagation();
				var data = {
					userId: item.workId,
					action: ''
				}
				if (item.isFollowed) {
					data.action = "unfollow";
				} else data.action = "follow";
				// 在此进行关注、取消关注操作
				//MineFrameServices.getMineAttentionFansData(dataFactor).then(function(res) {
				MineFrameServices.FollowOrUnfollowTa(data).then(function(res) {
					console.log(res);
					if (res.status == 1) {
						item.isFollowed = !item.isFollowed;
					} else {
						// 错误处理
						$ionicPopup.alert({
							template: "<p>" + res.errorMessage + "</p>"
						});
					}
				});
			}
			$scope.searchKeyDown = function(e) {
					console.log("keyboard", e);
					if (e.keyCode == 13) {
						$scope.enSureSearch();
					}
				}
				// 点击一个人 跳到详情 当为ta的粉丝、好友时，跳转要判断是否是自己
			$scope.clickPerson = function(item) {
					console.log("getMyId", $scope.myId)
					if ($scope.myId != item.workId) {
						$location.path("/ta/" + item.workId);
					} else $location.path("/mine");

				}
				/*获取格式化后的数据：对数据遍历,进行数据对接工作*/
			function getFormatData(datas) {
				return _.map(datas, function(data) {
					var isFollowed = false;
					if (dataFactor.searchRealKind == 'allPerson') {
						if (data.isAttention == 0) data.isAttention = false;
						else data.isAttention = true;
						return {
							name: data.name,
							workId: data.empNumber,
							department: data.deptName,
							select: false,
							headimgUrl: data.headPath,
							position: data.position,
							isFollowed: data.isAttention,
						}
					}
					if (attentionOrfansKind == 'attention') isFollowed = true;
					if (attentionOrfansKind == "fans") {
						if (data.isAttention == 0) data.isAttention = false;
						else data.isAttention = true;
						return {
							name: data.userName,
							workId: data.userId,
							department: data.deptName,
							select: false,
							headimgUrl: data.headPath,
							position: data.position,
							isFollowed: data.isAttention,
						}
					} else if (attentionOrfansKind == "attention") {
						return {
							name: data.attentionObjectName,
							workId: data.attentionObjectId,
							department: data.deptName,
							select: false,
							headimgUrl: data.headPath,
							position: data.position,
							isFollowed: data.isAttention,
						}
					}

				});
			}

			function selectBoxShow(sign, info) {
				$scope.modalShow = 3;
				$scope.explain = info;
				$scope.modal.show();
			};

			function checkAvailableItems(total) {
				$scope.noMoreItemsAvailable = dataFactor.startPage >= (total - 1);
			}
			// 从服务器 获取数据并进行格式化
			function getDataFromServer(dataFactor) {
				taFrameServices.getTaAttentionFansData(dataFactor).then(function(res) {
					if (res.status == '1') {
						var length = res.data.length;
						if (dataFactor.getDataType == "init") {
							$scope.fansFollowerDataList = getFormatData(res.data);
						} else if (dataFactor.getDataType == 'refresh') {
							$scope.fansFollowerDataList = getFormatData(res.data);
							refreshCompeleteInfoShow(length, 'refresh');
						} else if (dataFactor.getDataType == "loadMore") {
							var otherList = getFormatData(res.data);
							$scope.fansFollowerDataList = $scope.fansFollowerDataList.concat(otherList);
							refreshCompeleteInfoShow(length, 'loadMore');
						} else if (dataFactor.getDataType == "search") {
							$scope.fansFollowerDataList = getFormatData(res.data);
						}
						checkAvailableItems(res.totalPage);
						NoData(length, 1);
					} else {
						// 服务器那边有错误
					}

				});
			}
			// 刷新完成的提示显示函数
			function refreshCompeleteInfoShow(length, type) {
				var time = 1500;
				if (type == 'refresh') {
					$scope.$broadcast('scroll.refreshComplete');
					var info = length > 0 ? "已为您更新" + length + "条数据" : "暂时没有数据";
					$scope.refresherData = info;
					$(".refresher-data").show();
					$timeout(function() {
						$(".refresher-data").hide();
					}, time);
				} else if (type == 'loadMore') {
					$scope.$broadcast('scroll.infiniteScrollComplete');
					var info = length > 0 ? "已为您加载" + length + "条数据" : "暂时没有数据";
					$scope.infiniteData = info;
					$(".infinite-data").show();
					$timeout(function() {
						$(".infinite-data").hide();
					}, time);
				}
			};
			$scope.scrollDragUp = function(){
				dragUp($ionicScrollDelegate,$scope);
			};
			
				$scope.dealPath = function(url){
				return assembleImageUrl(url);
			};
		}
	])

});