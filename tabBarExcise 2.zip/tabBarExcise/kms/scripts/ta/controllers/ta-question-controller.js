define(['angularAMD', 'common/services/footer-service', 'common/services/common-group-service', 'ta/services/ta-frame-services','common/filters/common-filter'], function(angularAMD) {
	angularAMD.controller('taQuestionController', ['$scope', '$ionicModal', '$location', '$rootScope', 'FooterServices', '$ionicScrollDelegate', 'commonGroupServices', '$timeout', '$stateParams', 'taFrameServices',
		function($scope, $ionicModal, $location, $rootScope, FooterServices, $ionicScrollDelegate, commonGroupServices, $timeout, $stateParams, taFrameServices) {
			'use strict';
			FooterServices.hide();


			$scope.title = "TA的爱问";
			var DEFAULT_PAGE_SIZE = 8;
			$scope.startPage = 0;
			$scope.tabGroup = commonGroupServices.getTaQuestionGroup();
			$scope.curTab = 'taQuestion';
			$scope.notSelf = false;
			//----------------js私有方法----------------

			function initPager() {
				$scope.startPage = 0;
				$scope.pageSize = DEFAULT_PAGE_SIZE;
				$scope.noMoreItemsAvailable = true;
			}
			$scope.back = function() {
				$rootScope.$viewHistory.backView.go();
			}

			function cleanAllActiveStatus() {
				_.each($scope.tabGroup, function(tab) {
					tab.isActive = false;
				});
			}
			/**请求数据参数组装*/
			function assembleRequest() {
				return {
					'empNumber': $stateParams.workID,
					'startPage': $scope.startPage,
					'pageSize': $scope.pageSize
				}
			}
			//得到标签的名字

			function getTabByName(tabName) {
				return _.find($scope.tabGroup, function(tab) {
					return tab.name === tabName;
				});
			}


			//-------------------------------------------



			//------------------页面逻辑方法-------------


			$scope.activeTab = function(tabName) {
				cleanAllActiveStatus();
				var tab = getTabByName(tabName);
				$scope.isFirstIn = true;
				tab.isActive = true;
				$scope.items = [];
				$scope.curTab = tabName;
				if (tabName == 'taQuestion') {
					initTaQuestion();
				} 
				if (tabName == 'taAnswer') {
					initTaAnswer();
				} 
				if(tabName == 'taAttention'){
					initTaAttention();
				}

				$ionicScrollDelegate.resize();
			}
			$scope.getImageUrl = function(url){
				return assembleImageUrl(url)+'.thumbnail';
			};
			$scope.hasImage = function(item) {
				return !_.isEmpty(item.questionImage);
			};
			$scope.getCreator = function(item) {
				var result = item.createrName + ' ' + item.createrId;
				return result;
			};
			$scope.answerType = function(isSolve) {
				if (isSolve == 1) {
					return '我来补充';

				} else {
					return '我来回答';
				}
			};
			$scope.isSlove = function(isSlove) {
				if (isSlove == 1) {
					return '已解决';

				} else {
					return '未解决';
				}
			};
			$scope.toAnswerQuestion = function(item, event) {
				$location.path('/create-answer/' + item.id);
				event.stopPropagation();

			};
			$scope.hasReward = function(item) {
				return item.rewardScore > 0;
			};
			$scope.toCreatorDetail = function(item) {
				$location.path('/ta/' + item.id);
			};
			$scope.goAskDetail = function(item) {
				$location.path('/asksDetail/' + item.id);
			};
			$scope.isShow = function(item){
				if($scope.notSelf){
					if(item.createrId != getMyId()){
						return true;
					}else{
						return false;
					}
				}else{
					return true;
				}
			};
			//---------------------------------------------


			//------------------数据加载方法-------------
			/**初始化Ta的问题*/
			function initTaQuestion() {
				$scope.notSelf = false;
				initPager();
				taFrameServices.getTaAskInfoList(assembleRequest()).then(function(response) {
					console.log(response);
					$scope.items = response.data;
					checkAvailableItems(response.totalSize);
					cancelScrollInitFunction();
				});
			}
			/**初始化Ta的回答*/

			function initTaAnswer() {
				$scope.notSelf = true;
				initPager();
				taFrameServices.getTaAskAnswerInfoList(assembleRequest()).then(function(response) {
					console.log(response);
					$scope.items = response.data;
					checkAvailableItems(response.totalSize);
					cancelScrollInitFunction();
				});
			}
			/**初始化Ta的关注*/

			function initTaAttention() {
				$scope.notSelf = true;
				initPager();
				taFrameServices.getTaAskAttentionInfoList(assembleRequest()).then(function(response) {
					console.log(response);
					$scope.items = response.data;
					checkAvailableItems(response.totalSize);
					cancelScrollInitFunction();
				});
			}
			$scope.onRefresh = function() {
				if ($scope.curTab == 'taQuestion') {
					taFrameServices.getTaAskInfoList(assembleRequest()).then(function(response) {
						console.log(response);
						$scope.items = response.data;
						checkAvailableItems(response.totalSize);
						cancelScrollInitFunction();
					});
				} else if ($scope.curTab == 'taAnswer') {
					taFrameServices.getTaAskAnswerInfoList(assembleRequest()).then(function(response) {
						console.log(response);
						$scope.items = response.data;
						checkAvailableItems(response.totalSize);
						cancelScrollInitFunction();
					});
				} else {
					taFrameServices.getTaAskAttentionInfoList(assembleRequest()).then(function(response) {
						console.log(response);
						$scope.items = response.data;
						checkAvailableItems(response.totalSize);
						cancelScrollInitFunction();
					});
				}
			};

			function cancelScrollInitFunction() {
				$timeout(function() {
					$scope.$broadcast('scroll.refreshComplete');
				}, 100);
			}

			function checkAvailableItems(total) {
				$scope.noMoreItemsAvailable = $scope.items.length === total;
			}
			$scope.isFirstIn = true;
			$scope.loadMore = function() {

				if ($scope.noMoreItemsAvailable) {
					$scope.$broadcast('scroll.infiniteScrollComplete');
					return;
				}
				if ($scope.isFirstIn) {
					$scope.isFirstIn = false;
					$scope.$broadcast('scroll.infiniteScrollComplete');
					return;
				}
				$scope.startPage++;
				if ($scope.curTab == 'taQuestion') {
					taFrameServices.getTaAskInfoList(assembleRequest()).then(function(response) {
						var newItems = response.data;
						_.each(newItems, function(item) {
							$scope.items.push(item);
						});
						$scope.$broadcast('scroll.infiniteScrollComplete');

						checkAvailableItems(response.totalSize);
					});
				} else if ($scope.curTab == 'taAnswer') {
					taFrameServices.getTaAskAnswerInfoList(assembleRequest()).then(function(response) {
						var newItems = response.data;
						_.each(newItems, function(item) {
							$scope.items.push(item);
						});
						$scope.$broadcast('scroll.infiniteScrollComplete');

						checkAvailableItems(response.totalSize);
					});
				} else {
					taFrameServices.getTaAskAttentionInfoList(assembleRequest()).then(function(response) {
						var newItems = response.data;
						_.each(newItems, function(item) {
							$scope.items.push(item);
						});
						$scope.$broadcast('scroll.infiniteScrollComplete');

						checkAvailableItems(response.totalSize);
					});
				}

			};
			//---------页面初始化--------------



			function init() {
				initPager();
				$scope.notSelf = false;
				taFrameServices.getTaAskInfoList(assembleRequest()).then(function(response) {
					console.log(response);
					$scope.items = response.data;
					checkAvailableItems(response.totalSize);
					cancelScrollInitFunction();
				});
			}
			/**初始化Tab选项样式的设置，默认第一个Tab为进入选中Tab*/
			function initTabGroup() {
				$scope.tabGroup[0].isActive = true;
			}
			init();
			initTabGroup();
		}
	])

});