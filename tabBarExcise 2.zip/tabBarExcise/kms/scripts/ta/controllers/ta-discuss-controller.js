define(['angularAMD', 'common/services/footer-service', 'ta/services/ta-frame-services','common/controllers/staff-selection-controller','common/directive/hot-list-item'], function(angularAMD) {
	angularAMD.controller('taDiscussController', ['$scope', '$stateParams', '$ionicModal', '$location', '$rootScope', 'hotServices','FooterServices', '$ionicScrollDelegate', '$timeout','taFrameServices',
		function($scope, $stateParams,$ionicModal, $location, $rootScope,hotServices, FooterServices, $ionicScrollDelegate, $timeout,taFrameServices) {
			'use strict';
			FooterServices.hide();
			$scope.title = "TA的sss讨论";
			$scope.listData = [];
			$scope.isFirstIn = true;
			//初始化
			
			var dataFactor ={
				workId:$stateParams.workID,
				
				startPage:0,
				pageSize:10,
			}
			init();
			function init() {
					initPager($scope);
					getData(dataFactor,"init");
				}
				//请求数据

			function getData(dataFactor,type) {
					taFrameServices.getTaDiscussData(dataFactor).then(function(res) {
						console.log(res);
						if (res.status == 1) {
							switch(type){
								case "init":
									$scope.listData = traverseData(res.data);
									break;
								case "refresh":
									$scope.listData =  traverseData(res.data);
									break;
								case "loadmore":
									$scope.listData = $scope.listData.concat(traverseData(res.data));
									$scope.$broadcast('scroll.infiniteScrollComplete');
									break;
								default:
									console.error("type not defined");
									break;
							}
							
							$scope.noMoreItemsAvailable = dataFactor.startPage >= (res.totalPage-1);
							cancelScrollInitFunction($scope);
							
							refreshData(type, res.data.length);
						} else {
							$ionicPopup.alert({
								template: "<p >" + res.errorMessage + "</p>"
							});
						}

					})
				}
				//上下拉刷新数据条数 

			function refreshData(type, length) {
					if (type == "refresh") {
						if (length > 0) {
							$scope.refresherData = "已经为您更新" + length + "条数据";
							$(".refresher-data").show();
							$timeout(function() {
								$(".refresher-data").hide();
							}, 1500);
						}

					} else if (type == "loadMore") {
						if (length > 0) {
							$scope.infiniteData = "已经为您加载" + length + "条数据";
							$(".infinite-data").show();
							$timeout(function() {
								$(".infinite-data").hide();
							}, 1500);
						}
					}
					NoData(length);
				}
				// 对数据遍历

			function traverseData(datas) {
					return _.map(datas, function(data) {
						return {
							chType: "讨论",
							type: "theme",
							date: data.createrDate,
							contentId: data.id,
							title: data.theme,
							imageUrl: assembleImageUrl(data.imagePath)
						}
					})
				}
				//跳转详情
			$scope.goDeatil = function(data) {
					console.log(data);
					$location.path('/hotDetail/' + data.contentId + "/" + data.type);
				}
				// 下拉刷新
			$scope.onRefresh = function() {
					$scope.listData = [];
					dataFactor.startPage = 0;
					getData(dataFactor,"refresh");
				}
				// 加载更多
			$scope.loadMore = function() {
				if ($scope.noMoreItemsAvailable) {
					$scope.$broadcast('scroll.infiniteScrollComplete');
					return;
				}
				if ($scope.isFirstIn) {
					$scope.isFirstIn = false;
					$scope.$broadcast('scroll.infiniteScrollComplete');
					return;
				} else {
					$scope.isFirstIn = true;
					dataFactor.startPage++;
					getData("loadMore");
				}
			}

		}
	])

});