define(['angularAMD', 'common/services/footer-service', 'common/services/common-group-service', 'mine/services/mine-frame-services', 'common/filters/common-filter'], function(angularAMD) {
	angularAMD.controller('myQuestionController', ['$scope', '$ionicModal', '$location', '$rootScope', 'FooterServices', '$ionicScrollDelegate', 'commonGroupServices', 'MineFrameServices', '$timeout',
		function($scope, $ionicModal, $location, $rootScope, FooterServices, $ionicScrollDelegate, commonGroupServices, MineFrameServices, $timeout) {
			'use strict';
			FooterServices.hide();


			$scope.title = "我的爱问";
			var DEFAULT_PAGE_SIZE = 8;
			$scope.startPage = 1;
			$scope.tabGroup = commonGroupServices.getMyQuestionGroup();
			$scope.curTab = 'myQuestion';
			$scope.notSelf = false;
			//----------------js私有方法----------------

			function initPager() {
				$scope.startPage = 0;
				$scope.pageSize = DEFAULT_PAGE_SIZE;
				$scope.noMoreItemsAvailable = true;
			}

			function cleanAllActiveStatus() {
				_.each($scope.tabGroup, function(tab) {
					tab.isActive = false;
				});
			}
			/**请求数据参数组装*/
			function assembleRequest() {
				return {
					'startPage': $scope.startPage,
					'pageSize': $scope.pageSize
				};
			}
			//得到标签的名字

			function getTabByName(tabName) {
				return _.find($scope.tabGroup, function(tab) {
					return tab.name === tabName;
				});
			}


			//-------------------------------------------



			//------------------页面逻辑方法-------------


			$scope.activeTab = function(tabName) {
				cleanAllActiveStatus();
				var tab = getTabByName(tabName);
				$scope.isFirstIn = true;
				tab.isActive = true;
				$scope.items = [];
				$scope.curTab = tabName;
				if (tabName == 'myQuestion') {
					console.log('myquestion');
					initMyQuestion();
				} else if (tabName == 'myAnswer') {
					console.log('myAnswer');
					initMyAnswer();
				} else {
					console.log('myAttention');
					initMyAttention();
				}

				$ionicScrollDelegate.resize();
			}
			$scope.getImageUrl = function(url){
				return assembleImageUrl(url)+'.thumbnail';
			};
			$scope.hasImage = function(item) {
				return !_.isEmpty(item.questionImage);
			};
			$scope.getCreator = function(item) {
				var result = item.createrName + ' ' + item.createrId;
				return result;
			};
			$scope.answerType = function(isSolve) {
				if (isSolve == 1) {
					return '我来补充';

				} else {
					return '我来回答';
				}
			};
			$scope.isSlove = function(isSlove) {
				if (isSlove == 1) {
					return '已解决';

				} else {
					return '未解决';
				}
			};
			$scope.toAnswerQuestion = function(item, event) {
				$location.path('/create-answer/' + item.id);
				event.stopPropagation();
			};
			$scope.showPic = function(src, event) {
				var imgArray = [];
				imgArray.push(src);
				pictrueViewer(imgArray);
				event.stopPropagation();
			}
			$scope.hasReward = function(item) {
				return item.rewardScore > 0;
			};
			$scope.toCreatorDetail = function(item, event) {
				$location.path('/ta/' + item.createrId);
				event.stopPropagation();
			};
			$scope.goAskDetail = function(item) {
				$location.path('/asksDetail/' + item.id);
			};
			//---------------------------------------------



			function refreshData(type, length) {
				if (type == "refresh") {
					if (length > 0) {
						$scope.refresherData = "已经为您更新" + length + "条数据";
						$(".refresher-data").show();
						$timeout(function() {
							$(".refresher-data").hide();
						}, 1500);
					}

				} else if (type == "loadMore") {
					if (length > 0) {
						$scope.infiniteData = "已经为您加载" + length + "条数据";
						$(".infinite-data").show();
						$timeout(function() {
							$(".infinite-data").hide();
						}, 1500);
					}
				}

			}


			function checkNewItemsCount(newItems, items) {
				var count = 0;
				var temp = items[0].senderDate;
				for (var i = 0; i < newItems.length; i++) {
					if (newItems[i].senderDate != temp) {
						if (i == 0) {
							items.unshift(newItems[i]);
						} else {
							items.splice(i, 0, newItems[i]);
						}
						count++;
					} else {
						break;
					}
				}
				return count;
			}


			//------------------数据加载方法-------------
			/**初始化我的问题*/
			function initMyQuestion() {
				$scope.notSelf = false;
				initPager();
				console.log($scope.items);
				MineFrameServices.getMyQuestion(assembleRequest()).then(function(response) {
					$scope.items = response.data;
					console.log($scope.items);
					checkAvailableItems(response.totalSize);
					cancelScrollInitFunction();
					NoData($scope.items.length, 1);
				});

			}
			/**初始化我的回答*/

			function initMyAnswer() {
				$scope.notSelf = true;
				initPager();
				console.log($scope.items);
				MineFrameServices.getMyAnswer(assembleRequest()).then(function(response) {
					$scope.items = response.data;
					console.log($scope.items);
					checkAvailableItems(response.totalSize);
					cancelScrollInitFunction();
					NoData($scope.items.length, 1);
				});
			}
			/**初始化我的关注*/

			function initMyAttention() {
				$scope.notSelf = true;
				initPager();
				console.log($scope.items);
				MineFrameServices.getMyAttention(assembleRequest()).then(function(response) {
					$scope.items = response.data;
					console.log($scope.items);
					checkAvailableItems(response.totalSize);
					cancelScrollInitFunction();
					NoData($scope.items.length, 1);
				});
			}
			$scope.onRefresh = function() {
				if ($scope.curTab == 'myQuestion') {
					MineFrameServices.getMyQuestion({
						'startPage': 0,
						'pageSize': $scope.pageSize
					}).then(function(response) {
						var newItems = response.data;
						cancelScrollInitFunction();
						var count = checkNewItemsCount(newItems, $scope.items);
						refreshData('refresh', count);
					});
				} else if ($scope.curTab == 'myAnswer') {
					MineFrameServices.getMyAnswer({
						'startPage': 0,
						'pageSize': $scope.pageSize
					}).then(function(response) {
						var newItems = response.data;
						cancelScrollInitFunction();
						var count = checkNewItemsCount(newItems, $scope.items);
						refreshData('refresh', count);
					});
				} else {
					MineFrameServices.getMyAttention({
						'startPage': 0,
						'pageSize': $scope.pageSize
					}).then(function(response) {
						var newItems = response.data;
						cancelScrollInitFunction();
						var count = checkNewItemsCount(newItems, $scope.items);
						refreshData('refresh', count);
					});
				}
			};

			function cancelScrollInitFunction() {
				$timeout(function() {
					$scope.$broadcast('scroll.refreshComplete');
				}, 100);
			}

			function checkAvailableItems(total) {
				$scope.noMoreItemsAvailable = $scope.items.length === total;
			}
			$scope.isFirstIn = true;
			$scope.loadMore = function() {

				if ($scope.noMoreItemsAvailable) {
					$scope.$broadcast('scroll.infiniteScrollComplete');
					return;
				}
				if ($scope.isFirstIn) {
					$scope.isFirstIn = false;
					$scope.$broadcast('scroll.infiniteScrollComplete');
					return;
				}
				$scope.startPage++;
				if ($scope.curTab == 'myQuestion') {
					MineFrameServices.getMyQuestion(assembleRequest()).then(function(response) {
						var newItems = response.data;
						_.each(newItems, function(item) {
							$scope.items.push(item);
						});
						$scope.$broadcast('scroll.infiniteScrollComplete');

						checkAvailableItems(response.totalSize);
					});
				} else if ($scope.curTab == 'myAnswer') {
					MineFrameServices.getMyAnswer(assembleRequest()).then(function(response) {
						var newItems = response.data;
						_.each(newItems, function(item) {
							$scope.items.push(item);
						});
						$scope.$broadcast('scroll.infiniteScrollComplete');

						checkAvailableItems(response.totalSize);
					});
				} else {
					MineFrameServices.getMyAttention(assembleRequest()).then(function(response) {
						var newItems = response.data;
						_.each(newItems, function(item) {
							$scope.items.push(item);
						});
						$scope.$broadcast('scroll.infiniteScrollComplete');

						checkAvailableItems(response.totalSize);
					});
				}

			};
			//---------页面初始化--------------



			function init() {
				initPager();
				MineFrameServices.getMyQuestion(assembleRequest()).then(function(response) {
					console.log(response);
					$scope.items = response.data;
					checkAvailableItems(response.totalSize);
					cancelScrollInitFunction();
				});
			}
			/**初始化Tab选项样式的设置，默认第一个Tab为进入选中Tab*/
			function initTabGroup() {
				$scope.tabGroup[0].isActive = true;
			}
			init();
			initTabGroup();
		}
	])

});