define(['angularAMD', 'common/services/footer-service', 'mine/services/mine-frame-services', 'common/directive/input-box', 'common/filters/common-filter', 'common/controllers/staff-selection-controller', 'common/directive/common-review'], function(angularAMD) {
	angularAMD.controller('talkDetailController', ['$scope', '$stateParams', '$ionicModal', '$location', '$rootScope', 'MineFrameServices', 'FooterServices', '$ionicScrollDelegate', '$timeout',
		function($scope, $stateParams, $ionicModal, $location, $rootScope, MineFrameServices, FooterServices, $ionicScrollDelegate, $timeout) {
			'use strict';
			/*传入参数*/
			var parameter={};
			parameter.userId=getMyId() || "002628";//用户Id
			parameter.userName=getMyName() || "临时登录用户！";//用户Id
			parameter.microblogId=$stateParams.microblogId;
			parameter.meOrTa=$stateParams.empNumber?'ta':'me';
			parameter.empNumber=$stateParams.empNumber;
			/*分页控制*/
			var listPageSize=5;
			var listStartPage=0;
			/*评论数据*/
			var commentData={};
			commentData.type='';
			commentData.setTooltip=function(t){
				$scope.$broadcast("inputBoxPlaceholder", t);
			};
			commentData.id1='';
			commentData.id2='';
			commentData.commenterId1='';
			commentData.commenterId2='';
			commentData.commenterName1='';
			commentData.commenterName2='';
			commentData.receiverId1='';
			commentData.receiverId2='';
			commentData.receiverName1='';
			commentData.receiverName2='';

			/*定义对话框*/
			$scope.showDialogbox1=function(text, callback){/*confirm*/
				$scope.explain = text;
				$scope.modalYes = "确定";
				$scope.modalNo = "取消";
				$scope.modalShow = 3;
				$scope.isBatch = function(flag) {
					if(flag){
						callback();
					}
					$scope.modal.hide();
				};
				$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
					scope: $scope,
					animation: 'slide-in-up'
				}).then(function(modal) {
					$scope.modal = modal;
					$scope.modal.show();
				});
			};
			var showDialogbox2=function(text){/*提示*/
				$scope.modalShow = 10;
				$scope.collectContent = text;
				$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
					scope: $scope,
					animation: 'slide-in-up'
				}).then(function(modal) {
					$scope.modal = modal;
					$scope.modal.show();
					$timeout(function(){
						$scope.modal.hide();
					}, 1000);
				});
			};
			/*刷新数据提示*/
			function refreshData(type, length) {
				if (type == "refresh") {
					if (length > 0) {
						$scope.refresherData = "已经为您更新" + length + "条数据";
						$(".refresher-data").show();
						$timeout(function() {
							$(".refresher-data").hide();
						}, 1000);
					}

				} else if (type == "loadMore") {
					if (length > 0) {
						$scope.infiniteData = "已经为您加载" + length + "条数据";
						$(".infinite-data").show();
						$timeout(function() {
							$(".infinite-data").hide();
						}, 1000);
					}
				}
				NoData(length,1);
			};
			var isShowNomore=false;
			$scope.scrollDragUp=function(){
				var currentTop = $ionicScrollDelegate.getScrollPosition().top;
				var maxTop = $ionicScrollDelegate.getMaxTop();
				if (currentTop - maxTop > 50 && maxTop > 0) {
					if (!isShowNomore && $scope.scrollEnded) {
						isShowNomore = true;
						$scope.infiniteData = "已经到底啦!";
						$(".infinite-data").show();
						setTimeout(function() {
							$(".infinite-data").hide();
							isShowNomore = false;
						}, 700);
					}

				}
			}
			/*页面表情转码*/
			$scope.emoijToText=function(html){
				if(!html){
					return;
				}
				return replace_html(html)
			};
			/*转到他的主页*/
			$scope.goHome=function(userId){
				if(userId==getMyId()){
					$location.path('/mine');
				}else{
					$location.path('/ta/'+userId);
				}
			};

			var init=function(){
				FooterServices.hide();
				$scope.meOrTa=parameter.meOrTa;
				$scope.title = "说说";
				inputBoxImg($scope);
				$scope.sign.showKeyboardIf=false;
				$("ion-content").on("touchstart", function(event){
					var $target=$(event.target);
					if(!($target.hasClass('mine-delrep')||$target.parents().hasClass('mine-delrep'))){
						$(".mine-delrep").hide();
					}
				});
				$scope.userId=parameter.userId;
				$scope.userName=parameter.userName;
				$scope.isDelete=false;

				var data={};
				data.param={};
				data.param.microblogId=parameter.microblogId;
				MineFrameServices.getTalkDetail(data).then(function(result){
					if(result.status){
						$scope.talkItem=result.data;
						$scope.isDelete=($scope.talkItem.createrId==parameter.userId);
						$scope.replyDefault();
					}else{
						$ionicPopup.alert({
							template: "<p >" + result.errorMessage + "</p>"
						});
					}
				});
			}
			init();

			/*评论留言*/
			$scope.showKeyboard = function(autofocus) {
				var text = "回复：" + commentData.receiverName1;
				if(autofocus==0){
					text="我也说两句"
				}
				$timeout(function() {
					if (autofocus == 1) {
						$scope.$broadcast("inputOnFocus");
					}
					commentData.setTooltip(text);

				}, 500);
			};
			$scope.reply=function(event){
				var $target=$(event.target).hasClass('target')?$(event.target):$(event.target).parents(".target");
				commentData.type=$target.data('type');
				commentData.id1='';
				commentData.id2=$target.data('id2');
				commentData.commenterId1='';
				commentData.commenterId2=$target.data('commenterid2');
				commentData.commenterName1='';
				commentData.commenterName2=$target.data('commentername2');
				commentData.receiverId1='';
				commentData.receiverId2=$target.data('receiverid2');
				commentData.receiverName1='';
				commentData.receiverName2=$target.data('receivername2');

				var text="回复："+commentData.receiverName2;
				$scope.$broadcast("inputOnFocus");
				commentData.setTooltip(text);
				$(".mine-delrep").hide();
			}
			$scope.replyOthers=function(event){
				$scope.reply(event);
			}
			$scope.$on('inputSend', function(event, data){
				if(data.indexOf('placeholder') != -1 || data==""){
					showDialogbox2("请填写评论内容");
					return false;
				}
				var content=data;
				var data={};
				data.param={};
				data.param.content=content;
				data.param.contentId=parameter.microblogId;
				data.param.receiverId=(commentData.type==1)?commentData.receiverId1:commentData.receiverId2;
				var date=new Date();
				date=date.getTime();
				MineFrameServices.replyTalkDetail(data).then(function(result){
					if(result.status){
						var replyId=result.data.id;
						var reply={
							id: replyId,
							content: content,
							createrId: (commentData.type==1)?commentData.commenterId1:commentData.commenterId2,
							createrName: (commentData.type==1)?commentData.commenterName1:commentData.commenterName2,
							createDate: date,
							receiverId: (commentData.type==1)?commentData.receiverId1:commentData.receiverId2,
							receiverName: (commentData.type==1)?commentData.receiverName1:commentData.receiverName2
						}
						if(!$scope.talkItem.comments){
							$scope.talkItem.comments=[];
						}
						$scope.talkItem.comments.unshift(reply);
						showDialogbox2("回复成功");
						$scope.replyDefault();
					}else{
						$ionicPopup.alert({
							template: "<p >" + result.errorMessage + "</p>"
						});
					}
				});
			});
			$scope.replyDefault = function(at) {
				commentData.type=1;
				commentData.id1=parameter.microblogId;
				commentData.id2='';
				commentData.commenterId1=parameter.userId;
				commentData.commenterId2='';
				commentData.commenterName1=parameter.userName;
				commentData.commenterName2='';
				commentData.receiverId1=$scope.talkItem.createrId;
				commentData.receiverId2='';
				commentData.receiverName1=$scope.talkItem.createrName;
				commentData.receiverName2='';

				$scope.showKeyboard(at ? at : 0);
			}
			/*删除留言*/
			$scope.showTools=function(event){
				var $target=$(event.target).hasClass('target-del')?$(event.target):$(event.target).parents(".target-del");
				var createrId=$target.data('createrid');
				$scope.delOrRep=(createrId==parameter.userId)?'del':'rep';
				$target.find(".mine-delrep").show();
			}
			$scope.delete=function(parentId, replyId){
				var data={};
				data.meOrTa=parameter.meOrTa;
				data.param={};
				data.param.commentId=replyId;
				MineFrameServices.deleteTalkReply(data).then(function(result){
					if(result.status){
						$($scope.talkItem.comments).each(function(index, el) {
							if(el.id==replyId){
								$scope.talkItem.comments.splice(index, 1);
								$(".mine-detele").hide();
								return;
							}
						});
						showDialogbox2("删除成功");
					}else{
						$ionicPopup.alert({
							template: "<p >" + result.errorMessage + "</p>"
						});
					}
				});
			}
			/*删除说说*/
			$scope.deleteThis=function(){
				$scope.showDialogbox1("删除说说？", function(){
					var data={};
					data.param={};
					data.param.microblogId=parameter.microblogId;
					MineFrameServices.deleteTalkDetail(data).then(function(result){
						if(result.status){
							showDialogbox2("删除成功");
							if(parameter.meOrTa=="me"){
								$location.path('/talk-list/me/');
							}else{
								$location.path('/talk-list/ta/'+parameter.empNumber);
							}
						}else{
							$ionicPopup.alert({
								template: "<p >" + result.errorMessage + "</p>"
							});
						}
					});
				});
			}

			/*点赞留言*/
			$scope.praise=function(){
				var praise=!$scope.talkItem.isPraise;
				var data={};
				data.meOrTa=parameter.meOrTa;
				data.isCancel=!praise;
				data.param={};
				data.param.microblogId=parameter.microblogId;
				MineFrameServices.praiseTalkDetail(data).then(function(result){
					if(result.status){
						if(praise){
							$scope.talkItem.isPraise=true;
							$scope.talkItem.praiseCount++;
						}else{
							$scope.talkItem.isPraise=false;
							$scope.talkItem.praiseCount--;
						}
					}else{
						$ionicPopup.alert({
							template: "<p >" + result.errorMessage + "</p>"
						});
					}
				});
			}

			/*刷新数据*/
			$scope.doRefresh = function(atTop) {
				if (atTop) {
					$scope.talkItem.comments = {};

					var data={};
					data.param={};
					data.param.microblogId=parameter.microblogId;
					MineFrameServices.getTalkDetail(data).then(function(result){
						if(result.status){
							$scope.talkItem=result.data;
							$scope.replyDefault();

							$scope.$broadcast('scroll.refreshComplete');
							refreshData("refresh", result.data.length);
						}else{
							$ionicPopup.alert({
								template: "<p >" + result.errorMessage + "</p>"
							});
						}
					});
				} else {

				}
			};
			
			$scope.getImageUrl = function(src){
				return assembleImageUrl(src)+'.thumbnail';
			};
			
			$scope.clickImg = function(index){
				var imgArray = [];
				_.each($scope.talkItem.images, function(content){
					imgArray.push(assembleImageUrl(content.path));
				});
				imgArray.unshift(index);
				pictrueViewer(imgArray);
			};
			$scope.dealPath = function(url){
				return assembleImageUrl(url)+'.thumbnail';
			};
		}
	])
});