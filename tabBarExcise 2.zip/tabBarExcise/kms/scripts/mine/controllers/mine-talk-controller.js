define(['angularAMD', 'common/services/footer-service', 'mine/services/mine-frame-services', 'common/directive/input-box', 'common/filters/common-filter', 'common/controllers/staff-selection-controller', 'common/directive/common-review'], function(angularAMD) {
	angularAMD.controller('mineTalkController', ['$scope', '$stateParams', '$ionicModal', '$location', '$rootScope', 'MineFrameServices', 'FooterServices', '$ionicScrollDelegate', '$timeout',
		function($scope, $stateParams, $ionicModal, $location, $rootScope, MineFrameServices, FooterServices, $ionicScrollDelegate, $timeout) {
			'use strict';
			FooterServices.hide();
			// 说说设置
			$scope.talkTypeSettings = {};
			$scope.talkListData = []; //说说列表数据
			// 说说列表类型 me or ta
			$scope.talkListKind = $stateParams.who;
			// 获取工号
			var workId = $stateParams.workId;
			$scope.type = "polymeric";
			$scope.talkTypeSettings.mineRelatedHide = true;
			if ($scope.talkListKind == 'me') {
				$scope.title = "我的说说";
				$scope.talkTypeSettings.deletable = true;
				//用来判断是否是自己
				$scope.talkTypeSettings.Myself = "mineFrame";
			} else if ($scope.talkListKind == 'ta') {
				$scope.title = "TA的说说";
				$scope.talkTypeSettings.deletable = false;
				$scope.talkTypeSettings.Myself = "taTalk";
			}
			$scope.talkTypeSettings.showReplyNo = true;
			// 请求接口时传的参数
			var dataFactor = {
				// 说说类型：me 或 ta
				talkListKind: $scope.talkListKind,
				startPage: 0, // 第几页
				pageSize: 5, // 一页数据的数量
				empNumber: workId // 工号，ta的说说时用到
			}

			function init() {
				$scope.noMoreItemsAvailable = true;
				$scope.isFirstIn = true;
				dataFactor.startPage = 0;
				getTalkDataFromServer();
			}
			//监听关闭弹出键盘
			var closeMyTalkDialog = GetByid("closeMyTalkDialog");

			function touchEnd(event) {
				$rootScope.$broadcast("closeHide", close);
			}
			closeMyTalkDialog.addEventListener("touchend", touchEnd, false);
			init();

			function cancelScrollInitFunction() {
				window.setTimeout(function() {
					$scope.$broadcast('scroll.refreshComplete');
				}, 100);
			}


			function getTalkDataFromServer(type) {
				MineFrameServices.getMineTalkListData(dataFactor).then(function(res) {
					// 接收到说说数据
					if (res.status == 1) {
						console.log(res.data);
						//是否可以进行下拉刷新
						$scope.talkListData = $scope.talkListData.concat(traverseData(res.data));
						$scope.noMoreItemsAvailable = dataFactor.startPage >= (res.totalPage - 1);
						refreshDataInfo(type, res.data.length);
					} else {
						$ionicPopup.alert({
							template: "<p >" + res.errorMessage + "</p>"
						});
					}

				});
			}
			//遍历数据

			function traverseData(datas) {
				return _.map(datas, function(data) {
					return {
						imgUrl: assembleImageUrl(data.headPath),
						name: data.createrName,
						id: data.createrId,
						publishTime: data.createDate,
						contentId: data.id,
						contentTitle: data.content,
						selectType: "microblog",
						images: getImageArr(data.images),
						commentNum: data.commentCount,
						goodNum: data.praiseCount,
						isPraise: data.isPraise,
						totalReplyCount: data.commentCount,
						replyContent: replyData(data.comments),
						uuid: data.uuid
					}
				})
			}
			//遍历回复数据
			function getImageArr(images) {
				var imgs = [];
				if (images) {
					_.each(images, function(image) {
						image.path = assembleImageUrl(image.path);
						imgs.push(image);
					});
				}
				return imgs;
			}

			function replyData(items) {
				return _.map(items, function(item) {
					return {
						replyPerson: item.createrName,
						replyPersonId: item.createrId,
						signId: item.id,
						berepliedPerson: item.receiverName,
						berepliedPersonId: item.receiverId,
						replyCont: item.content,
						createDate: item.createDate
					}

				})
			}

			$scope.mine = {}
			var data = MineFrameServices.getMineMessage();
			$scope.mine.imgUrl = data.imgUrl;
			$scope.mine.name = data.name;
			$scope.mine.id = data.id;

			$scope.back = function() {
				// 说说 - 返回上一页
				history.back(-1);
			};
			$scope.goMessageDetail = function(item) {

			};
			//  点击了写说说
			$scope.clickWriteTalk = function() {
					$location.path('/talk-write/' + $stateParams.who + '/' + $stateParams.workId);
					console.log("writeTalk");
				}
				// 下拉刷新
			$scope.onRefresh = function() {
					// 设置dataFactor，调用getTalkDataFromServer
					$scope.talkListData = [];
					dataFactor.startPage = 0;
					getTalkDataFromServer("refresh");

				}
				// 加载更多
			$scope.loadMore = function() {
				console.log("loadMore");
				if ($scope.noMoreItemsAvailable) {
					$scope.$broadcast('scroll.infiniteScrollComplete');
					return;
				}
				if ($scope.isFirstIn) {
					$scope.isFirstIn = false;
					$scope.$broadcast('scroll.infiniteScrollComplete');
					return;
				} else {
					$scope.isFirstIn = true;
					dataFactor.startPage++;
					getTalkDataFromServer("loadMore");
				}

				//$scope.$broadcast("scroll.infiniteScrollComplete");
			}

			function refreshDataInfo(type, length) {
				if (type == "refresh") {
					$scope.$broadcast('scroll.refreshComplete');
					if (length > 0) {
						$scope.refresherData = "已经为您更新" + length + "条数据";
						$(".refresher-data").show();
						$timeout(function() {
							$(".refresher-data").hide();
						}, 1500);
					}
				} else if (type == "loadMore") {
					$scope.$broadcast('scroll.infiniteScrollComplete');
					console.log("infinite")
					if (length > 0) {
						$scope.infiniteData = "已经为您加载" + length + "条数据";
						$(".infinite-data").show();
						$timeout(function() {
							$(".infinite-data").hide();
						}, 1500);
					}
				}
				NoData(length, 1);
			}
			$scope.scrollDragUp = function() {
					dragUp($ionicScrollDelegate, $scope);
				}
				//调用输入框
			$scope.showInputBox = function() {
				inputBox($scope);
				$scope.$broadcast("inputOnFocus");
			}
			$scope.showInputBoxImg = function() {
					inputBoxImg($scope);
					$scope.$broadcast("inputOnFocus");
				}
				//输入框提示语
			$scope.setHalohoder = function(mess) {
				$timeout(function() {
					$scope.$broadcast("inputBoxPlaceholder", mess);
				}, 50);
			};



			//转换表情
			$scope.changeData = function(data) {
				if (data != null) {
					return replace_html(data);
				}
			}
			$scope.IsEmpty = function(data) {
				if (data) {
					return true;
				} else {
					return false;
				}
			}
			$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
				scope: $scope,
				animation: 'slide-in-up'
			}).then(function(modal) {
				$scope.modal = modal;
			});
			/*删除*/
			var deleteContentId = "",
				deleteContentType = "";
			$scope.deleteData = function(data) {
				deleteContentId = data.contentId;
				deleteContentType = data.selectType;
				$scope.modalShow = 3;
				$scope.explain = "是否要删除该条数据？";
				$scope.modalYes = "是";
				$scope.modalNo = "否";
				$scope.modal.show();
			}
			$scope.isBatch = function(flag) {
				var items = {};
				if (flag) {
					items.targetId = deleteContentId;
					items.targetType = deleteContentType;
					MineFrameServices.deleteMineData(items).then(function(res) {
						if (res.status == 1) {
							console.log("删除成功");
						} else {
							console.log("删除失败");
						}
					});
					GetByid("list" + items.targetId).remove();
					$scope.modal.hide();
				} else {
					$scope.modal.hide();
				}
			};
			//跳转详情
			$scope.goMicroblogDetail = function(data) {
				$location.path('/talk-detail/' + data.contentId + "/" + data.id);
			}

			//对时间过滤
			$scope.getFilterTime = function(time) {
				return utilsTime(time);
			}

			$scope.clickImg = function(index, images, event) {
				var imgArray = [];
				imgArray.push(index);
				_.each(images, function(content) {
					imgArray.push(content.path);
				});
				console.log(imgArray);
				pictrueViewer(imgArray);
				event.stopPropagation();
			};


		}
	])

});