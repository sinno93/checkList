define(['angularAMD', 'common/services/footer-service', 'mine/services/mine-frame-services', 'common/filters/common-filter'], function(angularAMD) {
	angularAMD.controller('minePrivateMessageListController', ['$scope', '$location', '$rootScope', 'MineFrameServices', 'FooterServices', '$ionicScrollDelegate', '$timeout',
		function($scope, $location, $rootScope, MineFrameServices, FooterServices, $ionicScrollDelegate, $timeout) {
			'use strict';
			FooterServices.hide();
			var DEFAULT_PAGE_SIZE = 10;
			$scope.title = '我的私信';

			$scope.items = [];

			function assembleRequestParams() {
				return {
					'startPage': $scope.startPage,
					'pageSize': DEFAULT_PAGE_SIZE
				};
			}

			function init() {
				$scope.startPage = 0;
				$scope.noMoreItemsAvailable = true;
				MineFrameServices.getMyPrivateMessageList(assembleRequestParams()).then(function(response) {
					console.log(response);
					$scope.items = response.data;
					checkAvailableItems(response.totalSize);
					cancelScrollInitFunction();
					NoData($scope.items.length,1);
				});
			}
		
			init();

			function cancelScrollInitFunction() {
				$timeout(function() {
					$scope.$broadcast('scroll.refreshComplete');
				}, 100);
			}

			function checkAvailableItems(total) {
				$scope.noMoreItemsAvailable = $scope.items.length === total;
				if($scope.noMoreItemsAvailable){
					console.log($scope.noMoreItemsAvailable)
					$scope.isFirstIn = true;
				}
			}
			$scope.transCode = function(content) {
				return replace_html(content);
			};
			$scope.getName = function(item) {
				return item.relationName + item.relationId;
			};

			$scope.goDetailPrivateMessage = function(relationID) {
				$location.path('/private-message-detail/' + relationID);
			};
			$scope.goRelationDetail = function(relationID, event){
				$location.path();
				event.stopPropagation();
			};
			
			/**
			 * 检测上拉刷新的时候，真正的更新数据有多少
			 * @param {Object} newItems
			 * @param {Object} items
			 */
			function checkNewItemsCount(newItems, items) {
				var count = 0;
				var temp = items[0].senderDate;
				for (var i=0; i<newItems.length; i++){
					if (newItems[i].senderDate != temp) {
						if(i==0){
							items.unshift(newItems[i]);
						}else{
							items.splice(i,0,newItems[i]);
						}
						count++;
					}else{
						break;
					}
				}
				return count;
			}
			function refreshData(type, length) {
					if (type == "refresh") {
						if (length > 0) {
							$scope.refresherData = "已经为您更新" + length + "条数据";
							$(".refresher-data").show();
							$timeout(function() {
								$(".refresher-data").hide();
							}, 1500);
						}

					} else if (type == "loadMore") {
						if (length > 0) {
							$scope.infiniteData = "已经为您加载" + length + "条数据";
							$(".infinite-data").show();
							$timeout(function() {
								$(".infinite-data").hide();
							}, 1500);
						}
					}
					
				}
			
			$scope.onRefresh = function(){
				$scope.startPage = 0;
				MineFrameServices.getMyPrivateMessageList(assembleRequestParams()).then(function(response) {
					console.log(response);
					var newItems = response.data;
					var count = checkNewItemsCount(newItems, $scope.items);
					refreshData('refresh', count);
   					cancelScrollInitFunction();
				});
			};
			
			
			$scope.isFirstIn = true;

			$scope.loadMore = function() {
				if ($scope.noMoreItemsAvailable) {
					$scope.$broadcast('scroll.infiniteScrollComplete');
					return;
				}
				if ($scope.isFirstIn) {
					$scope.isFirstIn = false;
					$scope.$broadcast('scroll.infiniteScrollComplete');
					return;
				}
				$scope.startPage++;
				MineFrameServices.getMyPrivateMessageList(assembleRequestParams()).then(function(response) {
						var newItems = response.data;
						_.each(newItems, function(item) {
							$scope.items.push(item);
						});
						$scope.$broadcast('scroll.infiniteScrollComplete');

						checkAvailableItems(response.totalSize);
						refreshData('loadMore', newItems.length);
					});
			};
			
			$scope.dealPath = function(url){
				return assembleImageUrl(url);
			};

		}
	])

});