define(['angularAMD', 'common/services/footer-service', 'hot/services/hot-services', 'mine/services/mine-frame-services', 'common/controllers/staff-selection-controller', 'common/directive/hot-list-item', 'common/filters/common-filter'], function(angularAMD) {
	angularAMD.controller('mineCollectionController', ['$scope', '$ionicModal', '$location', '$rootScope', '$ionicPopup', 'FooterServices', '$ionicScrollDelegate', 'MineFrameServices', 'hotServices', '$timeout',
		function($scope, $ionicModal, $location, $rootScope, $ionicPopup, FooterServices, $ionicScrollDelegate, MineFrameServices, hotServices, $timeout) {
			'use strict';
			FooterServices.hide();
			$scope.title = "我的收藏";
			$scope.listLength = "";
			$scope.isCollection = true;
			$scope.listData = [];
			var cancelId = "",
				cancelType = "";
			$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
				scope: $scope,
				animation: 'slide-in-up'
			}).then(function(modal) {
				$scope.modal = modal;
			});

			function cancelScrollInitFunction() {
					window.setTimeout(function() {
						$scope.$broadcast('scroll.refreshComplete');
					}, 100);
				}
				//初始化
			init();

			function assembleItem() {
				return {
					'startPage': $scope.startPage,
					'pageSize': 8
				};
			}

			function init() {
					$scope.noMoreItemsAvailable = true;
					$scope.isFirstIn = true;
					$scope.startPage = 0;
					getData();
				}
				//请求数据

			function getData(type) {
					MineFrameServices.getMineFavorites(assembleItem()).then(function(res) {
						console.log(res.data);
						if (res.status == 1) {
							$scope.listData = $scope.listData.concat(traverseData(res.data));
							statusType($scope.listData);
							$scope.noMoreItemsAvailable = res.totalSize == $scope.listData.length;
							cancelScrollInitFunction();
							$scope.$broadcast('scroll.infiniteScrollComplete');
							$ionicScrollDelegate.resize();
							$scope.listLength = res.data.length;
							refreshData(type, $scope.listLength);
						} else {
							$ionicPopup.alert({
								template: "<p >" + res.errorMessage + "</p>"
							});
						}

					})
				}
				//上下拉刷新数据条数 

			function refreshData(type, length) {
					if (type == "refresh") {
						if (length > 0) {
							$scope.refresherData = "已经为您更新" + length + "条数据";
							$(".refresher-data").show();
							$timeout(function() {
								$(".refresher-data").hide();
							}, 700);
						}

					} else if (type == "loadMore") {
						if (length > 0) {
							$scope.infiniteData = "已经为您加载" + length + "条数据";
							$(".infinite-data").show();
							$timeout(function() {
								$(".infinite-data").hide();
							}, 700);
						}
					}
					NoData(length,1);
				}
				// 对数据遍历

			function traverseData(datas) {
				return _.map(datas, function(data) {
					return {
						cType: getType(data.contentType),
						type: data.contentType,
						date: data.createDate,
						contentId: data.contentId,
						creator: data.contentCreaterName,
						contentCreaterId: data.contentCreaterId,
						title: data.content,
						imageUrl: assembleImageUrl(data.imagePath),
						isCollect: "取消收藏"
					}
				})
			}

			function statusType(datas) {
				return _.map(datas, function(data) {
					translateType(data);
				})
			}

			function translateType(data) {
					switch (data.cType) {
						case "知识":
						case "知识地图":
							data.colorType = "type-blue";
							break;
						case "爱问":
							data.colorType = "type-green";
							break;
						case "博客":
							data.colorType = "type-brown";
							break;
						case "讨论":
							data.colorType = "type-green";
							break;
						case "社区":
							data.colorType = "type-blue";
							break;
						default:
							break;
					}
				}
				//取消收藏
			$scope.hotCollect = function(data) {
				cancelId = data.contentId;
				cancelType = data.type;
				$scope.modalShow = 3;
				$scope.explain = "是否取消收藏？";
				$scope.modalYes = "是";
				$scope.modalNo = "否";
				$scope.modal.show();
			}
			$scope.isBatch = function(flag) {
				if (flag) {
					GetByid("cancel" + cancelId).remove();
					console.log(cancelId);
					console.log(cancelType);
					var json = {
						"contentId": cancelId,
						"contentType": cancelType,
						"saveType": false
					};
					hotServices.getIsCollect(json).then(function(res) {
						if (res.status == 1) {
							console.log(1);
						} else {
							$ionicPopup.alert({
								template: "<p >" + res.errorMessage + "</p>"
							});
						}
					});
					$scope.modalShow = 0;
					$scope.modalName = "取消收藏成功";
					$timeout(function() {
						$scope.modal.hide();
					}, 700)
				} else {
					$scope.modal.hide();
				}
			};
			//跳转详情
			$scope.goDeatil = function(data) {
					console.log(data);
					if (data.type == "iask") {
						$location.path('/asksDtail/' + data.contentId);
					} else {
						$location.path('/hotDetail/' + data.contentId + "/" + data.type);
					}

				}
				// 下拉刷新
			$scope.onRefresh = function() {
					$scope.listData = [];
					$scope.startPage = 0;
					getData("refresh");
				}
				// 加载更多
			$scope.loadMore = function() {
				if ($scope.noMoreItemsAvailable) {
					$scope.$broadcast('scroll.infiniteScrollComplete');
					return;
				}
				if ($scope.isFirstIn) {
					$scope.isFirstIn = false;
					$scope.$broadcast('scroll.infiniteScrollComplete');
					return;
				} else {
					$scope.isFirstIn = true;
					$scope.startPage++;
					getData("loadMore");
				}
			}
							//下拉提示到底了
			$scope.scrollDragUp = function() {
				dragUp($ionicScrollDelegate, $scope);
			}

		}
	])

});