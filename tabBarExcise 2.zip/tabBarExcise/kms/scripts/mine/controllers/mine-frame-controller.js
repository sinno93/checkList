define(['angularAMD', 'global', 'common/services/footer-service', 'mine/services/mine-frame-services', 'common/directive/top-right-dialog', 'common/directive/input-box',
	'common/filters/common-filter', 'common/controllers/staff-selection-controller', 'hot/services/hot-services', 'asks/services/ask-services',
], function(angularAMD) {
	angularAMD.controller('mineFrameController', ['$scope', 'Global', '$ionicModal', '$location', '$rootScope', 'FooterServices', 'MineFrameServices', 'asksServices', '$ionicScrollDelegate', '$timeout', 'hotServices',
		function($scope, Global, $ionicModal, $location, $rootScope, FooterServices, MineFrameServices, asksServices, $ionicScrollDelegate, $timeout, hotServices) {
			'use strict';
			FooterServices.activeItemByIndex(3);
			$scope.title = "我";
			$scope.mine = {};
			$scope.talkTypeSettings = {};
			$scope.talkTypeSettings.collectPerson = "我";
			$scope.talkTypeSettings.deletable = true;
			$scope.talkTypeSettings.hideShow = false;
			$scope.talkTypeSettings.mineRelatedHide = true;
			$scope.talkTypeSettings.showReplyNo = true;
			$scope.type = "polymeric";
			var myId, myName, myHeader;
			getMineData();
			//初始化数据
			function init() {
				$scope.noMoreItemsAvailable = true;
				$scope.isFirstIn = true;
				$scope.startPage = 0;
				checkHasNewMsg();
				getMinFrameData();
			}
			init();
			//用来判断是否是自己
			$scope.talkTypeSettings.Myself = "mineFrame";
			$scope.backLogin = function() {
				$location.path("/hot");
			};


			//监听关闭右上角弹出层
			var closeDialog = GetByid("closeDialog");

			function touchEnd(event) {
				$rootScope.$broadcast("close", close);
			}
			closeDialog.addEventListener("touchend", touchEnd, false);



			function getMineData() {
				MineFrameServices.getMineMessage().then(function(response) {
					console.log(response);
					if (response.status == 1) {
						console.log(response.data);
						var data = response.data;
						$scope.mine.imgUrl = assembleImageUrl(data.headPath);
						$scope.mine.name = data.name;
						$scope.mine.id = data.empNumber;
						$scope.mine.apartment = data.deptName;
						$scope.mine.positions = data.position;
						$scope.mine.knowledge = data.knowledgeCount;
						$scope.mine.focus = data.attentionCount;
						$scope.mine.fance = data.fansCount;
						$scope.mine.saysay = data.microBlogCount;
						$scope.mine.collection = data.favoriteCount;
						$scope.mine.aboutMe = data.relationCount;
						$scope.mine.question = data.questionCount;
						$scope.mine.discuss = data.discussionCount;
						setMyId($scope.mine.id);
						setMyName($scope.mine.name);
						if (myHeader == "" || myHeader == null) {
							myHeader = data.headPath;
						}
						if (myName == "" || myName == null) {
							myName = data.name
						}
						if (myId == "" || myId == null) {
							myId = data.empNumber
						}
					}
				});
			}
			$scope.toMessageBox = function() {
				$location.path('/messageBox');
			};
			//点击了我的关注 进入我的关注列表页面
			$scope.clickMyAttention = function() {

				console.log("click my attention");
				$location.path("/mine/mine-attention-fans/attention");
			};
			//点击了我的粉丝页面，进入了我的粉丝页面
			$scope.clickMyFans = function() {
				console.log("click my fans");
				$location.path("/mine/mine-attention-fans/fans");
			}
			$scope.clickSaysay = function() {
				// 跳至说说列表,我的话中间有个me 后面带工号
				$location.path("/talk-list/me/232")
				console.log("clickSaysay!!!");
			}
			$scope.clickCollection = function() {
				$location.path("/mine-collection");
			}
			$scope.clickAboutMe = function(mine) {
				$location.path('/mineRelated/' + mine.id + '/' + mine.name);
			}
			$scope.clickQuestion = function() {
				$location.path('/myQuestion');
			}
			$scope.clickDiscuss = function() {
				$location.path("/mineDiscuss");
			}

			function cancelScrollInitFunction() {
				window.setTimeout(function() {
					$scope.$broadcast('scroll.refreshComplete');
				}, 100);
			}


			function assembleItem() {
				return {
					'startPage': $scope.startPage,
					'pageSize': 4
				};
			}
			$scope.setHalohoder = function(mess) {
				$timeout(function() {
					$scope.$broadcast("inputBoxPlaceholder", mess);
				}, 50);
			};


			function checkHasNewMsg() {
				MineFrameServices.hasNewMessage().then(function(response) {
					$scope.msg = response.data;
				});
			}
			/*列表*/
			$scope.listData = [];
			//获取数据
			function getMinFrameData(type) {
				MineFrameServices.getMineFrameData(assembleItem()).then(function(res) {
					if (res.status == 1) {
						getMineData();
						console.log(res.data);
						$scope.listData = $scope.listData.concat(traverseData(res.data));
						$scope.noMoreItemsAvailable = res.totalSize == $scope.listData.length;
						cancelScrollInitFunction();
						$scope.$broadcast('scroll.infiniteScrollComplete');
						refreshData(type, res.data.length);
//						changeAskType($scope.listData);
					} else {
						$ionicPopup.alert({
							template: "<p >" + res.errorMessage + "</p>"
						});
					}
				});
			}
			//对数据遍历

			function traverseData(datas) {
				return _.map(datas, function(data) {
					return {
						imgUrl: assembleImageUrl(myHeader),
						name: myName,
						id: myId,
						publishTime: data.createDate,
						contentId: data.targetId,
						contentImgUrl: assembleImageUrl(data.targetImagePath),
						images: data.images,
						contentTitle: data.targetTitle,
						selectType: data.targetType,
						action: data.action,
						goodNum: data.praiseCount,
						commentNum: data.commentCount,
						isPraise: data.isPraise,
						totalReplyCount: data.commentCount,
						replyContent: getComments(data.comments),
						isSolve: data.isSolve,
						num: data.replyCount,
						questionGold: data.rewardScore,
					}
				})
			}

			//			function changeAskType(datas) {
			//				for (var i = 0; i < datas.length; i++) {
			//					if (datas[i].isSolve == '1') {
			//						$scope.solve = "已解决";
			//						$scope.addAsk = "我来补充";
			//						$scope.askColor = "ask-green";
			//					} else {
			//						$scope.solve = "未解决";
			//						$scope.addAsk = "";
			//						$scope.askColor = "ask-blue";
			//					}
			//				}
			//
			//			}
			$scope.isSlove = function(isSlove) {
				if (isSlove == 1) {
					return '已解决';
				} else {
					return '未解决';
				}
			};
			$scope.answerType = function(isSolve) {
				if (isSolve == 1) {
					return '我来补充';

				} else {
					return '我来回答';
				}
			};
			//对评论数据遍历

			function getComments(items) {
				return _.map(items, function(item) {
					return {
						replyPerson: item.createrName,
						replyPersonId: item.createrId,
						signId: item.id,
						berepliedPerson: item.receiverName,
						berepliedPersonId: item.receiverId,
						replyCont: item.content,
						createDate: item.createDate
					}
				})
			}
			$scope.IsEmpty = function(data) {
					if (data) {
						return true;
					} else {
						return false;
					}
				}
				/*删除*/
			$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
				scope: $scope,
				animation: 'slide-in-up'
			}).then(function(modal) {
				$scope.modal = modal;
			});
			var isKmsCollect = "",
				deleteContentId = "",
				deleteContentType = "";
			/*删除*/
			$scope.deleteData = function(data) {
				$scope.modalShow = 3;
				isKmsCollect = data.action;
				deleteContentId = data.contentId;
				deleteContentType = data.selectType;
				console.log(isKmsCollect);
				if (data.action == 'collect') {
					$scope.explain = "是否取消收藏？";
				} else {
					$scope.explain = "是否要删除该条数据？";
				}
				$scope.modalYes = "是";
				$scope.modalNo = "否";
				$scope.modal.show();
			}
			$scope.isBatch = function(flag) {
				var items = {};
				if (flag) {
					if (isKmsCollect == 'collect') {
						items.contentId = deleteContentId
						items.contentType = deleteContentType;
						items.saveType = false;
						hotServices.getIsCollect(items).then(function(res) {
							if (res.status == 1) {
								console.log("取消成功");
							} else {
								console.log("取消失败");
							}
						});
						GetByid("list" + items.contentId).remove();
					} else {
						items.targetId = deleteContentId;
						items.targetType = deleteContentType;
						MineFrameServices.deleteMineData(items).then(function(res) {
							if (res.status == 1) {
								console.log("删除成功");
							} else {
								console.log("删除失败");
							}
						});
						GetByid("list" + items.targetId).remove();
					}
					$scope.modal.hide();
				} else {
					$scope.modal.hide();
				}
			};
			//对时间过滤
			$scope.getFilterTime = function(time) {
					return utilsTime(time);
				}
				/*跳转详情*/
			$scope.goAskDetail = function(data) {
				console.log(data.contentId);
				$location.path('/asksDetail/' + data.contentId);
			};
			$scope.goDeatil = function(data) {
				console.log(data);
				$location.path('/hotDetail/' + data.contentId + "/" + data.selectType);
			}
			$scope.goMicroblogDetail = function(data) {
					$location.path('/talk-detail/' + data.contentId + "/" + data.id);
				}
				/*我来补充*/
			$scope.toAnswerQuestion = function(data) {
					console.log(data.contentId);
					$location.path('/create-answer/' + data.contentId);
				}
				//转换表情
			$scope.changeData = function(data) {
					if (data != null) {
						return replace_html(data);
					}
				}
				// 移除modalPay
			$scope.$on('$destroy', function() {
				$scope.modal.remove();
			});
			//过滤表情
			$scope.getToRefer = function(data) {
					return replace_html(data);
				}
				//处理知识不能删除
			$scope.hideKnowledge = function(type) {
				if (type == 'knowledge') {
					return false;
				} else {
					return true;
				}
			}

			//上下拉刷新数据条数 

			function refreshData(type, length) {
				if (type == "refresh") {
					if (length > 0) {
						$scope.refresherData = "已经为您更新" + length + "条数据";
						$(".refresher-data").show();
						$timeout(function() {
							$(".refresher-data").hide();
						}, 700);
					}

				} else if (type == "loadMore") {
					if (length > 0) {
						$scope.infiniteData = "已经为您加载" + length + "条数据";
						$(".infinite-data").show();
						$timeout(function() {
							$(".infinite-data").hide();
						}, 700);
					}
				}
				mineNoData(length);
			}
			// 下拉刷新
			$scope.onRefresh = function() {
					$scope.listData = [];
					$scope.startPage = 0;
					getMinFrameData("refresh");
				}
				// 加载更多
			$scope.loadMore = function() {
					if ($scope.noMoreItemsAvailable) {
						$scope.$broadcast('scroll.infiniteScrollComplete');
						return;
					}
					if ($scope.isFirstIn) {
						$scope.isFirstIn = false;
						$scope.$broadcast('scroll.infiniteScrollComplete');
						return;
					} else {
						$scope.isFirstIn = true;
						$scope.startPage++;
						getMinFrameData("loadMore");
					}

				}
				//$scope.listData = MineFrameServices.getMineListData();

			//调用输入框
			$scope.showInputBox = function() {
				inputBox($scope);
				//				$scope.sign.showKeyboardIf = true;
				$scope.$broadcast("inputOnFocus");
				FooterServices.hide();
			}
			$scope.showInputBoxImg = function() {
				inputBoxImg($scope);
				//				$scope.sign.showKeyboardIf = true;
				$scope.$broadcast("inputOnFocus");
				FooterServices.hide();
			}

			//下拉提示到底了
			$scope.scrollDragUp = function() {
				dragUp($ionicScrollDelegate, $scope);
			}

			$scope.dealPath = function(url) {
				return assembleImageUrl(url) + '.thumbnail';
			};

		}
	])
});