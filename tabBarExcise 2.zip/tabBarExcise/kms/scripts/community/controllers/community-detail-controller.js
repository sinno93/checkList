define(['angularAMD', 'common/services/footer-service', 'community/services/community-detail-services', 'community/directive/community-detail-directives', 'common/controllers/staff-selection-controller', 'common/directive/input-box', 'common/filters/common-filter'], function(angularAMD) {
	angularAMD.controller('communityDetailController', ['$scope', '$timeout', '$ionicModal', '$ionicPopup', '$location', '$rootScope', 'FooterServices', 'CommunityDetailServices', '$http', '$stateParams', '$ionicScrollDelegate',
		function($scope, $timeout, $ionicModal, $ionicPopup, $location, $rootScope, FooterServices, CommunityDetailServices, $http, $stateParams, $ionicScrollDelegate) {
			'use strict';
			/*模拟数据*/
			var parameter={};
			parameter.communityId=$stateParams.communityId;//社区详情id
			parameter.userId=getMyId() || "002628";
			/*分页控制*/
			var listPageSize=5;
			var listStartPage=0;

			/*定义对话框*/
			$scope.showDialogbox1=function(text, callback){/*confirm*/
				$scope.explain = text;
				$scope.modalYes = "确定";
				$scope.modalNo = "取消";
				$scope.modalShow = 3;
				$scope.isBatch = function(flag) {
					if(flag){
						callback();
					}
					$scope.modal.hide();
				};
				$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
					scope: $scope,
					animation: 'slide-in-up'
				}).then(function(modal) {
					$scope.modal = modal;
					$scope.modal.show();
				});
			};
			var showDialogbox2=function(text){/*提示*/
				$scope.modalShow = 10;
				$scope.collectContent = text;
				$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
					scope: $scope,
					animation: 'slide-in-up'
				}).then(function(modal) {
					$scope.modal = modal;
					$scope.modal.show();
					$timeout(function(){
						$scope.modal.hide();
					}, 1000);
				});
			}
			/*刷新数据提示*/
			function refreshData(type, length) {
				if (type == "refresh") {
					if (length > 0) {
						$scope.refresherData = "已经为您更新" + length + "条数据";
						$(".refresher-data").show();
						$timeout(function() {
							$(".refresher-data").hide();
						}, 1000);
					}

				} else if (type == "loadMore") {
					if (length > 0) {
						$scope.infiniteData = "已经为您加载" + length + "条数据";
						$(".infinite-data").show();
						$timeout(function() {
							$(".infinite-data").hide();
						}, 1000);
					}
				}
			}
			var isShowNomore=false;
			$scope.scrollDragUp=function(){
				var currentTop = $ionicScrollDelegate.getScrollPosition().top;
				var maxTop = $ionicScrollDelegate.getMaxTop();
				if (currentTop - maxTop > 50 && maxTop > 0) {
					if (!isShowNomore && $scope.scrollEnded) {
						isShowNomore = true;
						$scope.infiniteData = "已经到底啦!";
						$(".infinite-data").show();
						setTimeout(function() {
							$(".infinite-data").hide();
							isShowNomore = false;
						}, 700);
					}

				}
			}
			$scope.getImageUrl = function(src){
				return assembleImageUrl(src)+'.thumbnail';
			};
			$scope.showPic = function(src, item, event){
				var imgArray = [];
				_.each(item.contentSequence, function(content){
					if(content.type == 'image'){
						imgArray.push(assembleImageUrl(content.src));
					}
				});
				var index = 0;
				for (var i=0; i<imgArray.length; i++){
					if(imgArray[i] == assembleImageUrl(src)){
						index = i;
						break;
					}
				}
				imgArray.unshift(index);
				pictrueViewer(imgArray);
				event.stopPropagation();
			}
			/*页面表情转码*/
			$scope.emoijToText=function(html){
				return replace_html(html)
			};
			/*转到他的主页*/
			$scope.goHome=function(userId, event){
				if(userId==getMyId()){
					$location.path('/mine');
				}else{
					$location.path('/ta/'+userId);
				}
				event.stopPropagation();
			};

			/*初始化函数*/
			var init=function(){
				FooterServices.hide();
				$scope.title="社区详情";
				$scope.scrollEnded=true;
				$scope.praisedList=[];
				$scope.userId=parameter.userId;
				var data={};
				data.communityId=parameter.communityId;
				CommunityDetailServices.getCommunityDetail(data).then(function(result){
					if(result.status){
						$scope.communityDetail=result.data;
						$(".content-body").removeClass('hide-on-in');
						
						if($scope.communityDetail.userRole=='visitor'){
							return;
						}

						var data={};
						data.communityId=parameter.communityId;
						data.pageSize=listPageSize;
						data.startPage=listStartPage;
						CommunityDetailServices.getCommunityPostList(data).then(function(result){
							if(result.status){
								$scope.communityPostList=result.data;
								listStartPage++;
								if(result.currentPage>=(result.totalPage-1)){
									$scope.scrollEnded=true;
								}else{
									$scope.scrollEnded=false;
								}

							}else{
								$ionicPopup.alert({
									template: "<p >" + result.errorMessage + "</p>"
								});
							}
						});
					}else{
						$ionicPopup.alert({
							template: "<p >" + result.errorMessage + "</p>"
						});
					}
				});
			}
			init();

			/*返回上一页面*/
			$scope.back=function(){
				history.go(-1);
			}
			/*加入/退出社区*/
			$scope.attend=function(){
				var isAttended=($scope.communityDetail.userRole=='member');
				var data={};
				data.communityId=parameter.communityId;
				data.isAdd=!isAttended;
				CommunityDetailServices.setCommunityAttention(data).then(function(result){
					listStartPage=0;
					if(result.status){
						if(result.status==1){
							$scope.communityDetail.userRole=!isAttended?'member':'visitor';
							showDialogbox2(!isAttended?"加入社区成功":"退出社区成功");
							if(!isAttended){
								var data={};
								data.communityId=parameter.communityId;
								data.pageSize=listPageSize;
								data.startPage=listStartPage;
								CommunityDetailServices.getCommunityPostList(data).then(function(result){
									if(result.status){
										$scope.communityPostList=result.data;
										listStartPage++;
										if(result.currentPage>=(result.totalPage-1)){
											$scope.scrollEnded=true;
										}else{
											$scope.scrollEnded=false;
										}
									}else{
										$ionicPopup.alert({
											template: "<p >" + result.errorMessage + "</p>"
										});
									}
								});
							}else{
								$scope.communityPostList={};
							}
						}else{
							$scope.communityDetail.userRole=!isAttended?'applicant':'visitor';
							showDialogbox2("等待审核...");
						}
					}else{
						$ionicPopup.alert({
							template: "<p >" + result.errorMessage + "</p>"
						});
					}
				});
			};
			/*评论回复内容*/
			$scope.replyPost=function(postId){
				$location.path('/hotDetail/'+postId+'/theme');
			};
			/*点赞回复内容*/
			$scope.praisePost=function(index){
				var praised=$scope.praisedList[index];
				var data={};
				CommunityDetailServices.praiseCommunityPost(data).then(function(result){
					if(result.status){
						if(praised){
							$scope.praisedList[index]=false;
							$scope.communityPostList[index].PraiseNumber--;
						}else{
							$scope.praisedList[index]=true;
							$scope.communityPostList[index].PraiseNumber++;
						}
					}else{
						$ionicPopup.alert({
							template: "<p >" + result.errorMessage + "</p>"
						});
					}
				});
			};
			/*删除回复内容*/
			$scope.deletePost=function(discussionId){
				var postId=discussionId;
				var data={};
				data.discussionId=postId;
				data.operationRole=$scope.communityDetail.userRole;
				CommunityDetailServices.deleteCommunityPost(data).then(function(result){
					if(result.status){
						$($scope.communityPostList).each(function(index, el) {
							if(el.id==postId){
								$scope.communityPostList.splice(index, 1);
								$scope.praisedList.splice(index, 1);

								return;
							}
						});
					}else{
						$ionicPopup.alert({
							template: "<p >" + result.errorMessage + "</p>"
						});
					}
				});
			};

			/*刷新数据*/
			$scope.doRefresh = function(atTop) {
				if(atTop){
					listStartPage=0;
					$scope.communityPostList={};

					var data={};
					data.communityId=parameter.communityId;
					data.pageSize=listPageSize;
					data.startPage=listStartPage;
					CommunityDetailServices.getCommunityPostList(data).then(function(result){
						if(result.status){
							$scope.communityPostList=result.data;
							$scope.$broadcast('scroll.refreshComplete');
							refreshData("refresh", result.data.length);
							listStartPage++;
							if(result.currentPage>=(result.totalPage-1)){
								$scope.scrollEnded=true;
							}else{
								$scope.scrollEnded=false;
							}
						}else{
							$ionicPopup.alert({
								template: "<p >" + result.errorMessage + "</p>"
							});
						}
					});
				}else{
					var data={};
					data.communityId=parameter.communityId;
					data.pageSize=listPageSize;
					data.startPage=listStartPage;
					CommunityDetailServices.getCommunityPostList(data).then(function(result){
						if(result.status){
							var newPostlist=result.data;
							$scope.communityPostList=$scope.communityPostList.concat(newPostlist);

							$scope.$broadcast('scroll.infiniteScrollComplete');
							if(result.currentPage>1){
								refreshData("loadMore", result.data.length);
							}
							listStartPage++;
							if(result.currentPage>=(result.totalPage-1)){
								$scope.scrollEnded=true;
							}else{
								$scope.scrollEnded=false;
							}
						}else{
							$ionicPopup.alert({
								template: "<p >" + result.errorMessage + "</p>"
							});
						}
					});
				}
			};
			/*创建主题*/
			$scope.create=function(postId){
				$location.path('/createTheme/'+parameter.communityId);
			};
			
			$scope.dealPath = function(url){
				return assembleImageUrl(url);
			};
		}
	]);
});