define(['angularAMD','jquery','angular-resource','ionic',
'../components/underscore/underscore',
//'../../CordovaPublicJS/cordova',
'utils','global',
'common/directive/footer',
'common/services/footer-service',
'common/directive/loading',
'common/services/loading-interceptor',
'common/services/global-interceptor-handler',
'common/services/http-interceptor',


],
function (angularAMD) {
  'use strict';
  return angularAMD;
});


