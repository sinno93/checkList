define(['angularAMD', 'global', 'common/services/footer-service', 'hot/services/hot-services', 'common/services/common-group-service',
	'common/controllers/staff-selection-controller', 'mine/services/mine-frame-services', 'common/directive/hot-list-item', 'common/filters/common-filter'
], function(angularAMD) {
	angularAMD.controller('hotFrameController', ['$scope', '$ionicModal', '$location', '$rootScope', '$timeout', '$ionicPopup', '$ionicSlideBoxDelegate', 'Global', 'FooterServices',
		'$ionicScrollDelegate', 'hotServices', 'commonGroupServices','MineFrameServices',
		function($scope, $ionicModal, $location, $rootScope, $timeout, $ionicPopup, $ionicSlideBoxDelegate, Global, FooterServices, $ionicScrollDelegate, hotServices, commonGroupServices , MineFrameServices) {
			'use strict';
			FooterServices.activeItemByIndex(0);
			$scope.title = "热门";
			$scope.imgUrl = [];
			$scope.listData = [];
			$scope.contentType = "";
			$scope.show = false;
			//			$scope.screenWidth = document.documentElement.clientWidth + 'px';
			//			console.log($scope.screenWidth);
			//			$(".slider-slides").css("width",$scope.screenWidth);
			//console.log($(".slider-slides"));
			//获取tab数组
			$scope.tabGroup = commonGroupServices.getHotTabGroup();
			$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
				scope: $scope,
				animation: 'slide-in-up'
			}).then(function(modal) {
				$scope.modal = modal;
			});
			$scope.backLogin = function() {
				$scope.modalShow = 3;
				$scope.explain = "是否退出KMS模块？";
				$scope.modalYes = "是";
				$scope.modalNo = "否";
				$scope.modal.show();
			};
			$scope.isBatch = function(flag) {
				if (flag) {
					//退出到门户
                                                 ExpressPlugin.backToWidget();
				} else {
					$scope.modal.hide();
				}
			};
			$scope.toMessageBox = function() {
				$location.path('/messageBox');
			};

			function cancelScrollInitFunction() {
				window.setTimeout(function() {
					$scope.$broadcast('scroll.refreshComplete');
				}, 100);
			}

			init();

			function init() {
				$scope.noMoreItemsAvailable = true;
				$scope.isFirstIn = true;
				$scope.startPage = 0;
				$scope.contentType = "";
				initTabGroup();
				getData();
				getAdsBanner();
				checkHasNewMsg();
			}
			function checkHasNewMsg() {
				MineFrameServices.hasNewMessage().then(function(response) {
					$scope.msg = response.data;
				});
			}
			//获取banner图
			function getAdsBanner() {
				//				$scope.show = true;
				//				$scope.imgUrl = hotServices.getBanner();
				//				console.log($scope.imgUrl);
				//				$timeout(function() {
				//					$scope.imgUrl = $scope.imgUrl.splice(0, 2);
				//				}, 100)
				//				console.log($scope.imgUrl);
				hotServices.getBanner().then(function(res) {
					if (res.status == 1) {
						$scope.show = true;
						console.log(res.data);
						$scope.imgUrl = traverseBanner(res.data);
					}
				});
			}

			function traverseBanner(banners) {
				return _.map(banners, function(banner) {
					return {
						imageUrl: assembleImageUrl(banner.imagePath),
						imageContent: banner.descript,
						type: banner.moduleId,
						contentId: banner.targetId
					}
				})

			}
			//获取数据
			function getData(type) {
				var hotData = {};
				hotData.startPage = $scope.startPage;
				hotData.pageSize = 8;
                                                 //getData
				hotData.contentType = $scope.contentType;
				console.log(hotData);
				hotServices.getListData(hotData).then(function(res) {
					if (res.status == 1) {
						console.log(res);
						if (res.data != null) {
							$scope.listData = $scope.listData.concat(traverseData(res.data));
							$scope.noMoreItemsAvailable = res.totalSize == $scope.listData.length;
							$scope.noData = res.totalSize;
							cancelScrollInitFunction();
							$scope.$broadcast('scroll.infiniteScrollComplete');
							refreshData(type, res.data.length);
						}
					} else {
						$ionicPopup.alert({
							template: "<p >" + res.errorMessage + "</p>"
						});
					}

				});
			}
			//上下拉刷新数据条数 

			function refreshData(type, length) {
				if (type == "refresh") {
					if (length > 0) {
						$scope.refresherData = "已经为您更新" + length + "条数据";
						$(".refresher-data").show();
						$timeout(function() {
							$(".refresher-data").hide();
						}, 1000);
					}

				} else if (type == "loadMore") {
					if (length > 0) {
						$scope.infiniteData = "已经为您加载" + length + "条数据";
						$(".infinite-data").show();
						$timeout(function() {
							$(".infinite-data").hide();
						}, 1000);
					}
				}
				NoData(length, 1);
			}
			// 对数据遍历

			function traverseData(datas) {
				return _.map(datas, function(data) {
					return {
						commentCount: data.commentCount,
						contentId: data.contentId,
						type: data.contentType,
						creator: data.createrName,
						createrId: data.createrId,
						date: data.createDate,
						isSave: data.isCollection,
						title: data.title,
						imageUrl: assembleImageUrl(data.imagePath),
						isCollect: isCollect(data.isCollection)
					}
				})
			}
			//banner图片轮播
			$scope.slideChanged = function(index) {
				$scope.slideIndex = index;
			};
			//图片跳转
			$scope.goHotDetail = function(item) {
				console.log(item);
				$location.path('/hotDetail/' + item.contentId + "/" + item.type);
			}
			$scope.goHotDetailText = function(item, event) {
				console.log("点击我");
				$location.path('/hotDetail/' + item.contentId + "/" + item.type);
				event.stopPropagation();
			}

			//tab数据切换
			$scope.activeTab = function(tabName) {
				$scope.listData = [];
				$scope.noMoreItemsAvailable = true;
				$scope.isFirstIn = true;
				cleanAllActiveStatus();
				var tab = getTabByName(tabName);
				console.log(tab);
				$scope.contentType = tab.type;
				$scope.startPage = 0;
				if ($scope.contentType) {
					$scope.show = false;
				} else {
					$scope.show = true;
				}
				getData();
				tab.isActive = true;
				$ionicScrollDelegate.resize();
			};

			function cleanAllActiveStatus() {
				_.each($scope.tabGroup, function(tab) {
					tab.isActive = false;
				});
			}
			//得到标签的名字

			function getTabByName(tabName) {
				return _.find($scope.tabGroup, function(tab) {
					return tab.name === tabName;
				});
			}
			//设置当前tab颜色
			function initTabGroup() {
				console.log($scope.tabGroup[0]);
				$scope.tabGroup[0].isActive = true;
				setCurName($scope.tabGroup[0].name);
			}
			// 下拉刷新
			$scope.onRefresh = function() {
					$scope.listData = [];
					$scope.startPage = 0;
					getData("refresh");
				}
				// 加载更多
			$scope.loadMore = function() {
				if ($scope.noMoreItemsAvailable) {
					$scope.$broadcast('scroll.infiniteScrollComplete');
					return;
				}
				if ($scope.isFirstIn) {
					$scope.isFirstIn = false;
					$scope.$broadcast('scroll.infiniteScrollComplete');
					return;
				} else {
					$scope.isFirstIn = true;
					$scope.startPage++;
					getData("loadMore");
				}
			}

			//下拉提示到底了
			$scope.scrollDragUp = function() {
				dragUp($ionicScrollDelegate, $scope);
			}

		}
	])

});