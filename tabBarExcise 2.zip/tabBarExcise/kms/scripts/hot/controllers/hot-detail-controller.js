define(['angularAMD', 'common/services/footer-service', 'hot/services/hot-detail-services', 'hot/directive/hot-detail-directives', 'common/controllers/staff-selection-controller', 'common/directive/input-box', 'common/filters/common-filter'], function(angularAMD) {
	angularAMD.controller('hotDetailController', ['$scope', '$ionicModal', '$ionicPopup', '$location', '$rootScope', '$stateParams', 'FooterServices', '$ionicScrollDelegate', 'HotDetailServices', '$timeout',
		function($scope, $ionicModal, $ionicPopup, $location, $rootScope, $stateParams, FooterServices, $ionicScrollDelegate, HotDetailServices, $timeout) {
			'use strict';
			/*传入参数*/
			var parameter = {};
			parameter.userId = getMyId() || "002628"; //用户Id
			parameter.userHeadPath = ""; //用户头像
			parameter.contentType = $stateParams.type; //内容类型
			parameter.contentId = $stateParams.contentId; //内容Id
			/*分页控制*/
			var listPageSize = 5;
			var listStartPage = 0;
			var listReplyDefaultSize = 2;
			var listReplyPageSize = 5;
			var listReplyStartPage = 0;
			/*评论数据*/
			var commentData = {};
			commentData.type = '';
			commentData.setTooltip = function(t) {
				$scope.$broadcast("inputBoxPlaceholder", t);
			};
			commentData.id0 = '';
			commentData.id1 = '';
			commentData.id2 = '';
			commentData.commenterId0 = '';
			commentData.commenterId1 = '';
			commentData.commenterId2 = '';
			commentData.commenterName0 = '';
			commentData.commenterName1 = '';
			commentData.commenterName2 = '';
			var autofocus = 0;


			/*定义对话框*/
			$scope.showDialogbox1 = function(text, callback) { /*confirm*/
				$scope.explain = text;
				$scope.modalYes = "确定";
				$scope.modalNo = "取消";
				$scope.modalShow = 3;
				$scope.isBatch = function(flag) {
					if (flag) {
						callback();
					}
					$scope.modal.hide();
				};
				$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
					scope: $scope,
					animation: 'slide-in-up'
				}).then(function(modal) {
					$scope.modal = modal;
					$scope.modal.show();
				});
			};
			var showDialogbox2 = function(text) { /*提示*/
				$scope.modalShow = 10;
				$scope.collectContent = text;
				$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
					scope: $scope,
					animation: 'slide-in-up'
				}).then(function(modal) {
					$scope.modal = modal;
					$scope.modal.show();
					$timeout(function() {
						$scope.modal.hide();
					}, 1000);
				});
			};
			/*刷新数据提示*/
			function refreshData(type, length) {
				if (type == "refresh") {
					if (length > 0) {
						$scope.refresherData = "已经为您更新" + length + "条数据";
						$(".refresher-data").show();
						$timeout(function() {
							$(".refresher-data").hide();
						}, 1000);
					}

				} else if (type == "loadMore") {
					if (length > 0) {
						$scope.infiniteData = "已经为您加载" + length + "条数据";
						$(".infinite-data").show();
						$timeout(function() {
							$(".infinite-data").hide();
						}, 1000);
					}
				}
			};
			var isShowNomore=false;
			$scope.scrollDragUp=function(){
				var currentTop = $ionicScrollDelegate.getScrollPosition().top;
				var maxTop = $ionicScrollDelegate.getMaxTop();
				if (currentTop - maxTop > 50 && maxTop > 0) {
					if (!isShowNomore && $scope.scrollEnded) {
						isShowNomore = true;
						$scope.infiniteData = "已经到底啦!";
						$(".infinite-data").addClass('ended').show();
						setTimeout(function() {
							$(".infinite-data").removeClass('ended').hide();
							isShowNomore = false;
						}, 700);
					}

				}
			}
			/*页面表情转码*/
			$scope.emoijToText = function(html) {
				return replace_html(html)
			};
			/*转到他的主页*/
			$scope.goHome = function(userId) {
				if (userId == getMyId()) {
					$location.path('/mine');
				} else {
					$location.path('/ta/' + userId);
				}
			};

			/*初始化函数*/
			var init = function() {
				FooterServices.hide();
				$scope.type;
				switch (parameter.contentType) {
					case "知识":
					case "knowledge":
						$scope.title = "知识详情";
						$scope.type = 0;
						break;
					case "主题":
					case "theme":
						$scope.title = "讨论详情";
						$scope.type = 1;
						break;
					case "博客":
					case "blog":
						$scope.title = "博客详情";
						$scope.type = 2;
						break;
					default:
						break;
				};
				inputBoxAsk2($scope);
				$scope.sign.showKeyboardIf = false;
				if(parameter.contentType=='theme'){
					$scope.sign.ifperson=false;
					setInterval(function(){
						$(".share-row").hide();
					}, 500);
				}
				$scope.scrollEnded = true;
				$scope.listReplySize = listReplyDefaultSize;
				$timeout(function() {
					autofocus = 1;
				}, 3000);
				var setShareFavi = function() {
					$scope.data = {};
					$scope.data.type = parameter.contentType;
					$scope.data.contentId = parameter.contentId;
					$scope.data.contentType = parameter.contentType;
					$scope.sign.shareType = 1;
				}
				setShareFavi();

				var data = {};
				data.contentType = parameter.contentType;
				data.contentId = parameter.contentId;
				HotDetailServices.getHotDetailContent(data).then(function(result) {
					if (result.status) {
						$scope.hotDetailContent = result.data;
						$scope.sign.saveType = result.data.isCollection;
						$scope.replyDefault();

						$(".content-body").removeClass('hide-on-in');
					} else {
						$ionicPopup.alert({
							template: "<p >" + result.errorMessage + "</p>"
						});
					}
				});
				var data = {};
				data.type = parameter.contentType;
				data.param = {};
				data.param.contentId = parameter.contentId;
				data.param.defaultReplySize = listReplyDefaultSize;
				data.param.pageSize = listPageSize;
				data.param.startPage = listStartPage;
				HotDetailServices.getHotDetailPostlist(data).then(function(result) {
					if (result.status) {
						$scope.hotDetailPostlist = result.data;
						listStartPage++;

						if (result.currentPage >= (result.totalPage - 1)) {
							$scope.scrollEnded = true;
						} else {
							$scope.scrollEnded = false;
						}
					} else {
						$ionicPopup.alert({
							template: "<p >" + result.errorMessage + "</p>"
						});
					}
				});
			}
			init();

			/*点赞热门详情*/
			$scope.praise = function() {
				var data = {};
				data.contentId = parameter.contentId;
				data.contentType = parameter.contentType;
				data.isCanceled = !!$scope.hotDetailContent.hasPraise;
				HotDetailServices.praiseHotDetailContent(data).then(function(result) {
					if (result.status) {
						$scope.hotDetailContent.hasPraise = !$scope.hotDetailContent.hasPraise;
						$scope.hotDetailContent.praiseCount = result.data.praiseCount;
					} else {
						$ionicPopup.alert({
							template: "<p >" + result.errorMessage + "</p>"
						});
					}
				});
			};

			/*切换显示评论*/
			var index_old = 0,
				parentId_old = 0;
			$scope.toggleMoreReplys = function(index, parentId) {
				if (parentId_old != parentId && parentId_old) {
					$scope.toggleLessReplys(index_old, parentId_old);
				}

				index_old = index;
				parentId_old = parentId;
				var replys;
				var data = {};
				data.type = parameter.contentType;
				data.param = {};
				data.param.parentId = parentId;
				data.param.pageSize = listReplyPageSize;
				data.param.startPage = listReplyStartPage;
				HotDetailServices.getMoreReplys(data).then(function(result) {
					if (result.status) {
						replys = result.data;
						result.currentPage == 0 ? $scope.hotDetailPostlist[index].commentReply = replys :
							$scope.hotDetailPostlist[index].commentReply = $scope.hotDetailPostlist[index].commentReply.concat(replys);

						listReplyStartPage++;
					} else {
						$ionicPopup.alert({
							template: "<p >" + result.errorMessage + "</p>"
						});
					}
				});
			};
			$scope.toggleLessReplys = function(index, parentId) {
				$scope.hotDetailPostlist[index].commentReply = $scope.hotDetailPostlist[index].commentReply.slice(0, 2);
				listReplyStartPage = 0;
			};
			$scope.getImageUrl = function(src){
				return assembleImageUrl(src)+'.thumbnail';
			};
			/*回复评论*/
			$scope.showKeyboard = function(autofocus) {
				var text;
				switch (commentData.type) {
					case 0:
						$scope.sign.ifperson = true;
						if(parameter.contentType=='theme'){
							$scope.sign.ifperson = false;
						}
						text = "回复：" + commentData.commenterName0;
						break;
					case 1:
						$scope.sign.ifperson = false;
						text = "回复：" + commentData.commenterName1;
						break;
					case 2:
						$scope.sign.ifperson = false;
						text = "回复：" + commentData.commenterName2;
						break;
					default:
						break;
				}
				if(autofocus==0){
					text="我也说两句";
				}

				$scope.isInputing = true;
				$timeout(function() {
					if (autofocus == 1) {
						$scope.$broadcast("inputOnFocus");
					}
					commentData.setTooltip(text);

				}, 500);
			};
			$scope.$on('inputSend', function(event, data) {
				if (data.indexOf('placeholder') != -1 || data == "") {
					showDialogbox2("请填写评论内容");
					return false;
				}
				var content = data;
				if (commentData.type == 0) {
					var data = {};
					data.type = parameter.contentType;
					data.param = {};
					data.param.contentType = parameter.contentType;
					data.param.contentId = parameter.contentId;
					data.param.commentContent = content;
					HotDetailServices.replyHotDetail(data).then(function(result) {
						if (result.status) {
							var reply = result.data;
							$scope.hotDetailPostlist.unshift(reply);
							$scope.hotDetailContent.commentCount++;
							$scope.replyDefault();
							showDialogbox2("回复成功");
						} else {
							$ionicPopup.alert({
								template: "<p >" + result.errorMessage + "</p>"
							});
						}
					});
				} else {
					var index1, index2;
					$($scope.hotDetailPostlist).each(function(index, el) {
						if (el.id == commentData.id1) {
							if (commentData.type == 2) {
								$(el.commentReply).each(function(i, e) {
									if (e.id == commentData.id2) {
										index2 = i;
										return;
									}
								});
							}
							index1 = index;
							return;
						};
					});

					var data = {};
					data.type = parameter.contentType;
					data.param = {};
					data.param.parentId = commentData.id1;
					data.param.commentContent = content;
					HotDetailServices.replyHotDetailPost(data).then(function(result) {
						if (result.status) {
							var reply = result.data;
							$($scope.hotDetailPostlist).each(function(index, el) {
								if (el.id == commentData.id1) {
									if (!el.commentReply) {
										el.commentReply = [];
									}
									el.commentReply.unshift(reply);
									el.commentReplySize++;
									showDialogbox2("回复成功");
									$scope.replyDefault();
									return;
								}
							});
						} else {
							$ionicPopup.alert({
								template: "<p >" + result.errorMessage + "</p>"
							});
						}
					});
				}
			});

			/*关注评论*/
			$scope.followPost = function() {
				var userId;
				$($scope.hotDetailPostlist).each(function(index, el) {
					if (el.id == commentData.id1) {
						if (commentData.type == 1) {
							userId = el.commenterId;
						} else {
							$(el.commentReply).each(function(index, e) {
								if (e.id == commentData.id2) {
									userId = e.commenterId;
									return;
								}
							});
						}
						return;
					}
				});
				var data = {};
				data.targetUserId = userId;
				HotDetailServices.followHotDetailPoster(data).then(function(result) {
					if (result.status) {
						showDialogbox2("关注评论人成功");
					} else {
						$ionicPopup.alert({
							template: "<p >" + result.errorMessage + "</p>"
						});
					}
				});
			};

			/*刷新数据*/
			$scope.doRefresh = function(atTop) {
				if (atTop) {
					$scope.hotDetailPostlist = {};
					listStartPage = 0;

					var data = {};
					data.type = parameter.contentType;
					data.param = {};
					data.param.contentId = parameter.contentId;
					data.param.defaultReplySize = listReplyDefaultSize;
					data.param.pageSize = listPageSize;
					data.param.startPage = listStartPage;
					HotDetailServices.getHotDetailPostlist(data).then(function(result) {
						if (result.status) {
							$scope.hotDetailPostlist = result.data;
							$scope.$broadcast('scroll.refreshComplete');
							listReplyStartPage = 0;

							refreshData("refresh", result.data.length);
							listStartPage++;

							if (result.currentPage >= (result.totalPage - 1)) {
								$scope.scrollEnded = true;
							} else {
								$scope.scrollEnded = false;
							}
						} else {
							$ionicPopup.alert({
								template: "<p >" + result.errorMessage + "</p>"
							});
						}
					});
				} else {
					var data = {};
					data.type = parameter.contentType;
					data.param = {};
					data.param.contentId = parameter.contentId;
					data.param.defaultReplySize = listReplyDefaultSize;
					data.param.pageSize = listPageSize;
					data.param.startPage = listStartPage;
					HotDetailServices.getHotDetailPostlist(data).then(function(result) {
						if (result.status) {
							var newPostlist = result.data;
							$scope.hotDetailPostlist = $scope.hotDetailPostlist.concat(newPostlist);
							$scope.$broadcast('scroll.infiniteScrollComplete');
							if (result.currentPage > 1) {
								refreshData("loadMore", result.data.length);
							}
							listStartPage++;
							if (result.currentPage >= (result.totalPage - 1)) {
								$scope.scrollEnded = true;
							}
						} else {
							$ionicPopup.alert({
								template: "<p >" + result.errorMessage + "</p>"
							});
						}
					});
				}
			};

			/*设置弹出工具*/
			$scope.showTool = function(event) {
				var $target = $(event.target);
				if (!$target.hasClass('tooltip') && !$target.parents().hasClass('tooltip')) {
					return;
				}
				if (!$target.hasClass('tooltip')) {
					$target = $target.parents('.tooltip');
				}
				commentData.type = $target.data('type');
				commentData.id1 = $target.data('id1');
				commentData.id2 = $target.data('id2');
				commentData.commenterId1 = $target.data('commenterid1');
				commentData.commenterId2 = $target.data('commenterid2');
				commentData.commenterName1 = $target.data('commentername1');
				commentData.commenterName2 = $target.data('commentername2');
				$(".hot-detail-tool").css({
					top: event.pageY,
					left: event.pageX
				}).show();
			};
			$scope.hideTool = function() {
				$(".hot-detail-tool").hide();
			};
			$('ion-content').on('touchstart', function(obj) {
				$scope.hideTool();
			});

			$scope.replyDefault = function(at) {
					commentData.type = 0;
					commentData.id0 = parameter.contentId;
					commentData.commenterId0 = $scope.hotDetailContent.createrId;
					commentData.commenterName0 = $scope.hotDetailContent.createrName;
					$scope.showKeyboard(at ? at : 0);
				}
				/*点击按钮*/
			$scope.setTool = function(type) {
				switch (type) {
					case 0:
						$scope.showKeyboard(1);
						break;
					case 1:
						$scope.followPost();
						break;
					default:
						;
				}
				$scope.hideTool();
			};
			$scope.imageView = function(src) {
				
				var imgArray = [];
				_.each($scope.hotDetailContent.contentSequence, function(content){
					if(content.type == 'image'){
						imgArray.push(assembleImageUrl(content.src));
					}
				});
				var index = 0;
				for (var i=0; i<imgArray.length; i++){
					if(imgArray[i] == assembleImageUrl(src)){
						index = i;
						break;
					}
				}
				imgArray.unshift(index);
				pictrueViewer(imgArray);

			};
			$(window).on('touchstart', function(obj) {
				keyboardDown();
			});

			$scope.dealPath = function(url){
				return assembleImageUrl(url);
			};
		}
	])
});