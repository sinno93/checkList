define(['angularAMD', 'global'], function(angularAMD) {
	angularAMD.factory('hotServices', ["$http", "$q", "Global",
		function($http, $q, Global) {
			var getPromise = function(p) {
				var defer = $q.defer();
				p.success(function(response) {
					return defer.resolve(response);
				}).error(function() {
					return defer.reject();
				});
				return defer.promise;
			};
			return {
				//热门首页banner
				getBanner: function() {
					var url = Global.apiPath + "/ads/list/hot";
					return getPromise($http.get(url));
				},
				//热门首页列表10.20
				getListData: function(data) {
					var url = Global.apiPath + "/kmshome/list?" + $.param(data);
					return getPromise($http.get(url));

					},
					//收藏
					getIsCollect:function(data){
						var url = Global.apiPath + "/favorite/collect?" + $.param(data);
					    return getPromise($http.get(url));
					},
					//获得当前用户的信息
					getUerInfo:function(userId){
						var url= Global.apiPath+'/usermessage/profiles/'+userId;
						return getPromise($http.get(url));
					}
					
			};
		}
	]);

});