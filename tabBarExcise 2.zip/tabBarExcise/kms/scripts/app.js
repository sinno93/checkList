define(['common'], function(angularAMD) {
	'use strict';
	var kmsApp = angular.module('kms', ['ionic', 'ngResource']);

	kmsApp.config(['$httpProvider',
		function($httpProvider) {
			$httpProvider.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
		}
	]);
	kmsApp.config(['$stateProvider', '$urlRouterProvider',
		function($stateProvider, $urlRouterProvider) {
			$stateProvider
				.state('hot', angularAMD.route({
					url: '/hot',
					templateUrl: 'views/hot/hot-frame.html',
					controllerUrl: 'hot/controllers/hot-frame-controller',
					controller: 'hotFrameController'
				}))
				.state('asks', angularAMD.route({
					url: '/asks',
					templateUrl: 'views/asks/asks-frame.html',
					controllerUrl: 'asks/controllers/asks-frame-controller',
					controller: 'asksFrameController'
				}))
				.state('create-answer', angularAMD.route({
					url: '/create-answer/:askID',
					templateUrl: 'views/asks/answer-create.html',
					controllerUrl: 'asks/controllers/answer-create-controller',
					controller: 'answerCreateController'
				}))
				.state('asksDetail', angularAMD.route({
					url: '/asksDetail/:askID',
					templateUrl: 'views/asks/detail/ask-detail.html',
					controllerUrl: 'asks/controllers/question-detail-controller',
					controller: 'questionDetailController'
				}))
				.state('answer', angularAMD.route({
					url: '/answer/:questionID/:answererID/:type',
					templateUrl: 'views/asks/detail/answer-detail.html',
					controllerUrl: 'asks/controllers/answer-detail-controller',
					controller: 'answerDetailController'
				}))
				.state('community', angularAMD.route({
					url: '/community',
					templateUrl: 'views/community/community-frame.html',
					controllerUrl: 'community/controllers/community-frame-controller',
					controller: 'communityFrameController'
				}))
				.state('community-detail', angularAMD.route({
					url: '/community-detail/:communityId',
					templateUrl: 'views/community/community-detail.html',
					controllerUrl: 'community/controllers/community-detail-controller',
					controller: 'communityDetailController'
				}))
				.state('mine', angularAMD.route({
					url: '/mine',
					templateUrl: 'views/mine/mine-frame.html',
					controllerUrl: 'mine/controllers/mine-frame-controller',
					controller: 'mineFrameController'
				}))
				.state('mine-attention-fans', angularAMD.route({
					url: '/mine/mine-attention-fans/:attentionorfans',
					templateUrl: 'views/mine/mine-attention-fans.html',
					controllerUrl: 'mine/controllers/mine-attentionfans-controller',
					controller: 'mineAttentionFansController'
				}))
				.state('mine-private-message', angularAMD.route({
					url: '/mine-private-message',
					templateUrl: 'views/mine/mine-private-message.html',
					controllerUrl: 'mine/controllers/mine-private-message-list-controller',
					controller: 'minePrivateMessageListController'
				}))
				.state('private-message-detail', angularAMD.route({
					url: '/private-message-detail/:id',
					templateUrl: 'views/mine/mine-private-message-detail.html',
					controllerUrl: 'mine/controllers/mine-private-message-detail-controller',
					controller: 'minePrivateMessageDetailController'
				}))
				.state('talk-list', angularAMD.route({
					url: '/talk-list/:who/:workId',
					templateUrl: 'views/mine/mine-talk.html',
					controllerUrl: 'mine/controllers/mine-talk-controller',
					controller: 'mineTalkController'
				}))
				.state('talk-write', angularAMD.route({
					url: '/talk-write/:who/:workId',
					templateUrl: 'views/mine/mine-write.html',
					controllerUrl: 'mine/controllers/mine-write-controller',
					controller: 'mineWriteController'
				}))
				.state('ta', angularAMD.route({
					url: '/ta/:workID',
					templateUrl: 'views/ta/ta-frame.html',
					controllerUrl: 'ta/controllers/ta-frame-controller',
					controller: 'taFrameController'
				}))
				.state('ta-question', angularAMD.route({
					url: '/ta-question/:workID',
					templateUrl: 'views/ta/ta-question.html',
					controllerUrl: 'ta/controllers/ta-question-controller',
					controller: 'taQuestionController'
				}))
				.state('ta-attention-fans', angularAMD.route({
					url: '/ta/ta-attention-fans/:workID/:attentionorfans',
					templateUrl: 'views/ta/ta-attention-fans.html',
					controllerUrl: 'ta/controllers/ta-attentionfans-controller',
					controller: 'taAttentionFansController'
				}))
				.state('leaveMessageCreate', angularAMD.route({
					url: '/leave-message-create/:workID',
					templateUrl: 'views/common/leave-message-create.html',
					controllerUrl: 'common/controllers/leave-message-create-controller',
					controller: 'leaveMessageCreateController'
				}))
				.state('leaveMessage', angularAMD.route({
					url: '/leave-message/:who/:workID',
					templateUrl: 'views/ta/leave-message.html',
					controllerUrl: 'ta/controllers/leave-message-controller',
					controller: 'leaveMessageController'
				}))
				.state('createQuestion', angularAMD.route({
					url: '/createQuestion',
					templateUrl: 'views/asks/detail/ask-create.html',
					controllerUrl: 'asks/controllers/question-create-controller',
					controller: 'questionCreateController'
				}))
				.state('createTheme', angularAMD.route({
					url: '/createTheme/:sourceId',
					templateUrl: 'views/community/create-theme.html',
					controllerUrl: 'community/controllers/theme-create-controller',
					controller: 'themeCreateController'
				}))
				.state('messageBox', angularAMD.route({
					url: '/messageBox',
					templateUrl: 'views/mine/message-box.html',
					controllerUrl: 'mine/controllers/message-box-controller',
					controller: 'messageBoxController'
				}))
				.state('myQuestion', angularAMD.route({
					url: '/myQuestion',
					templateUrl: 'views/mine/mine-question.html',
					controllerUrl: 'mine/controllers/mine-question-controller',
					controller: 'myQuestionController'
				}))
				.state('hotDetail', angularAMD.route({
					url: '/hotDetail/:contentId/:type',
					templateUrl: 'views/hot/hot-detail.html',
					controllerUrl: 'hot/controllers/hot-detail-controller',
					controller: 'hotDetailController'
				}))
				.state('mine-collection', angularAMD.route({
					url: '/mine-collection',
					templateUrl: 'views/mine/mine-collection.html',
					controllerUrl: 'mine/controllers/mine-collection-controller',
					controller: 'mineCollectionController'
				}))
				.state('ta-discuss', angularAMD.route({
					url: '/ta/discuss/:workID',
					templateUrl: 'views/mine/mine-discuss.html',
					controllerUrl: 'mine/controllers/mine-discuss-controller',
					controller: 'mineDiscussController'
				}))
				.state('mine-discuss', angularAMD.route({
					url: '/mineDiscuss',
					templateUrl: 'views/mine/mine-discuss.html',
					controllerUrl: 'mine/controllers/mine-discuss-controller',
					controller: 'mineDiscussController'
				}))
				.state('talk-detail', angularAMD.route({
					url: '/talk-detail/:microblogId/:empNumber',
					templateUrl: 'views/mine/talk-detail.html',
					controllerUrl: 'mine/controllers/talk-detail-controller',
					controller: 'talkDetailController'
				}))
			$urlRouterProvider.otherwise('/hot');
		}
	]);

	kmsApp.config(['$sceProvider', '$httpProvider',
		function($sceProvider, $httpProvider) {
			$sceProvider.enabled(false);
			$httpProvider.interceptors.push('HttpInterceptor');
			$httpProvider.interceptors.push('LoadingInterceptor');
		}
	]);

	return angularAMD.bootstrap(kmsApp);
});