define(['angularAMD', 'global'], function(angularAMD) {
	angularAMD.factory('asksServices', ["$http", "$q", "Global",
		function($http, $q, Global) {
			var getPromise = function(p) {
				var defer = $q.defer();
				p.success(function(response) {
					return defer.resolve(response);
				}).error(function() {
					return defer.reject();
				});
				return defer.promise;
			};
			return {
				/**获得爱问的内容列表*/
				getAskLists:function(obj){
					console.log(obj);
					var url = Global.apiPath+'/question/list?categoryCode='+obj.categoryCode+"&pageSize="+obj.pageSize+"&startPage="+obj.startPage+"&title="+obj.keyWord;
					return getPromise($http.get(url));
				},
				/**获得爱问的类型*/
				getAskCategoryCode:function(){
					var url = Global.apiPath + '/question/category/list-top'
					return getPromise($http.get(url));
				},
				/**
				 * 爱问精选
				 * @param {Object} item
				 */
				getAskChoiceness:function(item){
					var url=Global.apiPath+'/question/list/choiceness?title='+item.keyWord+'&startPage='+item.startPage+'&pageSize='+item.pageSize;
					return getPromise($http.get(url));
				},
				/**
				 * 获得爱问最高悬赏
				 * @param {Object} item
				 */
				getAskMaximunReward:function(item){
					var url=Global.apiPath+'/question/list/maximum-reward?title='+item.keyWord+'&startPage='+item.startPage+'&pageSize='+item.pageSize;
					return getPromise($http.get(url));
				},
				//问题的详情
				getAskDetail: function(data) {
					var url = Global.apiPath+'/question/view/'+data;
					return getPromise($http.get(url));
				},
				//获取我的问题的答案
				getAnswerList: function(data) {
					var url = Global.apiPath+'/question/reply/list?'+$.param(data);
					return getPromise($http.get(url));
				},
				//关注/取消关注
				setFollow: function(data) {
					var questionId=data.questionId;
					var cancel=data.cancel;
					var url = Global.apiPath+'/question/'+(cancel?'cancel-':'')+'follow/'+questionId;
					return getPromise($http.get(url));
				},
				//采纳答案
				setAdopt: function(data) {
					var url = Global.apiPath+'/question/reply/adopt?'+$.param(data);
					return getPromise($http.get(url));
				},
				//评价问题答案
				setComment: function(data) {
//					var url = Global.apiPath+'/question/reply/comment?'+$.param(data);
//					return getPromise($http.get(url));
					var url = Global.apiPath+'/question/reply/comment';
					return getPromise($.post(url, data));
				},
				/**http://kms-mcmsrepo.sit.sf-express.com/KMS-MSERVER
				 * @param {Object} data
				 * 回答提出的问题
				 */
				setReply:function(data){
					var url = Global.apiPath+'/question/reply/save';
					return getPromise($.post(url, data));
				},
				/**
				 * @param {Object} data 如果已经有回答，就编辑回答
				 */
				updateReply:function(data){
					var url = Global.apiPath+'/question/reply/update';
					return getPromise($.post(url, data));
				},
				/**
				 * @param {Object} data
				 * 提出追问
				 */
				setAppend:function(data){
					var url=Global.apiPath+'/question/append';
					return getPromise($.post(url, data));
				},
				//回复追问
				replyAppend:function(data){
					var url=Global.apiPath+'/question/reply/reply-append';
					return getPromise($.post(url, data));
				},
				//追加悬赏
				setAppendReword: function(data) {
					var rewardScore=data;
					var url = Global.apiPath+'/question/reword?score='+rewardScore;
					return getPromise($http.get(url));
				},
				//撤销问题
				deleteQuestion: function(data) {
					var questionId=data;
					var url = Global.apiPath+'/question/delete/'+questionId;
					return getPromise($http.get(url));
				},
				//撤销问题
				atOthersQuestion: function(data) {
					var url = Global.apiPath+'/question/view/invite?'+$.param(data);
					return getPromise($http.get(url));
				},
				//创建一个问题
				saveQuestion: function(data){
					var questionId=data;
					var url = Global.apiPath+'/question/save?'+$.param(data);
					return getPromise($http.get(url));
				},
				//获得问题的答案和追问答案以及追问的答案
				getReplyAndAppendReply:function(replyID){
					var url=Global.apiPath+'/question/reply/view/'+replyID;
					return getPromise($http.get(url));
				},
				//获得答案的评论
				getReplyComment:function(replyID){
					var url = Global.apiPath+'/question/reply/comment/list/'+replyID;
					return getPromise($http.get(url));
				},
				//回答问题点赞
				praiseReplyQuestion: function(data) {
					var url = Global.apiPath+'/praise/toPraise?'+$.param(data.param);
					return getPromise($http.get(url));
				},
				//获取最高积分
				getTopScore: function(data) {
					var url = Global.apiPath+'/question/view/available-score?'+$.param(data.param);
					return getPromise($http.get(url));
				},
				getUserInfo:function(){
					var myId = getMyId();
					var url = Global.apiPath + '/usermessage/profiles/'+myId;
					return getPromise($http.get(url));
				},
				
			};
		}
	]);

});