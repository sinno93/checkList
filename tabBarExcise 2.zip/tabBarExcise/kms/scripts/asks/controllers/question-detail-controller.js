define(['angularAMD', 'common/services/footer-service', 'asks/services/ask-services', 'asks/directives/question-detail-directives', 'common/controllers/staff-selection-controller', 'common/filters/common-filter', 'common/directive/input-box'], function(angularAMD) {
	angularAMD.controller('questionDetailController', ['$scope', '$ionicModal', '$ionicPopup', '$location', '$rootScope', '$stateParams', 'FooterServices', '$ionicScrollDelegate', 'asksServices', '$timeout',
		function($scope, $ionicModal, $ionicPopup, $location, $rootScope, $stateParams, FooterServices, $ionicScrollDelegate, asksServices, $timeout) {
			'use strict';
			/*模拟数据*/
			var parameter={};
			parameter.askID=$stateParams.askID; //问题id
			parameter.userID=getMyId() || "002628";//用户Id
			$scope.isFollowed=false; //已经关注
			$scope.isExpire=false; //已经过期
			/*分页控制*/
			var listPageSize=5;
			var listStartPage=0;

			//定义对话框
			$scope.showDialogbox1=function(){/*积分选择*/
				$scope.explain = '';
				$scope.modalYes = "确定";
				$scope.modalNo = "取消";
				$scope.modalShow = 5;
				var setScoreList=function(length){
					var list=[];
					for (var i = 1; i <(length+1); i++) {
						var item={
							score: i,
							scoreName: i+"积分",
							selected: 0
						}
						list.push(item);
					};
					list[0].selected=1;
					return list;
				}
				$scope.scoreList=setScoreList(10);
				var rewardScore=1;
				$scope.setScore=function(index, score){
					$('.score-list').find("li").removeClass('on');
					$('.score-list').find("li").eq(index).addClass('on');
					rewardScore=score;
				};
				$scope.html='views/common/score-list.html';
				$scope.isBatch = function(flag) {
					if(flag){
						_appendReward(rewardScore)
					}
					$scope.modal.hide();
				};
				$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
					scope: $scope,
					animation: 'slide-in-up'
				}).then(function(modal) {
					$scope.modal = modal;
					$scope.modal.show();
				});
			}
			$scope.showDialogbox2=function(text, callback){/*confirm*/
				$scope.explain = text;
				$scope.modalYes = "确定";
				$scope.modalNo = "取消";
				$scope.modalShow = 3;
				$scope.isBatch = function(flag) {
					if(flag){
						callback();
					}
					$scope.modal.hide();
				};
				$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
					scope: $scope,
					animation: 'slide-in-up'
				}).then(function(modal) {
					$scope.modal = modal;
					$scope.modal.show();
				});
			}
			$scope.showDialogbox3=function(text){/*提示*/
				$scope.modalShow = 10;
				$scope.collectContent = text;
				$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
					scope: $scope,
					animation: 'slide-in-up'
				}).then(function(modal){
					$scope.modal = modal;
					$scope.modal.show();
					$timeout(function(){
						$scope.modal.hide();
					}, 1000);
				});
			};
			/*刷新数据提示*/
			function refreshData(type, length) {
				if (type == "refresh") {
					if (length > 0) {
						$scope.refresherData = "已经为您更新" + length + "条数据";
						$(".refresher-data").show();
						$timeout(function() {
							$(".refresher-data").hide();
						}, 1000);
					}

				} else if (type == "loadMore") {
					if (length > 0) {
						$scope.infiniteData = "已经为您加载" + length + "条数据";
						$(".infinite-data").show();
						$timeout(function() {
							$(".infinite-data").hide();
						}, 1000);
					}
				}
			}
			var isShowNomore=false;
			$scope.scrollDragUp=function(){
				var currentTop = $ionicScrollDelegate.getScrollPosition().top;
				var maxTop = $ionicScrollDelegate.getMaxTop();
				if (currentTop - maxTop > 50 && maxTop > 0) {
					if (!isShowNomore && $scope.scrollEnded) {
						isShowNomore = true;
						$scope.infiniteData = "已经到底啦!";
						$(".infinite-data").show();
						setTimeout(function() {
							$(".infinite-data").hide();
							isShowNomore = false;
						}, 700);
					}

				}
			}
			/*页面表情转码*/
			$scope.emoijToText=function(html, less){
				if(!html){
					return;
				}
				if(less && html.length>30){
					html=html.substr(0, 27);
					html=html+"...";
				}
				var text=replace_html(html);
				return text;
			};
			/*转到他的主页*/
			$scope.goHome=function(userId){
				if(userId==getMyId()){
					$location.path('/mine');
				}else{
					$location.path('/ta/'+userId);
				}
				event.stopPropagation();
			};

			//初始化函数
			function init() {
				FooterServices.hide();
				$scope.title = "问题详情";
				$scope.adoptImg="styles/images/accept.png";
				$scope.scrollEnded=true;

				var data={};
				data.questionId=parameter.askID;
				asksServices.getAskDetail(data.questionId).then(function(result){
					if (result.status) {
						$scope.detail=result.data;
						$scope.isSelf=($scope.detail.createrId==parameter.userID);

						$(".content-body").removeClass('hide-on-in');
					} else {
						$ionicPopup.alert({
							template: "<p >" + result.errorMessage + "</p>"
						});
					}
				});

				var data={};
				data.questionId=parameter.askID;
				data.pageSize=listPageSize;
				data.startPage=listStartPage;
				asksServices.getAnswerList(data).then(function(result){
					if (result.status) {
						$scope.answers=result.data;

						listStartPage++;
						if(result.currentPage>=(result.totalPage-1)){
							$scope.scrollEnded=true;
						}else{
							$scope.scrollEnded=false;
						}
					} else {
						$ionicPopup.alert({
							template: "<p >" + result.errorMessage + "</p>"
						});
					}
				});
			}
			init();

			$scope.back = function() {
				history.back(-1);
			};
			$scope.headPath = function(path){
				return assembleImageUrl(path);
			};
			$scope.replyMyself=function(){
				$location.path('/create-answer/' + parameter.askID );
			};
			$scope.toggleFollow=function(){
				var data={};
				data.questionId=$stateParams.askID;
				data.cancel=$scope.detail.isAttention;
				asksServices.setFollow(data).then(function(result){
					if(result.status){
						$scope.detail.isAttention=!$scope.detail.isAttention;
					}else{
						$ionicPopup.alert({
							template: "<p >" + result.errorMessage + "</p>"
						});
					}
				});
			};
			//@他人回答
			$scope.$on("personComplete", function(event, data){
				var person=data;
				var data={};
				data.questionId=$scope.detail.id;
				data.inviteUserIds=person.join(",");
				asksServices.atOthersQuestion(data).then(function(result){
					if(result.status){
						$scope.showDialogbox3("邀请他人回答成功");
					}else{
						$ionicPopup.alert({
							template: "<p >" + result.errorMessage + "</p>"
						});
					}
				});
			});
			//采纳、评论
			$scope.adoptAnswer=function(targetId){
				var data={};
				data.id=targetId;
				data.adoptComment='';
				asksServices.setAdopt(data).then(function(result){
					if(result.status){
						$scope.answers.forEach(function(item){
							if(item.id==targetId){
								item.isBestReply=1;
							}else{
								item.isBestReply=0;
							}
						});

						$scope.showDialogbox3("回答采纳成功");
					}else{
						$ionicPopup.alert({
							template: "<p >" + result.errorMessage + "</p>"
						});
					}
					$scope.isInputing=false;
				});
			}
			$scope.commentAnswer=function(targetId, event){
				$location.path('/answer/' + parameter.askID+'/'+targetId+'/'+'comment');
			}
			$scope.toAnswerDetail = function(targetId, replyerId, appendReply){
				if($scope.isSelf){
					if($scope.detail.isSolve){
						$location.path('/answer/' + parameter.askID+'/'+targetId+'/comment');
					}else{
						$location.path('/answer/' + parameter.askID+'/'+targetId+ '/append');
					}
				}else if(replyerId==parameter.userID){
					if($scope.detail.isSolve){
						$location.path('/answer/' + parameter.askID+'/'+targetId+'/comment');
					}else{
						$location.path('/answer/' + parameter.askID+'/'+targetId+ '/'+(appendReply?'appendReply':'detailReply'));
					}
				}else{
					$location.path('/answer/' + parameter.askID+'/'+targetId+'/comment');
				}
			};
			//问题详情中包含图片的查看
			$scope.praiseAnswer=function(id, index){
				var praise=!$scope.answers[index].isPraise;
				var data={};
				data.param={};
				data.param.contentId=id;
				data.param.contentType='question';
				data.param.isCanceled=!praise;
				asksServices.praiseReplyQuestion(data).then(function(result){
					if(result.status){
						if(praise){
							$scope.answers[index].isPraise=true;
						}else{
							$scope.answers[index].isPraise=false;
						}
						$scope.answers[index].priaseCount=result.data.praiseCount;
					}else{
						$ionicPopup.alert({
							template: "<p >" + result.errorMessage + "</p>"
						});
					}
				});

			};
			//问题答案的图片的查看
			$scope.showPic = function(item, src, event) {
				var imgArray = [];
				_.each(item.contentSequence, function(content){
					if(content.type == 'image'){
						imgArray.push(assembleImageUrl(content.src));
					}
				});
				var index = 0;
				for (var i=0; i<imgArray.length; i++){
					if(imgArray[i] == assembleImageUrl(src)){
						index = i;
						break;
					}
				}
				imgArray.unshift(index);
				pictrueViewer(imgArray);
				event.stopPropagation();
			};

			//撤销问题
			$scope.delete=function(questionId){
				asksServices.deleteQuestion(questionId).then(function(result){
					if(result.status){
						$scope.showDialogbox3("撤销提问成功");

						$location.path('/asks');
					}else{
						$ionicPopup.alert({
							template: "<p >" + result.errorMessage + "</p>"
						});
					}
				});
			};
			$scope.getImageUrl = function(src){
				return assembleImageUrl(src)+'.thumbnail';
			};
			$scope.showImageViewer = function(src){
				var imgArray = [];
				_.each($scope.detail.contentSequence, function(content){
					if(content.type == 'image'){
						imgArray.push(assembleImageUrl(content.src));
					}
				});
				var index = 0;
				for (var i=0; i<imgArray.length; i++){
					if(imgArray[i] == assembleImageUrl(src)){
						index = i;
						break;
					}
				}
				imgArray.unshift(index);
				pictrueViewer(imgArray);
			};

			/*刷新数据*/
			$scope.doRefresh = function(atTop) {
				if(atTop){
					$scope.answers={};
					listStartPage=0;

					var data={};
					data.questionId=parameter.askID;
					data.pageSize=listPageSize;
					data.startPage=listStartPage;
					asksServices.getAnswerList(data).then(function(result){
						$scope.answers=result.data;
						$scope.$broadcast('scroll.refreshComplete');
						refreshData("refresh", result.data.length);
						listStartPage++;
						if(result.currentPage>=(result.totalPage-1)){
							$scope.scrollEnded=true;
						}else{
							$scope.scrollEnded=false;
						}
					});
				}else{
					var data={};
					data.questionId=parameter.askID;
					data.pageSize=listPageSize;
					data.startPage=listStartPage;
					asksServices.getAnswerList(data).then(function(result){
						if(result.status){
							var newList=result.data;
							$scope.answers=$scope.answers.concat(newList);

							$scope.$broadcast('scroll.infiniteScrollComplete');
							if(result.currentPage>1){
								refreshData("loadMore", result.data.length);
							}
							listStartPage++;
							if(result.currentPage>=(result.totalPage-1)){
								$scope.scrollEnded=true;
							}else{
								$scope.scrollEnded=false;
							}
						}else{
							$ionicPopup.alert({
								template: "<p >" + result.errorMessage + "</p>"
							});
						}
					});
				}
			};
		}
	])

});