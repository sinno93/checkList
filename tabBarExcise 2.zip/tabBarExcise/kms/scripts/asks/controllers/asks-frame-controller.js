define(['angularAMD', 'common/services/footer-service', 'common/services/common-group-service', 'asks/services/ask-services', 'common/filters/common-filter'], function(angularAMD) {
	angularAMD.controller('asksFrameController', ['$scope', '$ionicModal', '$location', '$rootScope', 'FooterServices', '$ionicScrollDelegate', 'commonGroupServices', 'asksServices', '$timeout',
		function($scope, $ionicModal, $location, $rootScope, FooterServices, $ionicScrollDelegate, commonGroupServices, asksServices, $timeout) {

			'use strict';
			FooterServices.activeItemByIndex(1);
			$scope.title = "爱问";
			$scope.ok  = '确定';
			$scope.explain = "是否退出KMS模块？";
			$scope.modalYes = "是";
			$scope.modalNo = "否";
			$scope.modalShow = 3;

			$scope.data = {};
			var myWorkID = 'sfit0627';
			var DEFAULT_PAGE_SIZE = 8;
			$scope.beginSearch = false;
			var curCode = 'jx';
			$scope.items = [];
			var workID = getMyId();
			$scope.tabGroup = [{
				text: '精选',
				name: 'jx'
			}, {
				text: '最新',
				name: 'newest'
			}, {
				text: '最高奖励',
				name: 'highest'
			}];

			function getAskTabGroup(datas) {
				_.each(datas, function(data) {
					$scope.tabGroup.push({
						text: data.categoryName,
						name: data.categoryCode
					});
				});
			}

			FooterServices.activeItemByIndex(1);



			function assembleItem(categoryCode) {
				return {
					'categoryCode': (categoryCode == 'newest' ? '' : categoryCode),
					'pageSize': DEFAULT_PAGE_SIZE,
					'startPage': $scope.startPage,
					'keyWord': $scope.data.keyword
				};
			}

			/**
			 * 组装精选，最高悬赏的上传参数
			 */
			function assembleOtherItem() {
				return {
					'keyWord': $scope.data.keyword,
					'startPage': $scope.startPage,
					'pageSize': DEFAULT_PAGE_SIZE
				};
			}

			function init() {

				initPage();
				$scope.data.keyword = '';
				asksServices.getAskCategoryCode().then(function(response) {
					getAskTabGroup(response.data);
					initTabGroup();
				});
				asksServices.getAskChoiceness(assembleOtherItem()).then(function(response) {
					pushItem(response);
					NoData($scope.items.length, 1);
				});
			}

			init();

			$ionicModal.fromTemplateUrl('views/common/my-modal.html', {
				scope: $scope,
				animation: 'slide-in-up'
			}).then(function(modal) {
				$scope.modal = modal;
			});
			$scope.backLogin = function() {
				if ($scope.beginSearch) {
					$scope.beginSearch = false;
				} else {
					$location.path("/hot");
				}

			};
			$scope.getImageUrl = function(src){
				return assembleImageUrl(src)+'.thumbnail';
			}
			$scope.showPic = function(item, src, event) {
				var imgArray = [];
				_.each(item.contentSequence, function(content){
					if(content.type == 'image'){
						imgArray.push(assembleImageUrl(content.src));
					}
				});
				var index = 0;
				for (var i=0; i<imgArray.length; i++){
					if(imgArray[i] == assembleImageUrl(src)){
						index = i;
						break;
					}
				}
				imgArray.unshift(index);
				pictrueViewer(imgArray);
				event.stopPropagation();
			};
			$scope.getCreator = function(item) {
				var result = item.createrName + ' ' + item.createrId;
				return result;
			};
			$scope.getCreatorName = function(item) {
				var name=item.createrName;
				var result = name;
				return result;
			};
			$scope.getCreatorId = function(item) {
				var result = item.createrId;
				return result;
			};
			$scope.hasReward = function(item) {
				return item.rewardScore != null && item.rewardScore > 0;
			};
			$scope.hasImage = function(item) {
				var hasImage = false;
				_.each(item.contentSequence, function(content) {
					if (content.type == 'image') {
						hasImage = true;
					}
				});
				return hasImage;
			};
			$scope.isImage = function(type) {
				return type == 'image';
			};
			$scope.deleteKeyword = function() {
				console.log('delete');
				$scope.data.keyword = '';
			};
			$scope.gosearch = function() {
				$scope.items = [];
				getAskListInfo(curCode);
			};
			$scope.toAnswerQuestion = function(item, event) {
				$location.path('/create-answer/' + item.id);
				event.stopPropagation();
			};
			$scope.isMyQuestion = function(type) {
				return workID == type.createrId;
			};

			//搜索
			$scope.search = function() {
					$scope.beginSearch = true;
				}
				//编辑
			$scope.editor = function() {
					$location.path('/createQuestion');
				}
				/**
				 * 去到创建人详情页面
				 */
			$scope.toCreatorDetail = function(item, event) {
				if (item.createrId == getMyId()) {
					$location.path('/mine');
				} else {
					$location.path('/ta/' + item.createrId);
				}

				event.stopPropagation();
			};
			$scope.goAskDetail = function(item) {
				$location.path('/asksDetail/' + item.id);
			};
			$scope.emoijToText = function(html) {

				return replace_html(html);
			};
			$scope.isSlove = function(isSlove) {
				if (isSlove == 1) {
					return '已解决';
				} else {
					return '未解决';
				}
			};
			$scope.answerType = function(isSolve) {
				if (isSolve == 1) {
					return '我来补充';

				} else {
					return '我来回答';
				}
			};

			function cleanAllActiveStatus() {
				_.each($scope.tabGroup, function(tab) {
					tab.isActive = false;
				});
			}
			$scope.activeTab = function(tabName) {
				$ionicScrollDelegate.resize();
				$scope.items = [];
				cleanAllActiveStatus();
				var tab = getTabByName(tabName);
				$scope.isFirstIn = true;
				tab.isActive = true;
				curCode = tabName;
				initPage();
				getAskListInfo(tabName);
				
			}

			/**
			 * 加载的数据push到容器
			 * @param {Object} response
			 */
			function pushItem(response) {
					$scope.items = response.data;
				checkAvailableItems(response.totalSize);
				cancelScrollInitFunction();
			}

			function getAskListInfo(name) {
				
				if (name == 'jx') {
					asksServices.getAskChoiceness(assembleOtherItem()).then(function(response) {
						pushItem(response);
						NoData($scope.items.length, 1);
					});
				} else if (name == 'highest') {
					asksServices.getAskMaximunReward(assembleOtherItem()).then(function(response) {
						pushItem(response);
						NoData($scope.items.length, 1);
					});
				} else {
					asksServices.getAskLists(assembleItem(name)).then(function(response) {
						pushItem(response);
						NoData($scope.items.length, 1);
					});
				}
			}
			//得到标签的名字

			function getTabByName(tabName) {
				return _.find($scope.tabGroup, function(tab) {
					return tab.name === tabName;
				});
			}

			function initTabGroup() {
				$scope.tabGroup[0].isActive = true;
			}

			function initPage() {
				$scope.startPage = 0;
				$scope.pageSize = DEFAULT_PAGE_SIZE;
				$scope.noMoreItemsAvailable = true;
			}

			function cancelScrollInitFunction() {
				$timeout(function() {
					$scope.$broadcast('scroll.refreshComplete');
				}, 100);
			}

			function checkAvailableItems(total) {
				$scope.noMoreItemsAvailable = $scope.items.length === total;
			}

			/**
			 * 刷新新加载的数据
			 * @param {Object} newItems
			 */
			function addNewItem(response) {
				var newItems = response.data;
				_.each(newItems, function(item) {
					$scope.items.push(item);
				});
				$scope.$broadcast('scroll.infiniteScrollComplete');

				checkAvailableItems(response.totalSize);
				refreshData('loadMore', newItems.length);
			}

			function refreshData(type, length) {
				if (type == "refresh") {
					if (length > 0) {
						$scope.refresherData = "已经为您更新" + length + "条数据";
						$(".refresher-data").show();
						$timeout(function() {
							$(".refresher-data").hide();
						}, 1500);
					}

				} else if (type == "loadMore") {
					if (length > 0) {
						$scope.infiniteData = "已经为您加载" + length + "条数据";
						$(".infinite-data").show();
						$timeout(function() {
							$(".infinite-data").hide();
						}, 1500);
					}
				}

			}


			function checkNewItemsCount(newItems, items) {
				var count = 0;
				var temp = items[0].createrDate;
				for (var i = 0; i < newItems.length; i++) {
					if (newItems[i].createrDate != temp) {
						if (i == 0) {
							items.unshift(newItems[i]);
						} else {
							items.splice(i, 0, newItems[i]);
						}
						count++;
					} else {
						break;
					}
				}
				return count;
			}

			$scope.onRefresh = function() {
				if (curCode == 'jx') {
					$scope.items = [];
					$scope.startPage = 0;
					asksServices.getAskChoiceness(assembleOtherItem()).then(function(response) {
						$scope.items = response.data;
						cancelScrollInitFunction();
						checkAvailableItems(response.totalSize);
						refreshData('refresh', $scope.items.length);
					});
				} else if (curCode == 'newest') {
					asksServices.getAskLists({
						'categoryCode': '',
						'pageSize': DEFAULT_PAGE_SIZE,
						'startPage': 0,
						'keyWord': $scope.data.keyword
					}).then(function(response) {
						var newItems = response.data;
						var count = checkNewItemsCount(newItems, $scope.items);
						console.log(newItems);
						refreshData('refresh', count);
						cancelScrollInitFunction();
					});
				} else if (curCode == 'highest') {
					$scope.items = [];
					$scope.startPage = 0;
					asksServices.getAskMaximunReward(assembleOtherItem()).then(function(response) {
						$scope.items = response.data;
						cancelScrollInitFunction();
						checkAvailableItems(response.totalSize);
						refreshData('refresh', $scope.items.length);
					});
				} else {
					asksServices.getAskLists({
						'categoryCode': curCode,
						'keyWord': $scope.data.keyword,
						'startPage': 0,
						'pageSize': DEFAULT_PAGE_SIZE
					}).then(function(response) {
						var newItems = response.data;
						cancelScrollInitFunction();
						var count = checkNewItemsCount(newItems, $scope.items);
						refreshData('refresh', count);
					});
				}
			};


			$scope.isFirstIn = true;
			$scope.loadMore = function() {
				if ($scope.noMoreItemsAvailable) {
					$scope.$broadcast('scroll.infiniteScrollComplete');
					return;
				}
				if ($scope.isFirstIn) {
					$scope.isFirstIn = false;
					$scope.$broadcast('scroll.infiniteScrollComplete');
					return;
				}
				$scope.startPage++;
				if (curCode == 'jx') {
					asksServices.getAskChoiceness(assembleOtherItem()).then(function(response) {
						addNewItem(response);
					});
				} else if (curCode == 'highest') {
					asksServices.getAskMaximunReward(assembleOtherItem()).then(function(response) {
						addNewItem(response);
					});
				} else {
					asksServices.getAskLists(assembleItem(curCode)).then(function(response) {
						addNewItem(response);
					});
				}

			};
		}
	])
});