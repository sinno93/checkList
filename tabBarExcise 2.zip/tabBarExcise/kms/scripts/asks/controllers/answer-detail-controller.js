define(['angularAMD', 'common/services/footer-service', 'asks/services/ask-services', 'common/directive/input-box', 'common/filters/common-filter'], function(angularAMD) {
	angularAMD.controller('answerDetailController', ['$scope', '$ionicModal', '$location', '$rootScope', '$stateParams', 'asksServices', 'FooterServices', '$ionicScrollDelegate',
		function($scope, $ionicModal, $location, $rootScope, $stateParams, asksServices, FooterServices, $ionicScrollDelegate) {
			'use strict';
			FooterServices.hide();

			var questionID = $stateParams.questionID;
			var answererID = $stateParams.answererID;
			var type = $stateParams.type;
			var myWorkId = getMyId();
			var headPath = getHeadPath();

			//问题的详情
			$scope.askDetail = {};
			//问题的回答，追问，追问的回答
			$scope.replyDetail = {};
			//问题评论的列表
			$scope.commentList = [];

			function getPostType(type) {
				console.log(type);
				if (type == 'append') {
					$scope.type = 'append';
					inputBoxAsk8($scope);
				} else if (type == 'comment') {
					$scope.type = 'comment';
					inputBoxAsk9($scope);
				} else if (type == 'detailReply') {
					$scope.type = 'detailReply';
					inputBoxAsk7($scope);
					$scope.sign.imageUrlDirectory = true;
				} else {
					$scope.type = 'appendReply';
					inputBoxAsk10($scope);
				}
			}


			$scope.title = "回答详情";



			function init() {

				getPostType(type);
				getQuestionDetail();
				getQuesionAnswerAndAppend();
				getCommentList();
				$ionicScrollDelegate.scrollBottom(true);
				if (headPath == null || headPath == '') {
					asksServices.getUserInfo().then(function(response) {
						console.log(response);
						headPath = response.data.headPath;
						setHeadPath(headPath);
					});
				}
			}
			init();
			//获得问题的详情
			function getQuestionDetail() {
				asksServices.getAskDetail(questionID).then(function(response) {
					if (response.status == 1) {
						$scope.askDetail = response.data;
					}
				});
			}

			//获得评论列表
			function getCommentList() {
				asksServices.getReplyComment(answererID).then(function(response) {
					if (response.status == 1) {
						if (response.data != null) {
							$scope.commentList = response.data;
						}
					}

				});
			}
			//获得问题答案，追问，及追问的答案
			function getQuesionAnswerAndAppend() {
				asksServices.getReplyAndAppendReply(answererID).then(function(response) {
					$scope.replyDetail = response.data;
					console.log($scope.replyDetail);
				});
			}

			//组装采纳参数
			function assembleAdoptItem() {
				return {
					'id': answererID,
					'adoptComment': ''
				};
			}

			//讲评论的内容push到评论列表上
			function pushToCommentInfo(item) {
				return {
					'commentUserId': myWorkId,
					'content': item,
					'headPath': headPath,
					'commentDate': Date.parse(new Date())
				}
			}

			/**
			 * 组装回复上传内容
			 */
			function assembleReplyItem(item) {
				return {
					'id': answererID,
					'content': item
				}
			}

			/**
			 * 组装追问上传
			 */
			function assembleAppendItem(item) {
				return {
					'id': answererID,
					'replyAppend': item
				};
			}
			/**
			 * 组装评论的上传
			 */
			function assembleCommentItem(item) {
				return {
					'questionReplyId': answererID,
					'content': item
				};
			}

			function assembleReplyAppendItem(item) {
				return {
					'id': answererID,
					'appendReply': item
				};
			}
			$scope.headPath = function(path) {
				return assembleImageUrl(path);
			};
			$scope.hasAppend = function(replyDetail) {
				if (replyDetail.replyAppend) {
					return true;
				}
				return false;
			};
			$scope.getCommentName = function(comment) {
				return comment.commentUserName + comment.commentUserId;
			};
			$scope.hasAppendReply = function(replyDetail) {
				if (replyDetail.appendReply) {
					return true;
				}
				return false;
			};
			$scope.getCreator = function() {
				return $scope.askDetail.createrName + $scope.askDetail.createrId;
			};

			$scope.hasReward = function() {
				if ($scope.askDetail.rewardScore) {
					return true;
				}
				return false;
			};
			$scope.emoijToText = function(html) {
				return replace_html(html);
			};

			$scope.isSelft = function(id) {
				return id == myWorkId;
			};

			$scope.showAdopt = function() {
				if ($scope.replyDetail.isBestReply != 1 && myWorkId == $scope.askDetail.createrId) {
					return true;
				}
				return false;
			};
			$scope.getAdoptContent = function() {
				if ($scope.replyDetail.adoptComment) {
					return $scope.replyDetail.adoptComment;
				} else {
					return '太感谢了，你完美的解决了我的问题';
				}
			};
			$scope.isSelf = function(workID) {
				return workID == myWorkId;
			};
			$scope.getReward = function() {
				return '悬赏' + $scope.askDetail.rewardScore;
			};

			$scope.getReplyName = function() {
				return $scope.replyDetail.replyName + $scope.replyDetail.replyId;
			};

			$scope.getCommnetName = function(comment) {
				return comment.commentUserName + comment.commnetUserId;
			};

			/**
			 * 回复 
			 * 如果没有追问，覆盖掉以前的回复
			 * 如果有追问，就是回复追问
			 */
			$scope.reply = function(item) {
				asksServices.updateReply(assembleReplyItem(item)).then(function(response) {
					if (response.status == 1) {
						$scope.replyDetail.contentSequence = [{
							'type': 'text',
							'text': item
						}];
						$scope.replyDetail.replyDate = Date.parse(new Date());
					}

				});

			};

			$scope.appendReply = function(item) {
					asksServices.replyAppend(assembleReplyAppendItem(item)).then(function(response) {
						if (response.status == 1) {
							$scope.replyDetail.appendReply = item;
							$scope.replyDetail.appendReplyDate = Date.parse(new Date());
						}
					});
				}
				//			/**
				//			 * 用图片来答案编辑
				//			 */
				//			$scope.getImageUrl = function(image) {
				//				transferImageToService(Global.apiPath + "/upload/image", image.original, function(imageUrl) {
				//					console.log(imageUrl);
				//					asksServices.setReply({
				//						'questionId': questionID,
				//						'images': imageUrl
				//					}).then(function(response) {
				//						if (response.status == 1) {
				//							$ionicPopup.alert({
				//								template: "<p >" + '回答成功' + "</p>"
				//							});
				//						} else if (response.status == 0) {
				//							$ionicPopup.alert({
				//								template: "<p >" + response.errorMessage + "</p>"
				//							});
				//						}
				//					});
				//					$scope.myhead = headPath;
				//					$scope.postInfo.push(pushImageInfo(image.thumbnail));
				//					$ionicScrollDelegate.scrollBottom(true);
				//				}, function() {
				//
				//				});
				//			};

			/**
			 * 追问
			 */
			$scope.append = function(item) {
				asksServices.setAppend(assembleAppendItem(item)).then(function(response) {
					if (response.status == 1) {
						$scope.replyDetail.replyAppend = item;
						$scope.replyDetail.replyAppendDate = Date.parse(new Date());
					}

				});
			};
			/**
			 * 采纳
			 */
			$scope.adopt = function() {
				asksServices.setAdopt(assembleAdoptItem()).then(function(response) {
					console.log(response);
					if (response.status == 1) {
						inputBoxAsk9($scope);
						$scope.replyDetail.adoptCommentDate = Date.parse(new Date());
						$scope.replyDetail.isBestReply = 1;
					}
				});
			};
			/**
			 * 评论
			 */
			$scope.comment = function(item) {

				asksServices.setComment(assembleCommentItem(item)).then(function(response) {
					if (response.status == 1) {
						$scope.commentList.push(pushToCommentInfo(item));
						$ionicScrollDelegate.scrollBottom(true);
					}
				});

			};
			$scope.getImageUrl = function(src) {
				return assembleImageUrl(src) + '.thumbnail';
			}
			$scope.showImageViewer = function(src) {
				var imgArray = [];
				_.each($scope.askDetail.contentSequence, function(content) {
					if (content.type == 'image') {
						imgArray.push(assembleImageUrl(content.src));
					}
				});
				_.each($scope.replyDetail.contentSequence, function(content) {
					if (content.type == 'image') {
						imgArray.push(assembleImageUrl(content.src));
					}
				});
				var index = 0;
				for (var i = 0; i < imgArray.length; i++) {
					if (imgArray[i] == assembleImageUrl(src)) {
						index = i;
						break;
					}
				}
				imgArray.unshift(index);
				pictrueViewer(imgArray);
			};
			$(window).on('touchstart', function(obj) {
				keyboardDown();
			});
		}
	])

});