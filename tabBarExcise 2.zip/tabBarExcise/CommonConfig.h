//
//  CommonConfig.h
//  SFExpressApp
//
//  Created by 刘梓涛(ALEX Liu)-企业内部系统研发中心 on 16/1/11.
//  Copyright © 2016年 Neusoft. All rights reserved.
//

#ifndef CommonConfig_h
#define CommonConfig_h
#endif /* CommonConfig_h */
#define URL_TYPE 3

#if URL_TYPE == 0    //asp

#define COMMON_LOGIN_URL [SFUrlUtility getASPLoginUrl]
#define FOUD_PATH @"asp"


#elif URL_TYPE == 1    //itmp

#define COMMON_LOGIN_URL [SFUrlUtility getItmpLoginUrl]
#define FOUD_PATH @"itmp"


#elif URL_TYPE == 2    //ecp

#define COMMON_LOGIN_URL [SFUrlUtility getECPLoginUrl]
#define FOUD_PATH @"ecp"


#elif URL_TYPE == 3     //kms

#define COMMON_LOGIN_URL [SFUrlUtility getKMSLoginUrl]
#define FOUD_PATH @"kms"


#elif URL_TYPE == 4      //dickonline

#define COMMON_LOGIN_URL [SFUrlUtility getKMSLoginUrl]
#define FOUD_PATH @"dickonline"


#elif URL_TYPE == 5       //epm

#define COMMON_LOGIN_URL [SFUrlUtility getPMSLoginUrl]
#define FOUD_PATH @"epm"
#endif


