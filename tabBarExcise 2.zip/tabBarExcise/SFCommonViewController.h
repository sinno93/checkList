//
//  SFCommonViewController.h
//  SFExpressApp
//
//  Created by 刘梓涛(ALEX Liu)-企业内部系统研发中心 on 16/1/11.
//  Copyright © 2016年 Neusoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Cordova/CDVViewController.h>

@interface SFCommonViewController : CDVViewController

@end
