//
//  myURLProtocol.m
//  tabBarExcise
//
//  Created by 郑庆登(King Zheng)-企业内部系统研发中心 on 16/1/19.
//  Copyright © 2016年 郑庆登(Qingdeng Zheng)-IT服务中心. All rights reserved.
//

#import "myURLProtocol.h"
#import "zqdownload.h"
#import "zqdCacheManager.h"
//#define ECP_loadUrl  @"http://218.17.248.244:4280/5a3d7a70c66e4194add37263894f5387cf0b9d9492f14d79b7ee59c485a22d72/www"
@implementation myURLProtocol
+ (BOOL)canInitWithRequest:(NSURLRequest*)theRequest{
    
    if ([NSURLProtocol propertyForKey:@"MyURLProtocolHandledKey" inRequest:theRequest]) {
        return NO;
    }
   return [[zqdCacheManager share]shouldBeHandledWithUrl:theRequest.URL];
}
+ (NSURLRequest *)canonicalRequestForRequest:(NSURLRequest *)request
{
      return request;
}
// 开始加载 在此判断是否已经缓存，若已经缓存，直接使用缓存文件即可
// 若没有缓存 则去相应的地址取数据并返回
- (void)startLoading {
    NSMutableURLRequest *newRequest = [self.request mutableCopy];
    [newRequest setTimeoutInterval:200];
    [NSURLProtocol setProperty:@YES forKey:@"MyURLProtocolHandledKey" inRequest:newRequest];
    // 获取短网址,判断网址中是否含有cordova.js cordova-plugin.js 以及 /components/ 路径 若有 返回数据给它
    // 若没有 判断网址是否在shortUrlDic 中 若在 判断是否最新数据 不在 放走
    // 若是最新数据 放走 不是最新数据 下载后放走
    NSMutableString *shortUrlStr = [NSMutableString string];
    shortUrlStr = [[[zqdCacheManager share]getShortUrlStrWithUrl:newRequest.URL] mutableCopy];
    
    // cordova.js文件
    if([newRequest.URL.absoluteString rangeOfString:@"cordova.js"].length>0){
        NSString *memiType = @"application/x-javascript";
        NSURLResponse *response = [[NSURLResponse alloc] initWithURL:[newRequest URL]
                                                            MIMEType:memiType
                                               expectedContentLength:-1
                                                    textEncodingName:nil];
        NSURL *cordovaUrl = [[NSBundle mainBundle] URLForResource:@"cordova" withExtension:@"js"];
        NSData *data = [NSData dataWithContentsOfFile:cordovaUrl];
        [[self client] URLProtocol:self didReceiveResponse:response cacheStoragePolicy:NSURLCacheStorageNotAllowed]; // we handle caching ourselves.
        [[self client] URLProtocol:self didLoadData:data];
        [[self client] URLProtocolDidFinishLoading:self];
        return;
    }// 包含组件里的东西...
    if([newRequest.URL.absoluteString rangeOfString:@"/components/"].length>0){
        NSString *memiType = [self mimeTypeForPath:newRequest.URL.absoluteString];
        NSURLResponse *response = [[NSURLResponse alloc] initWithURL:[newRequest URL]
                                                            MIMEType:memiType
                                               expectedContentLength:-1
                                                    textEncodingName:nil];
        // 分隔components
        NSString *shortPath = [newRequest.URL.absoluteString componentsSeparatedByString:@"/components/"][1];
        NSString *headPath = [shortPath componentsSeparatedByString:@"."][0];
        NSString *suffix = [shortPath componentsSeparatedByString:@"."][1];
        NSString *comPath = [[NSBundle mainBundle] pathForResource:headPath ofType:suffix inDirectory:@"components"];
//        NSURL *cordovaUrl = [[NSBundle mainBundle] URLForResource:@"cordova" withExtension:@"js"];
        NSData *data = [NSData dataWithContentsOfFile:comPath];
        [[self client] URLProtocol:self didReceiveResponse:response cacheStoragePolicy:NSURLCacheStorageNotAllowed]; // we handle caching ourselves.
        [[self client] URLProtocol:self didLoadData:data];
        [[self client] URLProtocolDidFinishLoading:self];
        return;
    }
    [zqdCacheManager handleShortUrlStr:shortUrlStr andReturn:^(NSString*path){
        self.connection = [[NSURLConnection alloc]initWithRequest:newRequest delegate:self startImmediately:YES];
        return;
    }];

}
+(BOOL)isToCacheWithUrlStr:(NSString*)urlString{

    return  [ urlString hasSuffix:@".html"]||[urlString hasSuffix:@".js"]||[urlString hasSuffix:@".css"]||([urlString rangeOfString:@".woff?"].length>0)||([urlString rangeOfString:@".svg"].length>0)||([urlString rangeOfString:@".ttf"].length>0)||[urlString hasSuffix:@".png"];

}
- (NSString *)mimeTypeForPath:(NSString *)originalPath  {
    if ([originalPath hasSuffix:@".png"]) {
        return @"image/png";
    } else if ([originalPath hasSuffix:@".jpeg"]) {
        return @"image/jpeg";
    }else if ([originalPath hasSuffix:@".jpg"]) {
        return @"image/jpg";
    }else if ([originalPath hasSuffix:@".gif"]) {
        return @"image/gif";
    }
    else if ([originalPath hasSuffix:@".js"]) {
        return @"application/x-javascript";
    }
    else if ([originalPath hasSuffix:@".css"]) {
        return @"text/css";
    } else if([originalPath hasSuffix:@".html"]){
        return @"text/html";
    }else if([originalPath rangeOfString:@".woff"].length>0){
        return @"application/font-woff";
    }else if([originalPath rangeOfString:@".ttf"].length>0){
        return @"application/x-font-truetype";
    }else if([originalPath rangeOfString:@".svg"].length>0){
        return @"image/svg+xml";
    }
    else return @"unknow";
}
- (void)stopLoading
{
    [self.connection cancel];
    self.connection = nil;
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    self.responseData = [[NSMutableData alloc] init];
    [self.client URLProtocol:self didReceiveResponse:response cacheStoragePolicy:NSURLCacheStorageNotAllowed];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    [self.responseData appendData:data];
    [self.client URLProtocol:self didLoadData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
     NSString *urlStr = connection.currentRequest.URL.absoluteString;
    [self.client URLProtocolDidFinishLoading:self];
}
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    [self.client URLProtocol:self didFailWithError:error];
    
    NSLog(@"myURLProtocol error:%@%@", [error localizedDescription],connection);
}
// 为了通过https验证
- (BOOL)connection:(NSURLConnection *)connection canAuthenticateAgainstProtectionSpace:(NSURLProtectionSpace *)protectionSpace
{
    NSLog(@"验证。。。%@",connection);
    return [protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust];
}

- (void)connection:(NSURLConnection *)connection didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge {
    if ([challenge.protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust]){
        [[challenge sender]  useCredential:[NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust] forAuthenticationChallenge:challenge];
        [[challenge sender]  continueWithoutCredentialForAuthenticationChallenge: challenge];
    }
}

@end
