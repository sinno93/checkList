//
//  friendsViewController.m
//  tabBarExcise
//
//  Created by 郑庆登(King Zheng)-企业内部系统研发中心 on 16/1/15.
//  Copyright © 2016年 郑庆登(Qingdeng Zheng)-IT服务中心. All rights reserved.
//

#import "friendsViewController.h"
#import "CasLoginFilter.h"
#import "zqdCacheManager.h"
#import "ConstHeader.h"
@interface friendsViewController ()<CasLoginFilterDelegate>
{
    NSMutableData * _receiveData;
}
@end

@implementation friendsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor grayColor];
    
    UIButton *go = [[UIButton alloc]initWithFrame:CGRectMake(100, 100, 100, 50)];
    [go setTitle:@"发送提醒" forState:UIControlStateNormal];
    UIButton *casLoginButton = [[UIButton alloc]initWithFrame:CGRectMake(200,200, 100, 50)];
     UIButton *webVersionButton = [[UIButton alloc]initWithFrame:CGRectMake(200,300, 100, 50)];
    UIButton *manifestButton = [[UIButton alloc]initWithFrame:CGRectMake(200,400, 100, 50)];
    UIButton *pathInfoButton = [[UIButton alloc]initWithFrame:CGRectMake(200,500, 100, 50)];
    
    [webVersionButton  setTitle:@"cas二次登录" forState:UIControlStateNormal];
    webVersionButton.backgroundColor = [UIColor blueColor];
    [manifestButton  setTitle:@"manifest" forState:UIControlStateNormal];
    manifestButton.backgroundColor = [UIColor blueColor];
    [pathInfoButton  setTitle:@"pathInfo" forState:UIControlStateNormal];
    pathInfoButton.backgroundColor = [UIColor blueColor];
    [casLoginButton setTitle:@"Cas登录" forState:UIControlStateNormal];
    go.backgroundColor = [UIColor brownColor];
    casLoginButton.backgroundColor = [UIColor brownColor];
    [go addTarget:self action:@selector(go:) forControlEvents:UIControlEventTouchUpInside];
    [casLoginButton addTarget:self action:@selector(casLogin:) forControlEvents:UIControlEventTouchUpInside];
    [webVersionButton addTarget:self action:@selector(casSecondLogin) forControlEvents:UIControlEventTouchUpInside];
    [manifestButton addTarget:self action:@selector(getWebVersion:) forControlEvents:UIControlEventTouchUpInside];
    [pathInfoButton addTarget:self action:@selector(getDirectory:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:go];
    [self.view addSubview:casLoginButton];
    [self.view addSubview:webVersionButton];
    [self.view addSubview:manifestButton];
    [self.view addSubview:pathInfoButton];
}
-(void)go:(id)sender{
    if ([[UIApplication sharedApplication] respondsToSelector:@selector(registerUserNotificationSettings:)]){
        if ([[UIApplication sharedApplication]currentUserNotificationSettings].types!=UIUserNotificationTypeNone) {
            
        }else{
            [[UIApplication sharedApplication]registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:UIUserNotificationTypeAlert|UIUserNotificationTypeBadge|UIUserNotificationTypeSound  categories:nil]];
        }
    }
    [self addLocalNotification];
    NSLog(@"推送通知");
}
- (void)getDirectory:(id)sender{
    NSLog(@"沙盒目录:%@",[friendsViewController documentsDirectory]);
    [friendsViewController setProperFilePathWithShortUrl:@"www/i/b/c/ss"];
}
-(void)casLogin:(id)sender{
    CasLoginFilter *login =  [[CasLoginFilter alloc] init];
    login.loginDeleage = self;
    NSString* username=@"835881";
    NSString* password=@"iOSnodejs.com";
    [login userLogin:username passWord:password];
    
}
+(void)setProperFilePathWithShortUrl:(NSString*)str{
    // 还是要返回目录地址比较好
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSArray *fileArr = [str componentsSeparatedByString:@"/"];
    if (fileArr.count>2) {
        NSMutableString *fileRealPath = [[NSMutableString alloc]initWithString:[self documentsDirectory]];
        NSMutableArray *fileMutArr = [fileArr mutableCopy];
        [fileMutArr removeLastObject];
        for(NSString*filePath in fileMutArr){
            [fileRealPath appendFormat:@"/%@",filePath];
        }
        BOOL dirExist = [fileManager fileExistsAtPath:fileRealPath];
        if(!dirExist){ // 文件夹不存在
            [fileManager createDirectoryAtPath:fileRealPath withIntermediateDirectories:YES attributes:nil error:nil];
        }
    }
}
-(void)casSecondLogin{
    // 第二次cas登录 kms登录地址:https://kms-mappserver.sf-express.com/KMS-MSERVER/question/category/list-top
    _receiveData = [[NSMutableData alloc]initWithLength:0];
    NSString * loginUrl = @"https://kms-mappserver.sf-express.com/KMS-MSERVER/question/category/list-top";
    NSString * casUrl=ACTION_LOGIN_URL
    NSString *kmsLoginStr =[NSString stringWithFormat:@"%@?service=%@",casUrl,loginUrl];
    NSURL *kmsLoginUrl = [NSURL URLWithString:kmsLoginStr];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:kmsLoginUrl];
    [request setTimeoutInterval:15];
    [NSURLConnection connectionWithRequest:request delegate:self];
}
// 获取服务器上的webversion
-(void)getWebVersion:(id)sender{
    
    NSHTTPCookieStorage *cookieStorage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    NSArray *cookieArr = [cookieStorage cookies];
    //@"https://mcas.sf-express.com/cas/login?locale=zh&language=zh&country=CN&variant=CN"
    NSURLRequest *request = [[NSURLRequest alloc]initWithURL:[NSURL URLWithString:@"http://www.baidu.com"] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:100];
    //第三步，连接服务器
    NSURLConnection *connection = [[NSURLConnection alloc]initWithRequest:request delegate:nil ];
    
}
#pragma mark - CasLoginFilterDelegate
-(void)didUserLogin:(BOOL) isSucceed retunMesssage:(NSDictionary*) dict
{
    
    NSNumber *isLoginSuccess = [dict objectForKey:@"isLoginSuccess"];
    if ([isLoginSuccess intValue] == 0) {
        //[self.loading hide:YES];
        NSString *error = [dict objectForKey:@"message"];
        UIAlertView *alter = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"alert_standard_title", nil) message:error delegate:self  cancelButtonTitle:NSLocalizedString(@"IKnowFriend",nil) otherButtonTitles:nil, nil];
        [alter show];
        return;
    }
    else {
        NSLog(@"登录成功");
        //        TokenVerify *verify = [[TokenVerify alloc] init];
        //        [verify verfy:self];
    }
    //loginDictionary = dict;
}
-(void)addLocalNotification{
    NSLog(@"发送通知");
    //定义本地通知对象
    UILocalNotification *notification=[[UILocalNotification alloc]init];
    //设置调用时间
    notification.fireDate=[NSDate dateWithTimeIntervalSinceNow:5];//通知触发的时间，5s以后
    notification.repeatInterval=2;//通知重复次数
    notification.timeZone = [NSTimeZone defaultTimeZone];
    //notification.repeatCalendar=[NSCalendar currentCalendar];//当前日历，使用前最好设置时区等信息以便能够自动同步时间
    
    //设置通知属性
    notification.alertBody=@"您好!您在17:30-18:00有一个微访谈~"; //通知主体
   
//    notification.applicationIconBadgeNumber=(num+1);//应用程序图标右上角显示的消息数
    
    notification.alertAction=@"打开应用"; //待机界面的滑动动作提示
    notification.alertLaunchImage=@"Default";//通过点击通知打开应用时的启动图片,这里使用程序启动图片
    //notification.soundName=UILocalNotificationDefaultSoundName;//收到通知时播放的声音，默认消息声音
    notification.soundName=@"msg.caf";//通知声音（需要真机才能听到声音）
    
    //设置用户信息
    notification.userInfo=@{@"id":@1,@"user":@"Kenshin Cui"};//绑定到通知上的其他附加信息
    
    //调用通知
    NSLog(@"%@",[[UIApplication sharedApplication]scheduledLocalNotifications]);
    [[UIApplication sharedApplication ]scheduleLocalNotification:notification];
    //[[UIApplication sharedApplication] scheduleLocalNotification:notification];
   // [[UIApplication sharedApplication] presentLocalNotificationNow:notification];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (instancetype)init{
    self = [super init];
    self.tabBarItem.title=@"好友";
    self.tabBarItem.image=[UIImage imageNamed:@"friend.png"];
    self.tabBarItem.badgeValue=@"2";

    return self;
}
+(NSString*)documentsDirectory{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths firstObject];
    return documentsDirectory;
}
-(void)dealloc{
    
    NSLog(@"friendsViewControllerDead");
}

#pragma mark - NSURLConnectionDataDelegate
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    NSHTTPURLResponse *http = (NSHTTPURLResponse *)response;
   
}
- (void)connection:(NSURLConnection *)aConn didReceiveData:(NSData *)data
{
    [_receiveData appendData:data];
}
- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSData* returnData = [NSData dataWithData:_receiveData];
    NSString * responseContent = [[NSString alloc] initWithData:returnData encoding:NSUTF8StringEncoding];
    NSLog(@"%@",responseContent);
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:[error localizedDescription] delegate:nil cancelButtonTitle:NSLocalizedString(@"IKnow",nil) otherButtonTitles:nil, nil];
    [alert show];
}
- (BOOL)connection:(NSURLConnection *)connection canAuthenticateAgainstProtectionSpace:(NSURLProtectionSpace *)protectionSpace
{
    return [protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust];
}

- (void)connection:(NSURLConnection *)connection didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge {
    if ([challenge.protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust]){
        [[challenge sender]  useCredential:[NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust] forAuthenticationChallenge:challenge];
        [[challenge sender]  continueWithoutCredentialForAuthenticationChallenge: challenge];
    }
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
