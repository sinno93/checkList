//
//  zqdownload.m
//  tabBarExcise
//
//  Created by 郑庆登(King Zheng)-企业内部系统研发中心 on 16/1/26.
//  Copyright © 2016年 郑庆登(Qingdeng Zheng)-IT服务中心. All rights reserved.
//

#import "zqdownload.h"

@implementation zqdownload
@synthesize requestResultBlock;

+ (void)downloadWithURL:(NSString*)urlString
               complete:(void (^)(NetState state, NSData *data))requestResult {
    
    zqdownload *download = [[zqdownload alloc] init];
    download.requestResultBlock = requestResult;
    
    NSURL *url = [NSURL URLWithString:urlString];
    if ([urlString rangeOfString:@"ta.css"].length>0) {
        NSLog(@"catch ta.css");
    }
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url
                                             cachePolicy:NSURLRequestReloadIgnoringLocalCacheData
                                         timeoutInterval:200];
    [NSURLProtocol setProperty:@YES forKey:@"MyURLProtocolHandledKey" inRequest:request];
    [NSURLConnection connectionWithRequest:request delegate:download];
    
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    self.requestResultBlock(connectFailed, nil);
}

- (BOOL)connection:(NSURLConnection *)connection canAuthenticateAgainstProtectionSpace:(NSURLProtectionSpace *)protectionSpace {
    return [protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust];
}

- (void)connection:(NSURLConnection *)connection didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge {
    if ([challenge.protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust])
        //if ([trustedHosts containsObject:challenge.protecti*****pace.host])
        [challenge.sender useCredential:[NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust]
             forAuthenticationChallenge:challenge];
    
    [challenge.sender continueWithoutCredentialForAuthenticationChallenge:challenge];
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    NSHTTPURLResponse *http = (NSHTTPURLResponse*)response;
    self.httpCode = http.statusCode;
    
    myData = [[NSMutableData alloc] init];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    [myData appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    if (self.httpCode!= 200) {
        self.requestResultBlock(connectFailed,nil);
    }else{
        self.requestResultBlock(success, myData);
    }
}

- (void)dealloc {
    
}

@end
